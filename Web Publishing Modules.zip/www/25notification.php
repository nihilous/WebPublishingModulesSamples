<?php
  include_once('./inc/vs.php');
?>


<!doctype html>
<html itemscope="" itemtype="http://schema.org/WebPage" lang="ko">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title></title>
    <link rel="stylesheet" type="text/css" href="./css/reset.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.2/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="./css/style.css?<?=$ver?>">

</head>
<body>
    <div id="NotificationPage">
        <div id="notiContents">
            <form method="post">
                <div class="notiBox">
                    <div class="nbRow">
                        <div class="nbTitle">알림 수신방법 선택</div>
                        <div class="clear"></div>
                    </div>
                    <div class="nbRow">
                        <div class="nbrSection">
                            <div class="nbrLeft"><input id="nbKakao" name="notiContMethod" type="radio" /></div>
                            <label class="nbrRight" for="nbKakao"> 카카오 알림톡 (휴대폰번호 기반)</label>
                            <div class="clear"></div>
                        </div>
                        <div class="nbrSection">
                            <div class="nbrLeft"><input id="nbSMS" name="notiContMethod" type="radio" /></div>
                            <label class="nbrRight" for="nbSMS">문자 (SMS)</label>
                            <div class="clear"></div>
                        </div>
                    </div>
                    <div class="nbrWarn">
                        <img src="./img/24settingwarn.png?<?=$ver?>" />
                        <p> 카카오 알림톡 발송 실패 시 문자(SMS)로 발송됩니다.</p>
                        <div class="clear"></div>
                     </div>
                    <div class="nbRow">
                        <div>
                            <div class="nbTitle">담보채권 투자 알림</div>
                            <div class="nbOnOffB">on/off</div>
                            <div class="clear"></div>
                        </div>
                    </div>
                    <div class="nbRow">
                        <div class="nbrStitle">담보채권 투자금 상환 알림</div>
                        <div class="nbrSection">
                            <div class="nbrLeft"><input id="nbCB1" type="checkbox" /></div>
                            <label class="nbrRight" for="nbCB1">채권별</label>
                            <div class="clear"></div>
                        </div>
                    </div>
                    <div class="nbRow">
                        <div class="nbrStitle">담보 투자 채권 상태 알림</div>
                        <div class="nbrSection">
                            <div class="nbrLeft"><input id="nbCB2" type="checkbox" /></div>
                            <label class="nbrRight" for="nbCB2">투자채권 취소</label>
                            <div class="clear"></div>
                        </div>
                        <div class="nbrSection">
                            <div class="nbrLeft"><input id="nbCB3" type="checkbox" /></div>
                            <label class="nbrRight" for="nbCB3">연체발생 / 연체후 상환</label>
                            <div class="clear"></div>
                        </div>
                        <div class="nbrSection">
                            <div class="nbrLeft"><input id="nbCB4" type="checkbox" /></div>
                            <label class="nbrRight" for="nbCB4">기한이익상실</label>
                            <div class="clear"></div>
                        </div>
                        <div class="nbrSection">
                            <div class="nbrLeft"><input id="nbCB5" type="checkbox" /></div>
                            <label class="nbrRight" for="nbCB5">장기연체</label>
                            <div class="clear"></div>
                        </div>
                        <div class="nbrSection">
                            <div class="nbrLeft"><input id="nbCB6" type="checkbox" /></div>
                            <label class="nbrRight" for="nbCB6">중도상환</label>
                            <div class="clear"></div>
                        </div>
                    </div>
                    <div class="nbRow">
                        <div class="nbrStitle">투자상품 진행상황 업데이트 알림</div>
                        <div class="nbrSection">
                            <div class="nbrLeft"><input id="nbCB7" type="checkbox" /></div>
                            <label class="nbrRight" for="nbCB7">투자상품 진행상황 알림받기</label>
                            <div class="clear"></div>
                        </div>
                    </div>
                    <div class="nbRow">
                        <div class="nbrStitle">자동투자 알림</div>
                        <div class="nbrSection">
                            <div class="nbrLeft"><input id="nbCB8" type="checkbox" /></div>
                            <label class="nbrRight" for="nbCB8">자동투자 알림받기</label>
                            <div class="clear"></div>
                        </div>
                    </div>
                </div>


            </form>

        </div>
    </div>
</body>
</html>
