<?php
  include_once('./inc/vs.php');
?>


<!doctype html>
<html itemscope="" itemtype="http://schema.org/WebPage" lang="ko">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title></title>
    <link rel="stylesheet" type="text/css" href="./css/reset.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.2/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="./css/style.css?<?=$ver?>">

</head>
<body>
    <div id="InvesterInfoPage">
        <div id="iiContents">
            <div class="iiBox">
                <form method="get">
                    <div class="iiInfoType">
                        <div class="iiITelem1">기본정보</div>
                        <div class="iiMargin"></div>
                        <div class="iiITelem2">투자자정보</div>
                        <div class="iiMargin"></div>
                        <div class="iiITelem3">비밀번호 수정</div>
                        <div class="clear"></div>
                    </div>
                    <div class="iibInfos">
                        <div class="iibR1">
                            <div class="iibRl">투자자 구분</div>
                            <div class="iibRr">
                                <div class="iibr1T">개인 투자자</div>
                                <div class="iibr1D"><p><b>투자한도:</b>동일 투자물건에 대해 최대 500만원, 연 최대 1,000만원 이내 (투자금 잔액기준)</p></div>
                                <div class="iibr1D">※ 나의 잔여투자한도 확인은 <a href="#">대시보드</a>에서 가능합니다.</div>
                                <div class="iibInBox">
                                    <div class="iibIBt">투자한도 안내</div>
                                    <div class="iibIBd">금융위원회가 고시한 P2P가이드라인에 따라 투자자 개인의 연 투자한도가 제한됩니다. ‘투자자구분’에 따라 ‘투자한도’가 달리 적용되며, 조건을 갖춘 개인투자자는 투자한도 변경 신청을 통해 투자한도를 증액 할 수 있습니다. ※ 개인투자자는 전년도 근로-사업소득 1억원 이상 및 이자배당소득 2천만원 이상일 경우 최대 4천만원까지 투자한도가 확대됩니다.</div>
                                </div>
                            </div>
                            <div class="clear"></div>
                        </div>
                        <div class="iibR2">
                            <div class="iibRl">나의 가상계좌</div>
                            <div class="iibRr">
                                <div>
                                    <input class="iibBigInp" type="text" name="iiVAbank" value="신한은행"/>
                                </div>
                                <div>
                                    <input class="iibBigInp" type="text" name="iiVAnum" value="01234567890123"/>
                                </div>
                                <div>
                                    <input class="iibBigInp" type="text" name="iiVAown" value="테라펀딩(이석진)"/>
                                </div>
                            </div>
                            <div class="clear"></div>
                        </div>
                        <div class="iibR3">
                            <div class="iibRl">나의 출금계좌</div>
                            <div class="iibRr">
                                <div>
                                    <input class="iibBigInp" type="text" name="iiWAbank" value="기업은행"/>
                                </div>
                                <div>
                                    <input class="iibBigInp" type="text" name="iiWAnum" value="9876543210"/>
                                </div>
                                <div>
                                    <div class="iibI1"><input class="iibSmallInp" type="text" name="waOwn" value="이석진"/></div>
                                    <div class="iibI2">변경</div>
                                    <div class="clear"></div>
                                </div>
                            </div>
                            <div class="clear"></div>
                        </div>
                        <div class="iibR4">
                            <div class="iibRl">주민등록번호</div>
                            <div class="iibRr">
                                <div>
                                    <input class="iibBigInp" type="text" name="iiRn" value="8211111*****3"/>
                                </div>
                            </div>
                            <div class="clear"></div>
                        </div>
                        <div class="iibR5">
                            <div class="iibRl">주소</div>
                            <div class="iibRr">
                                <div>
                                    <input class="iibBigInp" type="text" name="iiForeAddress" value="서울 강남구"/>
                                </div>
                                <div>
                                    <div class="iibI1"><input class="iibSmallInp" type="text" name="iiDetAddress" value="2층 일레븐먼트"/></div>
                                    <div class="iibI2">변경</div>
                                    <div class="clear"></div>
                                </div>
                            </div>
                            <div class="clear"></div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</body>
</html>
