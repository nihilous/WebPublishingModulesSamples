<?php
  include_once('./inc/vs.php');
?>


<!doctype html>
<html itemscope="" itemtype="http://schema.org/WebPage" lang="ko">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title></title>
    <link rel="stylesheet" type="text/css" href="./css/reset.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.2/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="./css/style.css?<?=$ver?>">

</head>
<body>
    <div id="MyAccountPage">
        <div id="mapPCcontents">
            <div class="mapBox">
                <div class="mapBtop">
                    <div class="mapBTl">
                        <div>예치금</div>
                        <div>(출금가능 금액)</div>
                    </div>
                    <div class="mapBTr"><p><b>0</b>원</p></div>
                    <div class="clear"></div>
                </div>
                <div class="mapBvir">
                    <div class="mapBVl">나의 가상계좌</div>
                    <div class="mapBVr">
                        <div><p><b>예금주 : </b>테라펀딩(이석진)</p></div>
                        <div class="mapBmar"></div>
                        <div><p><b>계좌번호 : </b>12345678901234</p></div>
                        <div class="mapBmar"></div>
                        <div><p><b>은행 : </b>신한은행</p></div>
                        <div class="clear"></div>
                    </div>
                    <div class="clear"></div>
                </div>
                <div class="mapBwa">
                    <div class="mapBWAl"><p>나의 출금계좌<b>[계좌 변경]</b></p></div>
                    <div class="mapBWAr">
                        <div class="mapBWAr5"><p><b>예금주 : </b>이석진</p></div>
                        <div class="mapBmar mapBWAr4"></div>
                        <div class="mapBWAr3"><p><b>계좌번호 : </b>09876543210987</p></div>
                        <div class="mapBmar mapBWAr2"></div>
                        <div class="mapBWAr1"><p><b>은행 : </b>기업은행</p></div>
                        <div class="clear"></div>
                    </div>
                    <div class="clear"></div>
                </div>
                <div class="mapBwithdraw">
                    <div class="mapBWl">출금신청금액</div>
                    <div class="mapBWr">
                        <form>
                            <button class="mapBWR1" type="submit" name="MAPwithdraw">출금신청</button>
                            <button class="mapBWR2" type="submit" name="MAPmaxAmount">전액</button>
                            <div class="mapBWR3">
                                <input  class="mapBWR3l" type="text" name="MAPamount" />
                                <div class="mapBWR3r"> 원</div>
                                <div class="clear"></div>
                            </div>
                            <div class="clear"></div>
                        </form>
                    </div>
                    <div class="clear"></div>
                </div>
            </div>
            <div class="mapWarn">
                <div>※ 고객님의 가상계좌로 예치금 입금 후 투자신청이 가능합니다.</div>
                <div>※ 가상계좌의 잔액은 고객님의 출금계좌로 환급 받으실 수 있습니다.</div>
                <div>※ 출금신청금액은 신청 후 1분 이내에 고객님의 출금계좌로 이체됩니다.</div>
                <div>(단, 은행 전산망 점검시간(23:25~00:35)에는 출금이 불가능합니다)</div>
            </div>
        </div>
        <div id="mapMobcontents">
            <div class="mapBox">
                <div class="mapBtop">
                    <div>예치금</div>
                    <div>(출금가능 금액)</div>
                    <div class="mapBTr"><p><b>0</b>원</p></div>
                </div>
                <div class="mapBvir">
                    <div class="mapBVl">나의 가상계좌</div>
                    <div><p><b>예금주 : </b>테라펀딩(이석진)</p></div>
                    <div><p><b>계좌번호 : </b>12345678901234</p></div>
                    <div><p><b>은행 : </b>신한은행</p></div>
                </div>
                <div class="mapBwa">
                    <div class="mapBWAl"><p>나의 출금계좌<b>[계좌 변경]</b></p></div>
                    <div><p><b>예금주 : </b>이석진</p></div>
                    <div><p><b>계좌번호 : </b>09876543210987</p></div>
                    <div><p><b>은행 : </b>기업은행</p></div>
                    <div class="clear"></div>
                </div>
                <div class="mapBwithdraw">
                    <div class="mapBWl">출금신청금액</div>
                    <form>
                        <div class="mapBWbPos">
                            <button class="mapBWR1" type="submit" name="MAPwithdraw">출금신청</button>
                            <button class="mapBWR2" type="submit" name="MAPmaxAmount">전액</button>
                            <div class="clear"></div>
                        </div>
                        <div class="mapBWR3">
                            <input  class="mapBWR3l" type="text" name="MAPamount" />
                            <div class="mapBWR3r"> 원</div>
                            <div class="clear"></div>
                        </div>
                    </form>
                </div>
            </div>
            <div class="mapWarn">
                <div>※ 고객님의 가상계좌로 예치금 입금 후 투자신청이 가능합니다.</div>
                <div>※ 가상계좌의 잔액은 고객님의 출금계좌로 환급 받으실 수 있습니다.</div>
                <div>※ 출금신청금액은 신청 후 1분 이내에 고객님의 출금계좌로 이체됩니다.</div>
                <div>(단, 은행 전산망 점검시간(23:25~00:35)에는 출금이 불가능합니다)</div>
            </div>

        </div>
    </div>
</body>
</html>
