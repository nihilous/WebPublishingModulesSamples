<?php
  include_once('./inc/vs.php');
?>


<!doctype html>
<html itemscope="" itemtype="http://schema.org/WebPage" lang="ko">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title></title>
    <link rel="stylesheet" type="text/css" href="./css/reset.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.2/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="./css/style.css?<?=$ver?>">
    <script src="http://code.jquery.com/jquery-3.3.1.js" integrity="sha256-2Kok7MbOyxpgUVvAk/HJ2jigOSYS2auK4Pfzbm7uH60=" crossorigin="anonymous">
    </script>
    <script>
    $(document).ready(function(){
        $(".basicInfoBtn").click(function(){
            $(".dpProfitCal").hide();
            $(".dpBasicInfos").show();
        });
        $(".profitCalBtn").click(function(){
            $(".dpBasicInfos").hide();
            $(".dpProfitCal").show();
        });
    });
    </script>

</head>
<body>
    <div id="detailPage"> <!--1130 ,1129  768, 767-->
        <div id="detailContents">
            <form type="">
                <div class="dpMainTitle">
                <div class="dpTopPPos">
                    <p>모집기간 : 2018.06.05 ~ 2018.06.05</P>
                </div>
                <div class="dpTopTPos">
                    <p><b>제1139차 제주 신화월드 인근 공동주택 신축사업 15차</b></p>
                    <div class="dbTopBanners">
                        <div class="dpPriority">1순위</div>
                        <div class="dpAutoInvest">자동투자 30%</div>
                        <div class="dpCorporateBody">법인전용상품</div>
                        <div class="clear"></div>
                    </div>
                    <div class="clear"></div>
                </div>

            </div>
            <div class="dpMainSection">
                <div class="dpMainImg">
                    <img class="dpImgFile" src="./img/04mainimg.png?<?=$ver?>" />
                </div>
                <div class="dpMainInfo">
                    <div class="dpMIProgBar"></div>
                    <div class="dpMIEmptyBar"></div>

                    <!--완료-->
                    <div class="dpMIpaddingFinish">
                        <div class="dpMIps">
                            <div class="dpProgPercent">
                                <b>100</b>%
                            </div>
                            <div class="dpStatus">
                                <img src="./img/paybackicon.png?<?=$ver?>" />상환중
                            </div>
                            <div class="clear"></div>
                        </div>

                        <div class="dpFinancialRate">
                            <b>11억원</b>/11억원
                        </div>
                        <div class="dpPeopleCounter">
                            1944명참여
                        </div>
                        <div class="dpInnerBox">
                            <div class="dpIBP1">본 상품은 성공적으로 모집 완료되어</div>
                            <div class="dpIBP2">상환중입니다.</div>
                            <button class="dpInnerBut">다른 투자 상품 보기</button>
                        </div>
                    </div>
                    <!--모집중-->
                    <div class="dpMIpaddingFunding" style="display:none">
                        <div class="dpMIps">
                            <div class="dpProgPercent">
                                <b>50</b>%
                            </div>
                            <div class="dpStatus">
                                <img src="./img/paybackicon.png?<?=$ver?>" />모집중
                            </div>
                            <div class="clear"></div>
                        </div>

                        <div class="dpFinancialRate">
                            <b>2억 7,500백만원</b>/5억 5천만원
                        </div>
                        <div class="dpPeopleCounter">
                            1944명참여
                        </div>
                        <div class="dpExpInt">
                            <div><p><b>100만원 투자</b>시 예상수익(세전)은</p></div>
                            <div><p><b>총 131,532원</b>입니다.</p></div>
                        </div>
                        <div class="dpInvestPos">
                            <div class="dpInvestL">
                                <div class="dpMoneyInputPos">
                                    <input class="dpinputL" type="text" name="dpInvAmount" placeholder="₩" />
                                    <div class="dpinputR">만원</div>
                                    <div class="clear"></div>
                                </div>
                                <div class="dpBGruopPos">
                                    <button>10만</button>
                                    <button>100만</button>
                                    <button>1000만</button>
                                    <div class="clear"></div>
                                </div>

                            </div>
                            <button class="dpInnerBut">투자하기</button>
                            <div class="clear"></div>
                        </div>

                    </div>
                </div>
              </div>
              <div class="clear"></div>
              <div class="dpQuadB">
                  <div class="dpSBox">
                      <div>12.21%</div>
                      <div>예상 수익률(연)</div>
                  </div>
                  <div class="dpSBox">
                      <div>8개월</div>
                      <div>예상 투자기간</div>
                  </div>
                  <div class="dpSBox">
                      <div>B1</div>
                      <div>테라펀딩 평가등급</div>
                  </div>
                  <div class="dpSBox">
                      <div>56%</div>
                      <div>LTV <img src="./img/guideicon.png" /></div>
                  </div>
                  <div class="clear"></div>
              </div>
              <div class="dpLowerSection">
                  <div class="dpLowerContents">
                      <div class="BasicDetail">
                          <div class="basicInfoBtn">기본정보</div>
                          <div class="dpBotLiner"></div>
                          <div class="detailInfoBtn">상세정보</div>
                          <div class="dpBotLiner"></div>
                          <div class="profitCalBtn">수익계산</div>
                          <div class="dpBotLiner"></div>
                          <div class="clear"></div>
                      </div>



                      <div class="dpBasicInfos" >    <!-- 기본정보 버튼 클릭시-->
                          <div class="dpShortenInfos">
                              <div class="dpBDtitle">
                                  투자요약
                              </div>
                              <div class="dpBDInfos">
                                  <div class="dpBDIr">
                                      <div class="dpBDIC1">동일차주 대출현황</div>
                                      <div class="dpBDIC2">매월 이자 지급 후 원금은 만기일시상환(일부 또는 전액 조기 상환 가능) 단, 매월 25일 ~ 말일에 대출 실행된 상품의 첫 수익금은 [다다음달] 첫 영업일에 지급</div>
                                      <div class="clear"></div>
                                  </div>
                                  <div class="dpBDIr">
                                      <div class="dpBDIC1">동일차주 대출현황</div>
                                      <div class="dpBDIC2">매월 이자 지급 후 원금은 만기일시상환(일부 또는 전액 조기 상환 가능) 단, 매월 25일 ~ 말일에 대출 실행된 상품의 첫 수익금은 [다다음달] 첫 영업일에 지급</div>
                                      <div class="clear"></div>
                                  </div>
                                  <div class="dpBDIr">
                                      <div class="dpBDIC1">동일차주 대출현황</div>
                                      <div class="dpBDIC2">매월 이자 지급 후 원금은 만기일시상환(일부 또는 전액 조기 상환 가능) 단, 매월 25일 ~ 말일에 대출 실행된 상품의 첫 수익금은 [다다음달] 첫 영업일에 지급</div>
                                      <div class="clear"></div>
                                  </div>
                              </div>
                          </div >
                          <div class="dpShortenInfos">    <!--클래스 공유하지만 다른영역-->
                              <div class="dpBDtitle"> <!--공유클래스-->
                                  핵심 투자 포인트
                              </div>
                              <div class="dpBDInfos">
                                  <div class="dpCoreValueR">
                                      <div class="dpCVBar"></div>
                                      <div class="dpCVNum">
                                          POINT 01
                                      </div>
                                      <div class="dpCVEmpha">
                                          신화월드 개발 수혜 및 풍부한 수요
                                      </div>
                                      <div class="dpCVCol">
                                          신화월드 남측입구에서 2km, 영어국제도시 5km거리 위치
                                      </div>
                                      <div class="dpCVCol">
                                          신화월드 남측입구에서 2km, 영어국제도시 5km거리 위치
                                      </div>
                                      <div class="dpCVCol">
                                          신화월드 남측입구에서 2km, 영어국제도시 5km거리 위치
                                      </div>
                                  </div>
                                  <div class="dpCoreValueR">
                                      <div class="dpCVBar"></div>
                                      <div class="dpCVNum">
                                          POINT 01
                                      </div>
                                      <div class="dpCVEmpha">
                                          신화월드 개발 수혜 및 풍부한 수요
                                      </div>
                                      <div class="dpCVCol">
                                          신화월드 남측입구에서 2km, 영어국제도시 5km거리 위치
                                      </div>
                                      <div class="dpCVCol">
                                          신화월드 남측입구에서 2km, 영어국제도시 5km거리 위치
                                      </div>
                                      <div class="dpCVCol">
                                          신화월드 남측입구에서 2km, 영어국제도시 5km거리 위치
                                      </div>
                                  </div>
                              </div>
                          </div >
                          <div class="dpShortenInfos">    <!--클래스 공유하지만 다른영역-->
                              <div class="dpBDtitle"> <!--공유클래스-->
                                  담보정보
                              </div>
                              <div class="dpBDInfos">
                                  <div class="collateralChart">
                                      <div class="ccGraph">
                                              <div class="roundG"></div>
                                      </div>
                                      <div class="cc">
                                              <div class="expect">
                                                  <div class="expTitle">
                                                      준공 후 예상가치
                                                  </div>
                                                  <div class="expVal">
                                                      230.7억원
                                                  </div>
                                                  <div class="clear"></div>
                                             </div>
                                             <div class="elemGroup">
                                                 <div class="ccElem">
                                                     <div class="colorBox"></div>
                                                     <div class="elemType">
                                                         모집완료
                                                     </div>
                                                     <div class="elemVal">
                                                         49.2억원
                                                     </div>
                                                     <div class="clear"></div>
                                                 </div>
                                                 <div class="ccElem">
                                                     <div class="colorBox"></div>
                                                     <div class="elemType">
                                                         aaaa
                                                     </div>
                                                     <div class="elemVal">
                                                         bbbb
                                                     </div>
                                                     <div class="clear"></div>
                                                 </div>
                                                 <div class="ccElem">
                                                     <div class="colorBox"></div>
                                                     <div class="elemType">
                                                         cccc
                                                     </div>
                                                     <div class="elemVal">
                                                         dddd
                                                     </div>
                                                     <div class="clear"></div>
                                                 </div>
                                                 <div class="ccElem">
                                                     <div class="colorBox"></div>
                                                     <div class="elemType">
                                                         eeee
                                                     </div>
                                                     <div class="elemVal">
                                                         ffff
                                                     </div>
                                                     <div class="clear"></div>
                                                 </div>
                                             </div>
                                             <div class="clear"></div>
                                      </div>
                                      <div class="clear"></div>
                                  </div>
                                  <div class="ccWarn">
                                      대출자의 요청에 의해 모집금액이 변경될 수 있으며, 이로 인해 펀딩이 조기 마감될 수 있습니다.
                                  </div>
                              </div>
                          </div >
                          <div class="dpShortenInfos">    <!--클래스 공유하지만 다른영역-->
                              <div class="dpBDtitle"> <!--공유클래스-->
                                  테라펀딩 평가등급
                              </div>
                              <div class="dpBDInfos">
                                  <div class="dpEvaluation">
                                      <div class="dpGradeScore">
                                          <p><b>B1</b> (66 / 100점)</p>
                                      </div>
                                      <div class="dpGrades">
                                          <div class="dpGL">A1</div>
                                          <div class="dpGL">A2</div>
                                          <div class="dpGL">A3</div>
                                          <div class="dpGL">B1</div>
                                          <div class="dpGL">B2</div>
                                          <div class="dpGL">B3</div>
                                          <div class="dpGL">C1</div>
                                          <div class="dpGL">C2</div>
                                          <div class="dpGL">C3</div>
                                          <div class="dpGL">D1</div>
                                          <div class="dpGL">D2</div>
                                          <div class="dpGL">D3</div>
                                          <div class="dpGL">E1</div>
                                          <div class="dpGL">E2</div>
                                          <div class="dpGL">E3</div>
                                          <div class="clear"></div>
                                      </div>
                                      <div class="dpVisualize">
                                          <div class="dpVis" style="background-color:#57aafe"></div>
                                          <div class="dpVis" style="background-color:#61aafd"></div>
                                          <div class="dpVis" style="background-color:#6bb3fc"></div>
                                          <div class="dpVis" style="background-color:#75b8fb"></div>
                                          <div class="dpVis" style="background-color:#7fbcfa"></div>
                                          <div class="dpVis" style="background-color:#89c0f8"></div>
                                          <div class="dpVis" style="background-color:#93c5f7"></div>
                                          <div class="dpVis" style="background-color:#92caf7"></div>
                                          <div class="dpVis" style="background-color:#a8cff6"></div>
                                          <div class="dpVis" style="background-color:#b1d3f4"></div>
                                          <div class="dpVis" style="background-color:#bbd7f3"></div>
                                          <div class="dpVis" style="background-color:#c6dcf3"></div>
                                          <div class="dpVis" style="background-color:#d0e1f2"></div>
                                          <div class="dpVis" style="background-color:#dae5f0"></div>
                                          <div class="dpVis" style="background-color:#e4e9ef"></div>
                                          <div class="clear"></div>
                                      </div>
                                      <div class="dpStandard">
                                          <div class="dpUG">상위등급</div>
                                          <div class="dpLG">하위등급</div>
                                          <div class="clear"></div>
                                      </div>
                                      <div class="dpEvalDesc">
                                          <div class="dpEvalTopR">
                                              <div class="dpETRelem">항목</div>
                                              <div class="dpETRelem">설명</div>
                                              <div class="dpETRelem">평가점수 </div>
                                              <div class="clear"></div>
                                          </div>
                                          <div class="dpEvalSection">
                                              <div class="dpESR">
                                                  <div class="dpType">
                                                      안정성<img src="" />
                                                  </div>
                                                  <div class="dpDesc">
                                                        담보인정비율(LTV), 자기자본(Equity) 등
                                                  </div>
                                                  <div class="dpGradingG">
                                                      <div class="dpFillG dpActiveG"></div><div class="dpFillG dpActiveG"></div><div class="dpFillG"></div><div class="dpFillG"></div><div class="dpFillG"></div>
                                                      <div class="clear"></div>
                                                  </div>
                                                  <div class="clear"></div>
                                              </div>
                                              <div class="dpESR">
                                                  <div class="dpType">
                                                      수익성<img src="" />
                                                  </div>
                                                  <div class="dpDesc">
                                                        투자수익률(ROI), 자기자본이익률(ROE) 등
                                                  </div>
                                                  <div class="dpGradingG">
                                                      <div class="dpFillG"></div><div class="dpFillG"></div><div class="dpFillG"></div><div class="dpFillG"></div><div class="dpFillG"></div>
                                                      <div class="clear"></div>
                                                  </div>
                                                  <div class="clear"></div>
                                              </div>
                                              <div class="dpESR">
                                                  <div class="dpType">
                                                      시장성<img src="" />
                                                  </div>
                                                  <div class="dpDesc">
                                                        지역여건, 입지여건, 시장환경분석 등
                                                  </div>
                                                  <div class="dpGradingG">
                                                      <div class="dpFillG"></div><div class="dpFillG"></div><div class="dpFillG"></div><div class="dpFillG"></div><div class="dpFillG"></div>
                                                      <div class="clear"></div>
                                                  </div>
                                                  <div class="clear"></div>
                                              </div>
                                          </div>
                                      </div>
                                  </div>
                              </div>
                          </div >

                          <div class="dpShortenInfos">    <!--클래스 공유하지만 다른영역-->
                              <div class="dpBDtitle"> <!--공유클래스-->
                                  대출자 신용등급
                              </div>
                              <div class="dpBDInfos">
                                  <div class="dpEvaluation">
                                      <div class="dpGradeScore">
                                          <p><b>3등급</b> (840 / 1000점)</p>
                                      </div>
                                      <div class="dpCredit">
                                          <div class="dpCGL">1</div>
                                          <div class="dpCGL">2</div>
                                          <div class="dpCGL">3</div>
                                          <div class="dpCGL">4</div>
                                          <div class="dpCGL">5</div>
                                          <div class="dpCGL">6</div>
                                          <div class="dpCGL">7</div>
                                          <div class="dpCGL">8</div>
                                          <div class="dpCGL">9</div>
                                          <div class="dpCGL">10</div>
                                          <div class="clear"></div>
                                      </div>
                                      <div class="dpCreditVis">
                                          <div class="dpCVisR">
                                              <div class="dpCVisEmpty"></div>
                                              <div class="dpCVisHalf dpCVdisNone">
                                                  <div class="dpCVHEmpty"></div>
                                                  <div class="dpCVHFull"></div>
                                                  <div class="clear"></div>
                                              </div>
                                              <div class="dpCVisFull dpCVdisNone"></div> <!--1등급-->
                                          </div>
                                          <div class="dpCVisR">
                                              <div class="dpCVisEmpty"></div>
                                              <div class="dpCVisHalf dpCVdisNone">
                                                  <div class="dpCVHEmpty"></div>
                                                  <div class="dpCVHFull"></div>
                                                  <div class="clear"></div>
                                              </div>
                                              <div class="dpCVisFull dpCVdisNone"></div> <!--2등급-->
                                          </div>
                                          <div class="dpCVisR">
                                              <div class="dpCVisEmpty dpCVdisNone"></div>
                                              <div class="dpCVisHalf">
                                                  <div class="dpCVHEmpty"></div>
                                                  <div class="dpCVHFull"></div>
                                                  <div class="clear"></div>
                                              </div>
                                              <div class="dpCVisFull dpCVdisNone"></div> <!--3등급-->
                                          </div>
                                          <div class="dpCVisR">
                                              <div class="dpCVisEmpty dpCVdisNone"></div>
                                              <div class="dpCVisHalf dpCVdisNone">
                                                  <div class="dpCVHEmpty"></div>
                                                  <div class="dpCVHFull"></div>
                                                  <div class="clear"></div>
                                              </div>
                                              <div class="dpCVisFull"></div> <!--4등급-->
                                          </div>
                                          <div class="dpCVisR">
                                              <div class="dpCVisEmpty dpCVdisNone"></div>
                                              <div class="dpCVisHal dpCVdisNonef">
                                                  <div class="dpCVHEmpty"></div>
                                                  <div class="dpCVHFull"></div>
                                                  <div class="clear"></div>
                                              </div>
                                              <div class="dpCVisFull"></div> <!--5등급-->
                                          </div>
                                          <div class="dpCVisR">
                                              <div class="dpCVisEmpty dpCVdisNone"></div>
                                              <div class="dpCVisHalf dpCVdisNone">
                                                  <div class="dpCVHEmpty"></div>
                                                  <div class="dpCVHFull"></div>
                                                  <div class="clear"></div>
                                              </div>
                                              <div class="dpCVisFull"></div> <!--6등급-->
                                          </div>
                                          <div class="dpCVisR">
                                              <div class="dpCVisEmpty dpCVdisNone"></div>
                                              <div class="dpCVisHalf dpCVdisNone">
                                                  <div class="dpCVHEmpty"></div>
                                                  <div class="dpCVHFull"></div>
                                                  <div class="clear"></div>
                                              </div>
                                              <div class="dpCVisFull"></div> <!--7등급-->
                                          </div>
                                          <div class="dpCVisR">
                                              <div class="dpCVisEmpty dpCVdisNone"></div>
                                              <div class="dpCVisHalf dpCVdisNone">
                                                  <div class="dpCVHEmpty"></div>
                                                  <div class="dpCVHFull"></div>
                                                  <div class="clear"></div>
                                              </div>
                                              <div class="dpCVisFull"></div> <!--8등급-->
                                          </div>
                                          <div class="dpCVisR">
                                              <div class="dpCVisEmpty dpCVdisNone"></div>
                                              <div class="dpCVisHalf dpCVdisNone">
                                                  <div class="dpCVHEmpty"></div>
                                                  <div class="dpCVHFull"></div>
                                                  <div class="clear"></div>
                                              </div>
                                              <div class="dpCVisFull"></div> <!--9등급-->
                                          </div>
                                          <div class="dpCVisR">
                                              <div class="dpCVisEmpty dpCVdisNone"></div> <!--등급X-->
                                              <div class="dpCVisHalf dpCVdisNone">  <!--10등급진입중-->
                                                  <div class="dpCVHEmpty"></div>
                                                  <div class="dpCVHFull"></div>
                                                  <div class="clear"></div>
                                              </div>
                                              <div class="dpCVisFull"></div> <!--10등급-->
                                          </div>
                                          <div class="clear"></div>
                                      </div>
                                      <div class="dpCStandard">
                                          <div class="dpCUG">상위등급</div>
                                          <div class="dpCLG">하위등급</div>
                                          <div class="clear"></div>
                                      </div>
                                      <div class="dpCinfoDesc">
                                          <div class="dpCbox">
                                              <div class="dpCDesc">체무불이행</div>
                                              <div class="dpCValue"><p><b>0</b>원</p></div>
                                          </div>
                                          <div class="dpCbox">
                                              <div class="dpCDesc">신용채무</div>
                                              <div class="dpCValue"><p><b>23,990,000</b>원</p></div>
                                          </div>
                                          <div class="dpCbox">
                                              <div class="dpCDesc">담보채무</div>
                                              <div class="dpCValue"><p><b>0</b>원</p></div>
                                          </div>
                                          <div class="dpCbox">
                                              <div class="dpCDesc">보증채무</div>
                                              <div class="dpCValue"><p><b>0</b>원</p></div>
                                          </div>
                                          <div class="clear"></div>
                                      </div>
                                      <div class="dpCreditMou">※ 제공 : 나이스신용정보 / KCB</div>
                                  </div>
                              </div>
                          </div >

                          <div class="dpShortenInfos">    <!--클래스 공유하지만 다른영역-->
                              <div class="dpBDtitle"> <!--공유클래스-->
                                  투자시 유의사항
                              </div>
                              <div class="dpBDInfos">
                                  <li class="dpBDwarn">본 투자상품은 (주)테라크라우드대부가 취급한 대출채권에 대한 원리금수취권 투자입니다.</li>
                                  <li class="dpBDwarn">본 금융투자상품의 투자는 회사의 권유 없이 고객님의 판단에 의해 이루어집니다.</li>
                                  <li class="dpBDwarn">대출채권의 특성 상, 차입자가 대출금을 조기 상환할 경우 만기일 보다 수 개월 일찍 중도 상환될 수 있습니다.</li>
                                  <li class="dpBDwarn">투자상품의 취소는 펀딩 마감 전까지 가능하며 본 건 모집금액이 마감된 이후에는 투자 취소가 불가합니다.</li>
                                  <li class="dpBDwarn">대출 만기 도래 전 본 투자상품의 채권 및 원리금 수취권의 일부 또는 전체에 대하여 인수 의사가 있는 법인/기관이 있는 경우 회사는 해당 권리를 양도할 수 있으며 이때 투자금이 조기 상환될 수 있습니다.</li>
                                  <li class="dpBDwarn">차입자는 대출 만기 도래 전 대출 연장을 신청할 수 있고 회사는 차입자가 이자를 납부할 능력이 있고 채무 건정성이 확보되는 전제하에 대출 연장을 승인할 수 있습니다. 대출이 연장될 경우 대출 연장을 위한 신규 투자상품이 오픈되며, 투자금 모집이 완료되면 기존 투자자들의 투자금이 상환됩니다. 단, 투자금 모집이 지연되는 경우 상환일이 만기일 보다 늦어질 수 있으며 이때 24%의 연체이자가 일할 계산되어 지급됩니다.</li>
                                  <li class="dpBDwarn">차입자의 대출 만기가 도래 되었음에도 불구하고 이자를 납부할 능력이 없거나 채무 건정성이 악화된 경우 대출금 상환이 불가하여 연체가 발생할 수 있으며, 이때 회사는 법적 절차에 따른 채권추심을 통해 투자금 회수 절차를 진행합니다. 경매, 공매 등 법적 절차에 의해 채권 회수에 소요되는 시간은 최소 3개월에서 12개월 정도 소요됩니다.</li>
                                  <li class="dpBDwarn">본 투자상품은 부동산이 일부 담보로 제공되나 채무 불이행으로 인한 경매, 공매 등의 환가절차 과정에서 대출원금 이하로 매각될 가능성이 있고 이때 투자원금의 일부 손실이 발생할 수 있습니다.</li>
                                  <li class="dpBDwarn">회사는 본 건 투자와 관련하여 원금과 수익률을 확정 보장하지 않으므로 손실위험을 인지하고 투자에 신중한 결정 바랍니다.</li>
                              </div>
                          </div >
                      </div>





                      <div class="dpProfitCal" style="display:none">   <!-- 수익계산 버튼 클릭시-->
                          <div class="dpShortenInfos">    <!--클래스 공유하지만 다른영역-->
                              <div class="dpBDInfos">
                                  <div class="dpProfitExpCal">
                                      <div class="dpPECtitle">투자예정금액 입력</div>
                                      <div class="dpMoneyInputPos">
                                          <input class="dpinputL" type="text" name="dpInvAmount" placeholder="₩" />
                                          <div class="dpinputR">만원</div>
                                          <button>확인</button>
                                          <div class="clear"></div>
                                          <div class="dpPECinst">※ 최소금액 10만원부터 10만원 단위로 투자하실 수 있습니다.</div>
                                      </div>
                                      <div class="dpPBschedule"><p>상환 예정표 (대출실행일: <b>2018.06.21</b> 기준)</p></div>
                                      <div class="dpPECchart">
                                          <div class="dpPECCr">
                                              <div class="dpPECCRcol">
                                                  <div class="dpPECsec">만기상환일</div>
                                                  <div class="dpPECval">2019.07.03</div>
                                                  <div class="clear"></div>
                                              </div>
                                              <div class="dpPECCRcol">
                                                  <div class="dpPECsec">투자원금</div>
                                                  <div class="dpPECval">1,000,000원</div>
                                                  <div class="clear"></div>
                                              </div>
                                              <div class="dpPECCRcol">
                                                  <div class="dpPECsec">플랫폼이용료</div>
                                                  <div class="dpPECval">12,300원</div>
                                                  <div class="clear"></div>
                                              </div>
                                              <div class="clear"></div>
                                          </div>
                                          <div class="dpPECCr">
                                              <div class="dpPECCRcol">
                                                  <div class="dpPECsec">수익금(세전)</div>
                                                  <div class="dpPECval">131,184원</div>
                                                  <div class="clear"></div>
                                              </div>
                                              <div class="dpPECCRcol">
                                                  <div class="dpPECsec">세금(이자소득세+주민세)</div>
                                                  <div class="dpPECval">35,890원</div>
                                                  <div class="clear"></div>
                                              </div>
                                              <div class="dpPECCRcol">
                                                  <div class="dpPECsec">수익금(세후)</div>
                                                  <div class="dpPECval">95,294원</div>
                                                  <div class="clear"></div>
                                              </div class="dpPECCRcol">
                                              <div class="clear"></div>
                                          </div>
                                      </div>
                                  </div>
                              </div>
                          </div >
                          <div class="dpShortenInfos">    <!--클래스 공유하지만 다른영역-->
                              <div class="dpBDInfos">
                                  <div class="dpMPtitle">
                                      <div class="dpMPTl"><p>월별 수익금 지급 예정표 (대출실행일: <b>2018.06.21</b> 기준)</p></div>
                                      <div class="dpMPTr link_btn">펼쳐보기-</div>
                                      <div class="dpMPTr link_btn" style="display:none">닫기-</div>
                                      <div class="clear"></div>
                                  </div>
                                  <div class="dpMonthlyProfit">
                                      <div class="dpMPR">        <!--처음은 기준-->
                                          <div class="dpMPC">회차</div>
                                          <div class="dpMPC">지급일</div>
                                          <div class="dpMPC">이용일수</div>
                                          <div class="dpMPC">수익금(세전)</div>
                                          <div class="dpMPC">이자소득세</div>
                                          <div class="dpMPC">주민세</div>
                                          <div class="dpMPC">수익금(세후)</div>
                                          <div class="dpMPC">플랫폼이용료</div>
                                          <div class="clear"></div>
                                      </div>
                                      <div class="dpMPR">
                                          <div class="dpMPC">99회차</div>
                                          <div class="dpMPC">2018.07.01</div>
                                          <div class="dpMPC">10일</div>
                                          <div class="dpMPC">3,480원</div>
                                          <div class="dpMPC">870원</div>
                                          <div class="dpMPC">80원</div>
                                          <div class="dpMPC">2,530원</div>
                                          <div class="dpMPC">0원</div>
                                          <div class="clear"></div>
                                      </div>

                                      <div class="dpMPR">   <!--마지막은 총계-->
                                          <div class="dpMPC">총합계</div>
                                          <div class="dpMPC">3,480원</div>
                                          <div class="dpMPC">870원</div>
                                          <div class="dpMPC">80원</div>
                                          <div class="dpMPC">2,530원</div>
                                          <div class="dpMPC">0원</div>
                                          <div class="clear"></div>
                                      </div>
                                  </div>
                              </div>
                          </div >
                          <div class="dpShortenInfos">    <!--클래스 공유하지만 다른영역-->
                              <div class="dpBDtitle dpGT"> <!--공유클래스-->
                                  테라펀딩 투자 수익금 및 원금 지급 가이드
                              </div>
                              <div class="dpBDInfos">
                                  <div class="dpGuideR">
                                      <div class="dpGsection">수익금 지급</div>
                                      <div class="dpGdesc">
                                          <div>수익금은 대출실행일부터 월 단위로 일할 계산되며, 매월 첫 영업일에 세금 원천징수 후 지급됩니다.</div>
                                          <div>※ 첫 수익금 지급일 안내 : 매월 1 ~ 24일에 대출실행된 투자상품은 다음달 첫 영업일 매월 25일 ~ 말일에 대출실행된 투자상품은 다다음달 첫 영업일</div>
                                      </div>
                                      <div class="clear"></div>
                                  </div>
                                  <div class="dpGuideR">
                                      <div class="dpGsection">원금상환</div>
                                      <div class="dpGdesc">
                                          <div>원금만기일시상환 상품으로 대출자가 대출금 상환 즉시 투자자에게 원금이 상환됩니다.</div>
                                      </div>
                                      <div class="clear"></div>
                                  </div>
                                  <div class="dpGuideR">
                                      <div class="dpGsection">세금</div>
                                      <div class="dpGdesc">
                                          <div>이자 소득에 대한 세금 원천징수 후 차감된 금액(세후)이 테라펀딩 가상계좌로 입금됩니다.</div>
                                          <div>※ 이자소득세율 : 이자소득세 25% + 주민세 2.5% = 27.5%</div>
                                      </div>
                                      <div class="clear"></div>
                                  </div>
                                  <div class="dpGuideR">
                                      <div class="dpGsection">플랫폼 이용료</div>
                                      <div class="dpGdesc">
                                          <div>플랫폼 이용료는 투자기간에 따라 일할 계산되며, 원금상환시 차감됩니다. (예시) 투자기간 6개월인 상품의 경우 0.6% / 8개월인 상품의 경우 0.8%</div>
                                          <div>※ 플랫폼 이용료 : 투자금 X 1.2% / 365일 X 이용일수</div>
                                      </div>
                                      <div class="clear"></div>
                                  </div>
                              </div>
                          </div >
                      </div>



                  </div>

                  <div class="dpMovingBanner">
                      <div class="dpMainInfo">
                          <div class="dpMIProgBar"></div>
                          <div class="dpMIEmptyBar"></div>
                          <!--완료-->
                          <div class="dpMIpaddingFinish">
                              <div class="dpMIps">
                                  <div class="dpProgPercent">
                                      <b>100</b>%
                                  </div>
                              </div>

                              <div class="dpFinancialRate">
                                  <b>11억원</b>/11억원
                              </div>
                              <div class="dpPeopleCounter">
                                  1944명참여
                              </div>
                              <div class="dpInnerBox">
                                  <div class="dpIBP1">본 상품은 성공적으로 모집 완료되어</div>
                                  <div class="dpIBP2">상환중입니다.</div>
                                  <button class="dpInnerBut">다른 투자 상품 보기</button>
                              </div>
                          </div>
                          <!--모집중-->

                          <div class="dpMIpaddingFunding">
                              <div class="dpMIps">
                                  <div class="dpProgPercent">
                                      <b>50</b>%
                                  </div>
                              </div>

                              <div class="dpFinancialRate">
                                  <b>2억 7,500백만원</b>/5억 5천만원
                              </div>
                              <div class="dpPeopleCounter">
                                  1944명참여
                              </div>
                              <div class="dpExpInt">
                                  <div><p><b>100만원 투자</b>시 예상수익(세전)은</p></div>
                                  <div><p><b>총 131,532원</b>입니다.</p></div>
                              </div>
                              <div class="dpInvestPos">
                                  <div class="dpInvestL">
                                      <div class="dpMoneyInputPos">
                                          <input class="dpinputL" type="text" name="dpInvAmount" placeholder="₩" />
                                          <div class="dpinputR">만원</div>
                                          <div class="clear"></div>
                                      </div>
                                      <div class="dpBGruopPos">
                                          <button>10만</button>
                                          <button>100만</button>
                                          <button>1000만</button>
                                          <div class="clear"></div>
                                      </div>

                                  </div>
                                  <button class="dpInnerBut">투자하기</button>
                                  <div class="clear"></div>
                              </div>

                          </div>
                      </div>
                  </div>

              </div>
              </form>
            </div>
          </div>
      </body>
</html>
