<?php
  include_once('./inc/vs.php');
?>



<!doctype html>
<html itemscope="" itemtype="http://schema.org/WebPage" lang="ko">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title></title>
    <link rel="stylesheet" type="text/css" href="./css/reset.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.2/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="./css/style.css?<?=$ver?>">

</head>
<body>
    <div id="collateralPage">
        <div id="colContents">
            <div class="colBox">
                <form method="get">
                    <div class="colbInst1">아래 항목에 따라, 신청서를 작성해 주시면 확인후 담당자가 세부 내용에 대한 설명과 대출 진행을 도와드릴 수 있도록 연락드립니다.</div>
                    <div class="colbInst2">*필수사항</div>
                    <div class="colbSection">회사명 *</div>
                    <div class="colbIpos">
                        <input class="colbInput" type="text" name="collaComp" placeholder="회사명을 적어주세요." />
                    </div>
                    <div class="colbSection">담당자 성함 *</div>
                    <div class="colbIpos">
                    <input class="colbInput" type="text" name="collaName" placeholder="성함을 적어주세요." />
                    </div>
                    <div class="colbSection">담당자 전화번호 *</div>
                    <div class="colbIpos">
                    <input class="colbInput" type="text" name="collaPhone" placeholder="전화번호를 적어주세요." />
                    </div>
                    <div class="colbSection">담당자 이메일 *</div>
                    <div class="colbIpos">
                    <input class="colbInput" type="email" name="collaEmail" placeholder="이메일 주소를 적어주세요." />
                    </div>
                    <div class="colbSection">법인/개인 구분 *</div>
                    <div class="colbIpos">
                    <select>
                        <option>법인</option>
                        <option>개인</option>
                    </select>
                    </div>
                    <div class="colbSection">담보물 현재 시세 *</div>
                    <div class="colbIpos">
                        <input class="colbInput" type="text" name="collaMarketP" placeholder="숫자를 적어주세요." />
                    </div>
                    <div class="colbSection">대출 희망 금액 *</div>
                    <div class="colbIpos">
                        <input class="colbInput" type="text" name="collaAmount" placeholder="숫자를 적어주세요." />
                    </div>
                    <div class="colbSection">담보물 *</div>
                    <div class="colbIpos">
                        <input class="colbInput" type="text" name="collaProduct" placeholder="물품명을 적어주세요." />
                    </div>
                    <div class="colbSection">담보물 설명 *</div>
                    <div class="colbIpos">
                        <textarea  rows="15" class="colbTA" name="collaPDesc"></textarea/>
                    </div>
                    <div class="colbSection">자금용도 *</div>
                    <div class="colbIpos">
                        <textarea  rows="15" class="colbTA" name="collaPurpose" /></textarea/>
                    </div>
                    <div class="colbSection">※개인정보수집 및 이용 동의</div>
                    <div class="colbInst1">수집된 개인정보는 대출 상담을 위해 사용되며, 수집된 후 1년간 보유 및 이용됩니다.</div>
                    <div class="colbInst1">수집된 개인정보는 제 3자에게 제공되지 않으며, 수집 및 이용에 관한 동의를 하지 않을경우 접수가 불가합니다.</div>
                    <div class="colbCBR">
                        <input type="checkbox" /> 개인정보 수집 및 이용에 동의합니다.
                    </div>
                    <div class="colbSubmit link_btn">대출 가능여부 확인하기</div>

                </form>
            </div>
            <div class="colbWarn">
                <div class="colbWelem">대출금리 연 18%이내 (연체금리 연25%이내)플랫폼 이용료 외 취급수수료 등 기타 부대비용은 없습니다. 중개수수료를 요구하거나 받는 행위는 불법입니다.</div>
                <div class="colbWelem">과도한 빚은 당신에게 큰 불행을 안겨줄 수 있습니다.</div>
            </div>
        </div>
    </div>
</body>
</html>
