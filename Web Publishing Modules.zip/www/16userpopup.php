<?php
  include_once('./inc/vs.php');
?>


<!doctype html>
<html itemscope="" itemtype="http://schema.org/WebPage" lang="ko">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title></title>
    <link rel="stylesheet" type="text/css" href="./css/reset.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.2/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="./css/style.css?<?=$ver?>">

</head>
<body>
    <div id="UserPopUpPage">
        <div id="upuContents">
            <div class="upuBox">
                <div class="upuAccCont">
                    <div class="upuAmountPos">
                        <div class="upuAl">예치금</div>
                        <div class="upuAr">0 원</div>
                        <div class="clear"></div>
                    </div>
                    <div class="upuAmountPos">
                        <div class="upuAl">포인트</div>
                        <div class="upuAr">0 P</div>
                        <div class="clear"></div>
                    </div>
                    <div class="upuAccTitle">예치금충전</div>
                    <div class="upuAccPos">
                        <div class="upuAccBank">신한은행</div>
                        <div class="upuAccNum">111-111111-11-111</div>
                        <div class="clear"></div>
                    </div>
                    <div class="upuAccOwner">(펀다XXX)</div>
                    <div class="upuAmountPos">
                        <div class="upuAl">잔여 투자 원금</div>
                        <div class="upuAr">0원</div>
                        <div class="clear"></div>
                    </div>
                    <div class="upuAmountPos">
                        <div class="upuAl">잔여 투자 한도 <img src="./img/16userpopupicon01.png"<?=$ver?> /></div>
                        <div class="upuAr">20,000,000 원</div>
                        <div class="clear"></div>
                    </div>
                    <div class="upuAccExtB">투자한도 증액하기 &gt;</div>
                    <div class="upuRecCtitle">나의 추천인 코드</div>
                    <div class="upuAmountPos5">
                        <div class="upuAl">XV6C6</div>
                        <div class="upuAR">코드복사하기</div>
                        <div class="clear"></div>
                    </div>
                    <div class="upuEmpha">* 친구도 나도 +2,000 포인트</div>
                    <div class="upuExt">더보기 <img src="./img/16userpopupicon02.png"<?=$ver?> /></div>
                </div>
                <div class="upuUICont">
                    <div class="upuEditUI">회원정보 변경</div>
                    <div class="upuLogOut">로그아웃</div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
