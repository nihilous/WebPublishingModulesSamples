<?php
  include_once('./inc/vs.php');
?>



<!doctype html>
<html itemscope="" itemtype="http://schema.org/WebPage" lang="ko">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title></title>
    <link rel="stylesheet" type="text/css" href="./css/reset.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.2/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="./css/style.css?<?=$ver?>">

</head>
<body>


    <div id="IntroducePage">
        <div id="intContents">
            <div class="intBox">
                <div class="intR">
                    <div class="intr1L">
                        <img src="./img/27companyr1l.png?<?=$ver?>" />
                    </div>
                    <div class="intr1R">
                        <img src="./img/27companyr1r.png?<?=$ver?>" />
                    </div>
                    <div class="clear"></div>
                </div>

                <div class="intR">
                    <div class="intr2L">
                        <div><p>투자자가 있어야 대출자가 있을수 있습니다.</p></div>
                        <div><p>또, 대출자가 있어야 투자자가 있을 수 있습니다.</p></div>
                        <br />
                        <div><p>금리가 높아지면 투자자는 늘지만 대출자는 줄어듭니다.</p></div>
                        <div><p>금리가 낮아지면 대출자는 늘지만 투자자는 줄어듭니다.</p></div>
                        <br />
                        <div>
                            <h4>투자자와 대출자 <div class="intr2lP1"></div>모두가 만족할 수 있는 POINT를 잡아 <div class="intr2lP2"></div>상생할 수 있는 금융을 하겠습니다.</h4>
                        </div>

                    </div>
                    <div class="intr2R">
                        <img src="./img/27companyr2r.png?<?=$ver?>" />
                    </div>
                    <div class="clear"></div>
                </div>

                <div class="intR">
                    <div class="intr3Top">
                        <div><h4>플레이핀테크는 항상 투자자들이 안심하고 투자할 수 있는 환경을 조성하고 있습니다.</h4></div>
                        <div><p>확실한 환가성이 있는 동산들만 엄선하여 자체창고에서 직접 보관, 관리하며 LTV를 보수적으로 낮게 잡아 리스크를 최소화합니다.</p></div>
                        <div><p>또한, 창고에는 CCTV가 설치되어 있어 언제 어디서나 실시간으로 확인 가능합니다.</p></div>
                    </div>
                    <div class="intr3Low">
                        <div class="intrLowI1">
                            <img src="./img/27companyr3l.png?<?=$ver?>" />
                        </div>
                        <div class="intrLowI2">
                            <img src="./img/27companyr3m.png?<?=$ver?>" />
                        </div>
                        <div class="intrLowI3">
                            <img src="./img/27companyr3r.png?<?=$ver?>" />
                        </div>
                        <div class="clear"></div>
                    </div>

                </div>

                <div class="intR">
                    <div class="intr4Top">
                        <div><h3>왜 타업체보다 수익률이 낮나요?</h3></div>
                        <br />
                        <div><h4>수익률은 높은데 부실, 연체가 발생한다면!?</h4></div>
                        <div><h4>타사대비 조금 낮더라도 더 안전한 상품들만 엄선하여 제공하고 있습니다.</h4></div>
                        <div><h4>저금리에 시달리는 투자자, 고금리에 시달리는 대출자 모두에게 득이 되는 상생하는 중금리 P2P 플레이핀테크!</h4></div>
                        <div><h4>여러분의 꿈과 희망이 되겠습니다.</h4></div>
                    </div>
                    <div class="intr4Low">
                        <div class="intr4lR">
                            <div class="intr4lrT"><h4>1. 수익률이 낮은 만큼 더 많은 대출자들이 모이고 더 다양한 투자상품 제공</h4></div>
                            <div class="intr4lrM"><h4>2. 시장 전반의 안전성이 높아져 더 많은 투자자들이 유입</h4></div>
                            <div class="intr4lrL"><h4>3. P2P 시장이 커지는 선순환</h4></div>
                        </div>
                        <div class="intr4lL">
                            <img src="./img/27companyr4l.png?<?=$ver?>" />
                        </div>
                        <div class="clear"></div>
                    </div>

                </div>
                <div class="intR">
                    <div class="intr5top">
                        <div class="intr5tTitle"><h3>플레이핀테크 투자심의자문위원회</h3></div>
                        <div class="intr5tDesc"><p>플레이핀테크의 모든 투자상품은10인으로 구성된 투자 심의자문위원회를 통해 최적의 투자상품을 제안합니다.</p></div>
                        <div class="intr5tCont">
                            <div class="intr5tCL">
                                <div class="intCounselMem"><p><b>홍길동 이사_</b>전 삼일회계법인 전무</p></div>
                                <div class="intCounselMem"><p><b>홍길동 이사_</b>전 삼일회계법인 전무</p></div>
                                <div class="intCounselMem"><p><b>홍길동 이사_</b>전 삼일회계법인 전무</p></div>
                                <div class="intCounselMem"><p><b>홍길동 이사_</b>전 삼일회계법인 전무</p></div>
                                <div class="intCounselMem"><p><b>홍길동 이사_</b>전 삼일회계법인 전무</p></div>
                            </div>
                            <div class="intr5tCR">
                                <div class="intCounselMem"><p><b>홍길동 이사_</b>전 삼일회계법인 전무</p></div>
                                <div class="intCounselMem"><p><b>홍길동 이사_</b>전 삼일회계법인 전무</p></div>
                                <div class="intCounselMem"><p><b>홍길동 이사_</b>전 삼일회계법인 전무</p></div>
                                <div class="intCounselMem"><p><b>홍길동 이사_</b>전 삼일회계법인 전무</p></div>
                                <div class="intCounselMem"><p><b>홍길동 이사_</b>전 삼일회계법인 전무</p></div>
                            </div>
                            <div class="intr5tCM">
                                <img src="./img/27investcounsel.png?<?=$ver?>" />
                            </div>
                            <div class="clear"></div>
                        </div>
                    </div>
                    <div class="intr5mid">
                        <div class="intr5mUp">
                            <div class="intr5mLB">
                                카카오은행의<div class="intr5muChanger"></div>자금신탁관리
                            </div>
                            <div class="intr5mRB">
                                <div><h4>투자자분들의 예치금/투자금/상환금 일체를 카카오은행이 직접 관리하므로 안전합니다.</h4></div>
                                <div><p>플레이핀테크는 투자자분들의 예치금/투자금/상환금에 대해 조회만 가능하며 인출, 이체의 권한이 없습니다.</p></div>
                            </div>
                            <div class="clear"></div>
                        </div>
                        <div class="intr5mDown">
                            <div class="intr5mLB">
                                안전 시스템 구현
                            </div>
                            <div class="intr5mRB">
                                <div><h4>플레이핀테크의 홈페이지는 한국인터넷진흥원(KISA)의 웹 취약점검을 무결점으로 통과하였습니다.</h4></div>
                                <div><p>플레이핀테크의 SSL통신정보보안수준은 A+입니다. (www.sslabs.com의 서버테스트 기준)</p></div>
                            </div>
                            <div class="clear"></div>
                        </div>
                    </div>
                    <div class="intr5low">
                        <div class="intr5lMOU"><img src="./img/27moulogo1.png?<?=$ver?>" /></div>
                        <div class="intr5lMOU"><img src="./img/27moulogo2.png?<?=$ver?>" /></div>
                        <div class="intr5lMOU"><img src="./img/27moulogo3.png?<?=$ver?>" /></div>
                        <div class="intr5lMOU"><img src="./img/27moulogo4.png?<?=$ver?>" /></div>
                        <div class="intr5lMOU"><img src="./img/27moulogo5.png?<?=$ver?>" /></div>
                        <div class="intr5lMOU"><img src="./img/27moulogo6.png?<?=$ver?>" /></div>
                        <div class="intr5lMOU"><img src="./img/27moulogo7.png?<?=$ver?>" /></div>
                        <div class="intr5lMOU"><img src="./img/27moulogo8.png?<?=$ver?>" /></div>
                        <div class="intr5lMOU"><img src="./img/27moulogo9.png?<?=$ver?>" /></div>
                        <div class="intr5lMOU"><img src="./img/27moulogo10.png?<?=$ver?>" /></div>
                        <div class="clear"></div>
                    </div>

                </div>
                <div class="intR">

                </div>
            </div>
        </div>
    </div>
</body>
</html>
