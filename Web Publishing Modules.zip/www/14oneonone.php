<?php
  include_once('./inc/vs.php');
?>

<!doctype html>
<html itemscope="" itemtype="http://schema.org/WebPage" lang="ko">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title></title>
    <link rel="stylesheet" type="text/css" href="./css/reset.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.2/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="./css/style.css?<?=$ver?>">

</head>
<body>
    <div id="OneOnOnePage">
        <div id="oooContents">
            <div class="oooCpos">
                <div class="oooQBox">
                    <div class="oooQTitle">
                        <img src="" />1:1 문의하기
                    </div>
                    <form method="post">
                    <div class="oooSection">제목</div>
                    <div class="oooIFpos">
                        <input class="oooInputField" type="text" name="oooTitle" placeholder="제목을 입력해주세요"/>
                    </div>
                    <div  class="oooSection">이메일</div>
                    <div class="oooIFpos">
                        <input class="oooInputField" type="email" name="oooMail" placeholder="답변받을 이메일을 입력해주세요"/>
                    </div>
                    <div class="oooSection">문의내용</div>
                    <div class="oooIFBpos">
                        <textarea rows="15" class="oooIFbig" name="oooQuestion" placeholder="문의내용을 입력해주세요"></textarea>
                    </div>
                    <div class="oooSection">문의 접수와 처리, 회신을 위한 최소한의 개인정보입니다. 동의를 필요로 합니다.</div>

                    <div class="oooAgreePos">
                        <div class="oooAPR">
                            <div class="oooAPC">수집항목</div>
                            <div class="oooAPmar"></div>
                            <div class="oooAPC">목적</div>
                            <div class="oooAPmar"></div>
                            <div class="oooAPC">보유기간</div>
                            <div class="oooAPmar"></div>
                            <div class="oooAPC">동의여부</div>
                            <div class="clear"></div>
                        </div>
                        <div class="oooAPR">
                            <div class="oooAPC">이메일</div>
                            <div class="oooAPmar"></div>
                            <div class="oooAPC">고객상담 및 불만처리 결과 회신</div>
                            <div class="oooAPmar"></div>
                            <div class="oooAPC">문의 처리 후 3년간 보관</div>
                            <div class="oooAPmar"></div>
                            <div class="oooAPC"><input type="checkbox" name="oooAgree" /> 동의</div>
                            <div class="clear"></div>
                        </div>
                    </div>
                    <button type="submit" class="oooAB">문의하기</button>
                    </form>
                </div>
                <div class="oooCInfos">
                    <div class="oooCIr">FUNDA</div>
                    <div class="oooCIr"><img src="./img/14oneononeimg.png"<?=$ver?> /></div>
                    <div class="oooCIr"><p><b>도움</b>이 필요하신가요?</p></div>
                    <div class="oooCIr">02-552-0360</div>
                    <div class="oooCIr">(fax: 02-6020-8474)</div>
                    <div class="oooCIr">월요일 ~ 금요일 10.00am - 6.00pm</div>
                    <div class="oooCIr"><img src="./img/09contactdirecticon01.png"<?=$ver?> />contact@funda.kr</div>
                </div>
                <div class="clear"></div>
            </div>
        </div>
    </div>
</body>
</html>
