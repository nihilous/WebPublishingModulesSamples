<?php
  include_once('./inc/vs.php');
?>

<!doctype html>
<html itemscope="" itemtype="http://schema.org/WebPage" lang="ko">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title></title>
    <link rel="stylesheet" type="text/css" href="./css/reset.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.2/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="./css/style.css?<?=$ver?>">

</head>
<body>
    <div id="loginPage">
        <div id="lpContents">
            <div class="lpBox">
                <form method="post">
                    <div class="lpTitle">테라펀딩 로그인</div>
                    <div class="lpBar"></div>
                    <div class="lpInputFields">
                        <div class="lpifL">
                            <div class="lpIsection">아이디</div>
                            <div class="lpIinputPos">
                                <input type="text" name="lpID" placeholder="아이디를 입력해주세요." />
                            </div>
                        </div>
                        <div class="lpifR">
                            <div class="lpPWsection">비밀번호</div>
                            <div class="lpPWinputPos">
                                <input class="" type="password" name="lpPW" placeholder="비밀번호를 입력해주세요" />
                            </div>
                        </div>
                        <div class="clear"></div>
                        <div class="lpCBpos">
                            <div class="lpCBl">
                                <input type="checkbox" name="lpSaveID" /> 아이디 저장
                            </div>
                            <div class="lpCBR">
                                <input type="checkbox" name="lpShowString"/> 입력문자 보이기
                            </div>
                            <div class="clear"></div>
                        </div>
                        <button type="submit" class="lpLoginB">로그인</button>
                    </div>
                    <div class="lpSocial">
                        <div class="lpSmallButton">Toss</div>
                        <div class="lpSmallButton">Facebook</div>
                        <div class="clear"></div>
                    </div>
                    <div class="lpMargin">
                        <div class="lpSepBar"></div>
                        <div class="lpInMargin">or</div>
                        <div class="lpSepBar"></div>
                        <div class="clear"></div>
                    </div>
                    <div class="lpPRpos">
                        <div class="lpSmallButton"><img src="" />아이디 찾기</div>
                        <div class="lpSmallButton"><img src="" />비밀번호 재설정</div>
                        <div class="clear"></div>
                    </div>
                    <div class="lpJoinPos">
                        <div class="lpJinst">아직 테라펀딩에 가입하지 않으셨나요?</div>
                        <a href="#"><div>회원가입</div></a>
                        <div class="clear"></div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</body>
</html>
