<?php
  include_once('./inc/vs.php');
?>



<!doctype html>
<html itemscope="" itemtype="http://schema.org/WebPage" lang="ko">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title></title>
    <link rel="stylesheet" type="text/css" href="./css/reset.css">
    <link rel="stylesheet" type="text/css" href="./css/errorsample.css?<?=$ver?>">

</head>
<body>
    <div id="errorSamplePage">
        <div id="errorContents">
            <div class="planPEvalElem">
                <div class="planPeeRo">
                    <div class="planPeeI">266호</div>
                    <div class="planPeeI">참한아구</div>
                    <div class="clear"></div>
                </div>
                <div class="planPeeRo"><img src="" />img</div>
                <div class="planPeeRo">
                    <div class="planPeeDisconNo">상환차수</div><!--display none-->
                    <div class="planPeeDisconYes">15/18</div>
                    <div class="planPeeDisconNo">상태</div><!--display none-->
                    <div class="planPeeDisconYes">상환중</div>
                    <div class="planPeeDisconNo">총상환금</div><!--display none-->
                    <div class="planPeeDisconYes">총 상환금: 11,037,053원</div>
                    <div class="clear"></div>
                </div>
                <div class="planPeeRo">상환금: 9,191,565원</div>
                <div class="planPeeRo">남은 상환금: 1,839,488원</div>
                <div class="clear"></div>
            </div>
        </div>
    </div>
</body>
</html>
