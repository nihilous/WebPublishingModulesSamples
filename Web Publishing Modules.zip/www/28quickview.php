<?php
  include_once('./inc/vs.php');
?>



<!doctype html>
<html itemscope="" itemtype="http://schema.org/WebPage" lang="ko">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title></title>
    <link rel="stylesheet" type="text/css" href="./css/reset.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.2/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="./css/style.css?<?=$ver?>">

</head>
<body>


    <div id="QuickViewPage">
        <div id="qvContents">
            <div class="qvBox">
                <div class="qvbTop">
                    <ul>
                        <div class="qvbFloater">
                            <li>
                                <div><img src="./img/28quickviewicn1.png?<?=$ver?>" /></div>
                                <div>
                                    <div><h3>자체 평가 기준</h3></div>
                                    <div>기술과 금융이 결합된 부동산 <div class="qvbChanger"></div>담보평가시스템이 공정/투명하게 평가합니다</div>
                                </div>
                            </li>
                            <li>
                                <div><img src="./img/28quickviewicn2.png?<?=$ver?>" /></div>
                                <div>
                                    <div><h3>신용 등급 영향 없음</h3></div>
                                    <div>대출 후에도 신용등급의 영향없이 기존대출의 <div class="qvbChanger"></div>금리에 영향을 미치지 않습니다</div>
                                </div>
                            </li>
                            <div class="clear"></div>
                        </div>
                        <div class="qvbFloater">
                            <li>
                                <div><img src="./img/28quickviewicn3.png?<?=$ver?>" /></div>
                                <div>
                                    <div><h3>합리적인 이율</h3></div>
                                    <div>개인과의 직거래로 대출자에겐 합리적이율을, <div class="qvbChanger"></div>투자자에겐 고수익을 드립니다</div>
                                </div>
                            </li>
                            <li>
                                <div><img src="./img/28quickviewicn4.png?<?=$ver?>" /></div>
                                <div>
                                    <div><h3>안정성 확보</h3></div>
                                    <div>동산 담보를 직접 보관, 관리하여 <div class="qvbChanger"></div>보다 안전합니다</div>
                                </div>
                            </li>
                            <div class="clear"></div>
                        </div>
                        <div class="clear"></div>
                    </ul>
                    <div class="qvbTextB">플레이핀테크 더 알아보기</div>
                </div>
                <div class="qvbBot">
                    <div class="qvbbTitle">
                        <div><p><b>신규오픈 투자</b> 상품</p></div>
                        <div><img src="./img/28quickviewexticon.png?<?=$ver?>" /></div>
                        <div class="clear"></div>
                    </div>
                    <ul class="qvbProducts">
                        <div class="qvbFloater">
                            <li class="qvbProduct">
                                <div class="qvbImgPos">
                                    <img src="./img/28quickviewprodsample.png?<?=$ver?>" />
                                    <div class="qvbbBanner1">펀딩전</div>
                                    <div class="qvbbBanner2">펀딩중</div>
                                    <div class="clear"></div>
                                </div>
                                <div class="qvbDescPos">
                                    <div class="qvbProdName">서래마을 펜트하우스 분양1차</div>
                                    <div class="qvbProdInfo">
                                        <p class="qvbPII1"><b>30</b>억원</p>
                                        <div class="qvbPImargin"> / </div>
                                        <p class="qvbPII2"><b>15.5</b> %</p>
                                        <div class="qvbPImargin"> / </div>
                                        <p class="qvbPII3"><b>5</b>개월</p>
                                        <div class="clear"></div>
                                    </div>
                                </div>
                            </li>
                            <li class="qvbProduct">
                                <div class="qvbImgPos">
                                    <img src="./img/28quickviewprodsample.png?<?=$ver?>" />
                                    <div class="qvbbBanner1">펀딩전</div>
                                    <div class="qvbbBanner2">펀딩중</div>
                                    <div class="clear"></div>
                                </div>
                                <div class="qvbDescPos">
                                    <div class="qvbProdName">서래마을 펜트하우스 분양1차</div>
                                    <div class="qvbProdInfo">
                                        <p class="qvbPII1"><b>30</b>억원</p>
                                        <div class="qvbPImargin"> / </div>
                                        <p class="qvbPII2"><b>15.5</b> %</p>
                                        <div class="qvbPImargin"> / </div>
                                        <p class="qvbPII3"><b>5</b>개월</p>
                                        <div class="clear"></div>
                                    </div>
                                </div>
                            </li>
                            <div class="clear"></div>
                        </div>
                        <div class="qvbFloater">
                            <li class="qvbProduct">
                                <div class="qvbImgPos">
                                    <img src="./img/28quickviewprodsample.png?<?=$ver?>" />
                                    <div class="qvbbBanner1">펀딩전</div>
                                    <div class="qvbbBanner2">펀딩중</div>
                                    <div class="clear"></div>
                                </div>
                                <div class="qvbDescPos">
                                    <div class="qvbProdName">서래마을 펜트하우스 분양1차</div>
                                    <div class="qvbProdInfo">
                                        <p class="qvbPII1"><b>30</b>억원</p>
                                        <div class="qvbPImargin"> / </div>
                                        <p class="qvbPII2"><b>15.5</b> %</p>
                                        <div class="qvbPImargin"> / </div>
                                        <p class="qvbPII3"><b>5</b>개월</p>
                                        <div class="clear"></div>
                                    </div>
                                </div>
                            </li>
                            <li class="qvbProduct">
                                <div class="qvbImgPos">
                                    <img src="./img/28quickviewprodsample.png?<?=$ver?>" />
                                    <div class="qvbbBanner1">펀딩전</div>
                                    <div class="qvbbBanner2">펀딩중</div>
                                    <div class="clear"></div>
                                </div>
                                <div class="qvbDescPos">
                                    <div class="qvbProdName">서래마을 펜트하우스 분양1차</div>
                                    <div class="qvbProdInfo">
                                        <p class="qvbPII1"><b>30</b>억원</p>
                                        <div class="qvbPImargin"> / </div>
                                        <p class="qvbPII2"><b>15.5</b> %</p>
                                        <div class="qvbPImargin"> / </div>
                                        <p class="qvbPII3"><b>5</b>개월</p>
                                        <div class="clear"></div>
                                    </div>
                                </div>
                            </li>
                            <div class="clear"></div>
                        </div>
                        <div class="clear"></div>
                    </ul>
                </div>
                <div class="qvbIorL">
                    <div class="qvbIOLtitle"><h3><b>투자 및 대출</b> 하기</h3></div>
                    <div class="qvbIOL">
                        <div class="qvbInvest">
                            <div class="qvbiolP"><img src="./img/28quickviewvicon.png?<?=$ver?>" />책임감을 갖고 신뢰할 수 있는 상품들만 엄선했습니다.<div class="qvbChanger"></div>
누구나 손쉽게 재태크를 할 수 있습니다.</div>
                            <div class="qvbiolEmpha"><h3>지금play 버튼을 눌러 여러분의 <b>재태크를 시작</b>해보세요!</h3>

                            </div>
                            <div class="qvbiolB link_btn"><h5><img src="./img/28quickviewbicon.png?<?=$ver?>" /> 플레이핀테크<b> 투자하기</b></h5></div>
                        </div>
                        <div class="qvbLoan">
                            <div class="qvbiolP"><img src="./img/28quickviewvicon.png?<?=$ver?>" />확실한 동산담보가 있는데 제1금융권은 힘드시다고요?<div class="qvbChanger"></div>
플레이핀테크 대출신청을 통해 타사와 금리를 비교해보세요.</div>
                            <div class="qvbiolEmpha"><h3>지금play 버튼을 눌러 여러분의 <b>재태크를 시작</b>해보세요!</h3>

                            </div>
                            <div class="qvbiolB link_btn"><h5><img src="./img/28quickviewbicon.png?<?=$ver?>" /> 플레이핀테크<b> 대출받기</b></h5></div>
                        </div>
                    </div>
                    <div class="qvbIOLimg">
                        <div><img src="./img/28quickviewmonitorimg.png?<?=$ver?>" /></div>
                    </div>
                    <div class="clear"></div>
                </div>

                <div class="qvbNews">
                    <div class="qvbnTitle"><h3>플레이핀테크 <b>뉴스</b></h3></div>
                    <ul class="qvbArticles">
                        <div class="qvbFloater">
                            <li class="qvbArticle">
                                <div class="qvbImgPos">
                                    <img src="./img/28quickviewnewsthumb1.png?<?=$ver?>" />
                                </div>
                                <div class="qvbDescPos">
                                    <div class="qvbATitle">P2P대출 시대 본격 열리 나P2P대출 시대</div>
                                    <div class="qvbADate">2018-06-20</div>
                                </div>
                            </li>
                            <li class="qvbArticle">
                                <div class="qvbImgPos">
                                    <img src="./img/28quickviewnewsthumb2.png?<?=$ver?>" />
                                </div>
                                <div class="qvbDescPos">
                                    <div class="qvbATitle">P2P대출 시대 본격 열리 나P2P대출 시대</div>
                                    <div class="qvbADate">2018-06-20</div>
                                </div>
                            </li>
                            <div class="clear"></div>
                        </div>
                        <div class="qvbFloater">
                            <li class="qvbArticle">
                                <div class="qvbImgPos">
                                    <img src="./img/28quickviewnewsthumb3.png?<?=$ver?>" />
                                </div>
                                <div class="qvbDescPos">
                                    <div class="qvbATitle">P2P대출 시대 본격 열리 나P2P대출 시대</div>
                                    <div class="qvbADate">2018-06-20</div>
                                </div>
                            </li>
                            <li class="qvbArticle">
                                <div class="qvbImgPos">
                                    <img src="./img/28quickviewnewsthumb4.png?<?=$ver?>" />
                                </div>
                                <div class="qvbDescPos">
                                    <div class="qvbATitle">P2P대출 시대 본격 열리 나P2P대출 시대</div>
                                    <div class="qvbADate">2018-06-20</div>
                                </div>
                            </li>
                            <div class="clear"></div>
                        </div>


                        <div class="clear"></div>
                    </ul>
                </div>

            </div>
        </div>
    </div>
</body>
</html>
