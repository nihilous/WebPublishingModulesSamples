<?php
  include_once('./inc/vs.php');
?>


<!doctype html>
<html itemscope="" itemtype="http://schema.org/WebPage" lang="ko">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title></title>
    <link rel="stylesheet" type="text/css" href="./css/reset.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.2/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="./css/style.css?<?=$ver?>">

</head>
<body>
    <div id="contactPage">
        <div id="cpContents">
            <div class="cpPos">
                <div class="cpib">
                    <div class="cpibTitle">카카오톡 <img src="./img/09contactkakaoicon.png?<?=$ver?>"/> 플러스 친구</div>
                    <div class="cpibEmpha">시소펀딩과 Plus친구하면 투자상품 정보를 빠르게 만나보실 수 있습니다.</div>
                    <div class="cpibP">방법 1ㅣ카카오톡 친구찾기에서 “시소펀딩”을 검색 후, “친구추가”</div>
                    <div class="cpibP">방법 2ㅣ전화번호 입력 후, 전달되는 메시지에 따라, “친구추가”</div>
                    <div class="cpibP">* 친구추가를 하지 않으시면 카카오톡을 통해 투자상품 정보를 받아보실 수 없습니다.</div>
                    <div class="cpibFloater">
                        <form method="get">
                            <input class="cpibKi" type="text" name="cpkPhoneNum" placeholder="받으실 전화번호를 입력해 주세요.">
                            <button class="cpibKi" name="cpkSubmit">친구추가</button>
                            <div class="clear"></div>
                        </form>
                    </div>
                </div>
                <div class="cpib">
                    <div class="cpibTitle">시소펀딩에 궁금한 점이 있으세요?</div>
                    <div class="cpibEmpha">시소펀딩은 여러분의 소중한 문의를 받을 수 있도록 활짝 열려있습니다.</div>
                    <div class="cpibP">운영시간ㅣ평일 10:00 ~ 18:00</div>
                    <div class="cpibFloater">
                        <div class="cpibDi">
                            <div><img src="./img/09contactdirecticon01.png?<?=$ver?>" /> contact@c-so.co.kr</div>
                            <div><img src="./img/09contactdirecticon02.png?<?=$ver?>"/> 1634-5234</div>
                        </div>
                        <button class="cpibDi" name="cpdAsk">1:1 문의하기</button>
                        <div class="clear"></div>
                    </div>
                </div>
                <div class="clear"></div>
            </div>
        </div>
    </div>
</body>
</html>
