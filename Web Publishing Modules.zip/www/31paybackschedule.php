<?php
  include_once('./inc/vs.php');
?>



<!doctype html>
<html itemscope="" itemtype="http://schema.org/WebPage" lang="ko">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title></title>
    <link rel="stylesheet" type="text/css" href="./css/reset.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.2/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="./css/style.css?<?=$ver?>">

</head>
<body>
    <div id="PaybackSchedule">
      <div class="PSmodule">
        <div class="PSMtitle">상환일정</div>
        <div class="iimBBcal">
            <div class="iimBBcalL">상환예정 스케쥴</div>
            <div class="iimBBcalR">전체 스케줄 보기</div>
            <div class="clear"></div>
        </div>
        <div class="iimBBCstan">
            <div class="iimBBCS1">회차</div>
            <div class="iimBBCS2">원금</div>
            <div class="iimBBCS3">세전이자</div>
            <div class="iimBBCS4">세금</div>
            <div class="iimBBCS5">세후합계</div>

            <div class="clear"></div>
        </div>
        <div class="iimBBcvPos">
            <div class="iimBBCval">
                <div class="iimBBCV1">1</div>
                <div class="iimBBCV2">원금V</div>
                <div class="iimBBCV3">세전이자V</div>
                <div class="iimBBCV4">세금V</div>
                <div class="iimBBCV5">세후합계V</div>
                <div class="clear"></div>
            </div>
            <div class="iimBBCval">
                <div class="iimBBCV1">2</div>
                <div class="iimBBCV2">원금V</div>
                <div class="iimBBCV3">세전이자V</div>
                <div class="iimBBCV4">세금V</div>
                <div class="iimBBCV5">세후합계V</div>
                <div class="clear"></div>
            </div>
            <div class="iimBBCval">
                <div class="iimBBCV1">합계</div>
                <div class="iimBBCV2">원금합계더한값</div>
                <div class="iimBBCV3">세전이자더한값</div>
                <div class="iimBBCV4">세금더한값</div>
                <div class="iimBBCV5">세후합계더한값</div>
                <div class="clear"></div>
            </div>
        </div>
        <div class="PSMinsts">
          <div class="PSMI">각 회차 별 상환일자는 대출이 완료된 이후 확정되며, '마이페이지'에서 확인할 수 있습니다.</div>
          <div class="PSMI">확정되는 상환일자에 따라 1회차 이자금액은 변동이 있을 수 있습니다.</div>
        </div>
        <div class="iimBBNotice">상환예정이 없습니다.</div>
        <div class="PSMconfirmB">확인</div>
      </div>
    </div>
</body>
</html>
