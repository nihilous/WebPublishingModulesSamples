<?php
  include_once('./inc/vs.php');
?>
<!doctype html>
<html itemscope="" itemtype="http://schema.org/WebPage" lang="ko">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title></title>
    <link rel="stylesheet" type="text/css" href="./css/reset.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.2/css/bootstrap.min.css">
    <!--<link rel="stylesheet" type="text/css" href="./css/style.css?<?=$ver?>">-->
    <script src="http://code.jquery.com/jquery-3.3.1.js" integrity="sha256-2Kok7MbOyxpgUVvAk/HJ2jigOSYS2auK4Pfzbm7uH60=" crossorigin="anonymous"></script>
    <script>
        $(document).ready(function () {

            var mpValue = $(".mpInput1");
            var pValue = $(".pInput1");



            $("#inputMobile1").change(function () {
                    mpValue.focus();
            });

            $("#inputPhone1").change(function () {
                pValue.focus();
            });

            $(".mpInput1").keyup(function () {
                if (mpValue.val().length == 4)
                {
                    $(".mpInput2").focus();
                }
            });

            $(".mpInput2").keyup(function () {
                if ($(".mpInput2").val().length == 4) {
                    $("#inputPhone1").focus();
                }
            });


            $(".pInput1").keyup(function () {
                if (pValue.val().length == 4)
                {
                    $(".pInput2").focus();
                }
            });

            $(".pInput2").keyup(function () {
                if ($(".pInput2").val().length == 4) {
                    $(".mailInput").focus();
                }
            });




            $(".imgPopB1").click(function () {
                if ($(".imgPopup1").is(':visible'))
                {
                    $(".imgPopup1").css({ 'top': 0 });
                    $(".imgPopup1").css({ 'left': 0 });
                    $(".imgPopup1").hide()
                }
                else
                {
                    $(".imgPopup1").show();
                    $(".imgPopup2").hide();
                    $(".imgPopup3").hide();

                    $(".imgPopup1").css({ 'top': $(window).scrollTop() + (($(window).height() / 2) - ($(".imgPopup1").height() / 2)) });
                    $(".imgPopup1").css({ 'left': ($("#casamiaRecall").width() / 2) - ($(".imgPopup1").width() / 2) });
                }


            });

            $(".imgPopup1").click(function () {
                $(".imgPopup1").css({ 'top': 0 });
                $(".imgPopup1").css({ 'left': 0 });
                $(".imgPopup1").hide();
            });

            $(".imgPopB2").click(function () {
                if ($(".imgPopup2").is(':visible')) {
                    $(".imgPopup2").css({ 'top': 0 });
                    $(".imgPopup2").css({ 'left': 0 });
                    $(".imgPopup2").hide()
                }
                else {
                    $(".imgPopup1").hide();
                    $(".imgPopup2").show();
                    $(".imgPopup3").hide();

                    $(".imgPopup2").css({ 'top': $(window).scrollTop() + (($(window).height() / 2) - ($(".imgPopup2").height() / 2)) });
                    $(".imgPopup2").css({ 'left': ($("#casamiaRecall").width() / 2) - ($(".imgPopup2").width() / 2) });
                }


            });

            $(".imgPopup2").click(function () {
                $(".imgPopup2").css({ 'top': 0 });
                $(".imgPopup2").css({ 'left': 0 });
                $(".imgPopup2").hide();
            });

            $(".imgPopB3").click(function () {
                if ($(".imgPopup3").is(':visible')) {
                    $(".imgPopup3").css({ 'top': 0 });
                    $(".imgPopup3").css({ 'left': 0 });
                    $(".imgPopup3").hide()
                }
                else {
                    $(".imgPopup1").hide();
                    $(".imgPopup2").hide();
                    $(".imgPopup3").show();

                    $(".imgPopup3").css({ 'top': $(window).scrollTop() + (($(window).height() / 2) - ($(".imgPopup3").height() / 2)) });
                    $(".imgPopup3").css({ 'left': ($("#casamiaRecall").width() / 2) - ($(".imgPopup3").width() / 2) });
                }


            });

            $(".imgPopup3").click(function () {
                $(".imgPopup3").css({ 'top': 0 });
                $(".imgPopup3").css({ 'left': 0 });
                $(".imgPopup3").hide();
            });

            $(".rci1").click(function () {
              $("#prodType1").prop("checked",true);
            });

            $(".rci2").click(function () {
              $("#prodType2").prop("checked",true);
            });

            $(".rci3").click(function () {
              $("#prodType3").prop("checked",true);
            });


        });
    </script>
    <style>
        * {
            margin: 0;
            padding: 0;
            font-size: 13px !important;
        }

        ul, li {
            list-style: none;
        }

        html {
            height: 100%;
            width: 100%;
        }

        body {
            height: 100%;
            width: 100%;
            background-color: #fafafa;
        }

	input[type=text] {
		line-height: 1.5;
		color: #495057;
		background-color: #fff;
		background-clip: padding-box;
		border: 1px solid #ced4da;
		border-radius: .25rem;
	}

	input[type=checkbox], input[type=radio] {
		box-sizing: border-box;
	padding: 0;
	}
	.form-check-input {
		position: absolute;
		margin-top: .3rem;
		margin-left: -1.25rem;
	}

        .clear {
            clear: both;
            position: relative;
        }

        .floater{
            position:relative;
            float:left;
        }

        @media screen and (min-width: 900px)
        {



          label.inputTitle {
              position:relative;
              width: 18%;
              margin: 0;
          }

          .adminName{
              position:relative;
              margin: 0;
              margin-right: 10px;
          }

          .divButton{
              cursor:pointer;
          }
          .inputBox{
              position:relative;
              height:28px;
          }

          .inputTarea{
              position:relative;
              height:200px;
              width:100%;
              border:1px solid #eee;
              border-radius:4px;
              background-color:white;
              resize: none;
              padding:10px;
          }

          .fileUB{

              position:relative;
              height:28px;
              border:1px solid #eee;
              border-radius:4px;
              width:100px;
              background-color:#8296d8;
              text-align:center;
              color:white;
              cursor: pointer;
          }


          .noDispImg{
              position:absolute;
              display:none;
              margin:0 auto;
              z-index:1;
              border: 1px solid black;
              padding: 5px 5px 5px 5px;
              border-radius: 5px;
              background-color:white;
          }

          .imgCont{
              position:relative;
              height:auto;
          }



          .admin{

          }

          .adminNamePos{

            float: right;

          }



          #casamiaRecall {
              position: relative;
              height: 100%;
              width: 100%;
              max-width:900px;
              margin: 0 auto;
          }

          #casamiaRecall .crpCont {
              position: relative;
              width: 100%;
              padding: 20px 20px 20px 20px;
              border: 1px solid #eee;
              background-color:white;
              border-radius:5px;
              margin-bottom: 10px;
          }

          #casamiaRecall .crpCont .topInst{
              position: relative;
              width: 100%;
              margin-bottom: 10px;
          }

          #casamiaRecall .crpCont .topInst .topInstL{
              position: relative;
              width: 50%;
              float: left;
              text-align: left;
              font-weight: bold;
          }

          #casamiaRecall .crpCont .topInst .topInstR{
              position: relative;
              width: 50%;
              float: left;
              text-align: right;
          }

          #casamiaRecall .crpCont .topSubInst{
              position: relative;
              width: 100%;
              margin-bottom: 20px;
          }

          #casamiaRecall .crpCont .contTitle{
              position: relative;
              width: 100%;
              text-align:center;
              margin-bottom: 20px;
              font-weight: bold;
          }
          #casamiaRecall .crpCont .section{
              position:relative;
              border-bottom: 1px solid #ccc;
              padding-bottom: 15px;
              margin-bottom:15px;
          }
          #casamiaRecall .crpCont .section .contRight{
              position: relative;
              width: 82%
          }

          #casamiaRecall .crpCont .section .contRightName{
              position: relative;
          }

          #casamiaRecall .crpCont .section .nameSizer{
            width: 140px;
          }





          #casamiaRecall .crpCont .section .contRight .pn{
              position: relative;
              width: 80px;
              text-align:center
          }

          #casamiaRecall .crpCont .section .contRight .inputPad{
              position: relative;
              padding-left:10px;
          }

          #casamiaRecall .crpCont .section .contRight .mailInput{
              position:relative;
              width:50%;
              text-align:left;
              padding-right:10px;

          }
          #casamiaRecall .crpCont .section .contRight .addInput{
              position:relative;
              width:100%;

          }

          #casamiaRecall .crpCont .section .contRight .roeRadio1 {
            margin-right: 20px;
          }

          #casamiaRecall .crpCont .section .contRight .roeRadio1 .refexcRad{
            cursor: pointer;
          }

          #casamiaRecall .crpCont .section .contRight .roeRadio2 .refexcRad{
            cursor: pointer;
          }


          #casamiaRecall .crpCont .ipb{
              position:relative;
              text-align:center;
              background-color: #eee;
              height: 25px;
              border: 1px solid #b9b9b9;
              line-height: 25px;
              padding: 0px 5px 0px 5px;
              float:right;
          }

          #casamiaRecall .crpCont .section .inst{
              position:relative;
              float: left;
          }

          #casamiaRecall .crpCont .section .fileStat1{
            margin-left: 10px;
            margin-right: 10px;
          }
          #casamiaRecall .crpCont .section .fileStat2{
            margin-left: 10px;
            margin-right: 10px;
          }
          #casamiaRecall .crpCont .section .fileStat3{
            margin-left: 10px;
            margin-right: 10px;
          }
          #casamiaRecall .crpCont .section .contRight .prodSel{
            position: relative;
            width: 30%;
            margin-right: 5%;
            text-align: center;
          }

          #casamiaRecall .crpCont .section .contRight .prodSel:nth-last-child(2){
            margin-right: 0;
          }

          #casamiaRecall .crpCont .section .contRight .prodSel div{
            text-align: center;
          }

          #casamiaRecall .crpCont .section .contRight .prodSel .recallImg{
            position: relative;
            width: 100%;
            height: auto;
          }


          #casamiaRecall .crpCont .submitBPos{
            position: relative;
            text-align: center;
          }

          #casamiaRecall .crpCont .submitBPos .submitB{
            position: relative;
            text-align: center;
            width: 70px;
            height: 28px;
          }



          #casamiaRecall .crpCont .userAgreeInst{
            width:100%;
            position:relative;
            background-color:#eee;
            padding:20px;
            text-align:left;
            margin-bottom:20px;
          }











        }

        @media screen and (min-width: 500px) and (max-width: 899px){


          label.inputTitle {
              position:relative;
              width: 18%;
              margin: 0;
          }
          .adminName{
              position:relative;
              margin: 0;
              margin-right: 10px;
          }


          .divButton{
              cursor:pointer;
          }
          .inputBox{
              position:relative;
              height:28px;
          }

          .inputTarea{
              position:relative;
              height:200px;
              width:100%;
              border:1px solid #eee;
              border-radius:4px;
              background-color:white;
              resize: none;
              padding:10px;
          }

          .fileUB{

              position:relative;
              height:28px;
              border:1px solid #eee;
              border-radius:4px;
              width:100px;
              background-color:#8296d8;
              text-align:center;
              color:white;
              cursor: pointer;
          }


          .noDispImg{
              position:absolute;
              display:none;
              margin:0 auto;
              z-index:1;
              border: 2px solid black;
              padding: 5px 5px 5px 5px;
              border-radius: 5px;
              background-color:white;
          }

          .imgCont{
              position:relative;
              height:auto;
          }



          .admin{

          }


          .adminNamePos{

            float: right;

          }
          #casamiaRecall {
              position: relative;
              height: 100%;
              width: 100%;
              max-width:700px;
              margin: 0 auto;
          }

          #casamiaRecall .crpCont {
              position: relative;
              width: 100%;
              padding: 20px 20px 20px 20px;
              border: 1px solid #eee;
              background-color:white;
              border-radius:5px;
              margin-bottom: 10px;
          }


          #casamiaRecall .crpCont .topInst{
              position: relative;
              width: 100%;
              margin-bottom: 10px;
          }

          #casamiaRecall .crpCont .topInst .topInstL{
              position: relative;
              width: 50%;
              float: left;
              text-align: left;
              font-weight: bold;
          }

          #casamiaRecall .crpCont .topInst .topInstR{
              position: relative;
              width: 50%;
              float: left;
              text-align: right;
          }

          #casamiaRecall .crpCont .topSubInst{
              position: relative;
              width: 100%;
              margin-bottom: 20px;
          }

          #casamiaRecall .crpCont .contTitle{
              position: relative;
              width: 100%;
              text-align:center;
              margin-bottom: 20px;
              font-weight: bold;
          }
          #casamiaRecall .crpCont .section{
              position:relative;
              border-bottom: 1px solid #ccc;
              padding-bottom: 15px;
              margin-bottom:15px;
          }
          #casamiaRecall .crpCont .section .contRight{
              position: relative;
              width: 82%
          }

          #casamiaRecall .crpCont .section .contRightName{
              position: relative;
          }

          #casamiaRecall .crpCont .section .nameSizer{
            width: 140px;
          }

          #casamiaRecall .crpCont .section .contRight .pn{
              position: relative;
              width: 80px;
              text-align:center
          }

          #casamiaRecall .crpCont .section .contRight .inputPad{
              position: relative;
              padding-left:10px;
          }

          #casamiaRecall .crpCont .section .contRight .mailInput{
              position:relative;
              width:60%;
              text-align:left;
              padding-right:10px;

          }
          #casamiaRecall .crpCont .section .contRight .addInput{
              position:relative;
              width:100%;

          }

          #casamiaRecall .crpCont .section .contRight .roeRadio1{
            margin-right: 20px;
          }

          #casamiaRecall .crpCont .section .contRight .roeRadio1 .refexcRad{
            cursor: pointer;
          }

          #casamiaRecall .crpCont .section .contRight .roeRadio2 .refexcRad{
            cursor: pointer;
          }

          #casamiaRecall .crpCont .ipb{
              position:relative;
              text-align:center;
              background-color: #eee;
              height: 25px;
              border: 1px solid #b9b9b9;
              line-height: 25px;
              padding: 0px 5px 0px 5px;
              float:right;
          }

          #casamiaRecall .crpCont .section .inst{
              position:relative;
              float: right;
          }

          #casamiaRecall .crpCont .section .fileStat1{
            margin-left: 10px;
            margin-right: 10px;
          }
          #casamiaRecall .crpCont .section .fileStat2{
            margin-left: 10px;
            margin-right: 10px;
          }
          #casamiaRecall .crpCont .section .fileStat3{
            margin-left: 10px;
            margin-right: 10px;
          }

          #casamiaRecall .crpCont .section .contRight .prodSel{
            position: relative;
            width: 30%;
            margin-right: 5%;
            text-align: center;
          }

          #casamiaRecall .crpCont .section .contRight .prodSel:nth-last-child(2){
            margin-right: 0;
          }

          #casamiaRecall .crpCont .section .contRight .prodSel div{
            text-align: center;
          }

          #casamiaRecall .crpCont .section .contRight .prodSel .recallImg{
            position: relative;
            width: 100%;
            height: auto;
          }


          #casamiaRecall .crpCont .submitBPos{
            position: relative;
            text-align: center;
          }

          #casamiaRecall .crpCont .submitBPos .submitB{
            position: relative;
            text-align: center;
            width: 70px;
            height: 28px;
          }

          #casamiaRecall .crpCont .userAgreeInst{
            width:100%;
            position:relative;
            background-color:#eee;
            padding:20px;
            text-align:left;
            margin-bottom:20px;
          }

          }


        @media screen and (max-width: 499px) {

          label.inputTitle {
              position:relative;
              width: 100%;
              margin: 0;
              margin-bottom: 10px;
          }

          .adminName{
              position:relative;
              margin: 0;
              width: 100%;
              margin-top: 10px;
              margin-bottom: 10px;
          }

          .divButton{
              cursor:pointer;
          }
          .inputBox{
              position:relative;
              height:28px;
          }

          .inputTarea{
              position:relative;
              height:200px;
              width:100%;
              border:1px solid #eee;
              border-radius:4px;
              background-color:white;
              resize: none;
              padding:10px;
          }

          .fileUB{

              position:relative;
              height:28px;
              border:1px solid #eee;
              border-radius:4px;
              padding-left: 3px;
              padding-right: 3px;
              line-height: 28px;
              background-color:#8296d8;
              text-align:center;
              color:white;
              cursor: pointer;
          }


          .noDispImg{
              position:absolute;
              display:none;
              margin:0 auto;
              z-index:1;
              border: 2px solid black;
              padding: 5px 5px 5px 5px;
              border-radius: 5px;
              background-color:white;
          }

          .imgCont{
              position:relative;
              height:auto;
          }



          .admin{

          }

          .adminNamePos{
          }



          .mobMarginer
          {
            margin-top: 10px;
          }

          #casamiaRecall {
              position: relative;
              height: 100%;
              width: 100%;
              max-width:500px;
              margin: 0 auto;
          }


          #casamiaRecall .crpCont {
              position: relative;
              width: 100%;
              padding: 20px 20px 20px 20px;
              border: 1px solid #eee;
              background-color:white;
              border-radius:5px;
              margin-bottom: 10px;
          }


          #casamiaRecall .crpCont .topInst{
              position: relative;
              width: 100%;
              margin-bottom: 10px;
          }

          #casamiaRecall .crpCont .topInst .topInstL{
              position: relative;
              width: 100%;
              text-align: left;
              font-weight: bold;
              margin-bottom: 10px;
          }

          #casamiaRecall .crpCont .topInst .topInstR{
              position: relative;
              width: 100%;
              text-align: right;
          }

          #casamiaRecall .crpCont .topSubInst{
              position: relative;
              width: 100%;
              margin-bottom: 20px;
          }

          #casamiaRecall .crpCont .contTitle{
              position: relative;
              width: 100%;
              text-align:center;
              margin-bottom: 20px;
              font-weight: bold;
          }
          #casamiaRecall .crpCont .section{
              position:relative;
              border-bottom: 1px solid #ccc;
              padding-bottom: 15px;
              margin-bottom:15px;
          }
          #casamiaRecall .crpCont .section .contRight{
              position: relative;
              width: 100%
          }

          #casamiaRecall .crpCont .section .contRightName{
              position: relative;
              width: 100%;
          }

          #casamiaRecall .crpCont .section .nameSizer{
            width: 100%;
          }

          #casamiaRecall .crpCont .section #inputMobile1{
            float: left;
            margin-right: 2%;
          }

          #casamiaRecall .crpCont .section #inputPhone1{
            float: left;
            margin-right: 2%;
          }

          #casamiaRecall .crpCont .section .contRight .pn{
              position: relative;
              width: 39%;
              text-align:center;
              margin:0;
          }

          #casamiaRecall .crpCont .section .contRight .pn2r{
              position: relative;
              width: 39%;
              text-align:center;
              margin:0;
              float: right;
          }

          #casamiaRecall .crpCont .section .inputPad{
              position: relative;
              padding-left:10px;
          }
          #casamiaRecall .crpCont .section .contRight .mailInput{
              position:relative;
              width:100%;
              text-align:left;
              padding-right:10px;
          }



          #casamiaRecall .crpCont .ipb{
              position:relative;
              text-align:center;
              background-color: #eee;
              height: 25px;
              border: 1px solid #b9b9b9;
              line-height: 25px;
              padding: 0px 5px 0px 5px;
              float:right;
          }

          #casamiaRecall .crpCont .section .inst{
              position:relative;
              float: left;
          }

          #casamiaRecall .crpCont .section .fileStat1{
            margin-left: 5px;
            margin-right: 5px;
          }
          #casamiaRecall .crpCont .section .fileStat2{
            margin-left: 5px;
            margin-right: 5px;
          }
          #casamiaRecall .crpCont .section .fileStat3{
            margin-left: 5px;
            margin-right: 5px;
          }
          #casamiaRecall .crpCont .section .contRight .prodSel{
            position: relative;
            width: 30%;
            margin-right: 5%;
            text-align: center;
          }

          #casamiaRecall .crpCont .section .contRight .prodSel:nth-last-child(2){
            margin-right: 0;
          }

          #casamiaRecall .crpCont .section .contRight .prodSel div{
            text-align: center;
          }

          #casamiaRecall .crpCont .section .contRight .prodSel .recallImg{
            position: relative;
            width: 100%;
            height: auto;
          }

          #casamiaRecall .crpCont .section .contRight .addInput{
              position:relative;
              width:100%;

          }

          #casamiaRecall .crpCont .section .contRight .roeRadio1{
            width: 50%
          }

          #casamiaRecall .crpCont .section .contRight .roeRadio2{
            width: 50%
          }

          #casamiaRecall .crpCont .section .contRight .roeRadio1 .refexcRad{
            cursor: pointer;
          }

          #casamiaRecall .crpCont .section .contRight .roeRadio2 .refexcRad{
            cursor: pointer;
          }



          #casamiaRecall .crpCont .submitBPos{
            position: relative;
            text-align: center;
          }

          #casamiaRecall .crpCont .submitBPos .submitB{
            position: relative;
            text-align: center;
            width: 70px;
            height: 28px;
          }

          #casamiaRecall .crpCont .userAgreeInst{
            width:100%;
            position:relative;
            background-color:#eee;
            padding:20px;
            text-align:left;
            margin-bottom:20px;
          }
}
	.inst{
		font-size:12px !important;
	}


    </style>
</head>
<body>
    <div id="casamiaRecall">

        <form>

            <div class="crpCont">
                <div class="topInst">
                  <div class="topInstL">까사온 메모텍스 교환/환불 접수</div>
                  <div class="topInstR">리콜전용 상담센터 : <b>1670-3409</b></div>
                  <div class="clear"></div>
                </div>
                <div class="topSubInst">* 고객정보, 상품정보를 입력해주세요. 담당자가 순차적으로 연락드리겠습니다. </div>
                <div class="contTitle">고객정보 입력</div>
                <div class="section">
                    <label class="inputTitle floater">이름</label>
                    <div class="contRightName floater">
                        <input class="personName floater inputBox inputPad nameSizer" type="text" />

                        <div class="clear"></div>
                    </div>
                    <div class="admin adminNamePos">
                        <label class="adminName">접수자</label>
                        <input class="petitionerName inputBox inputPad nameSizer" type="text" />
                        <div class="clear"></div>
                    </div>
                    <div class="clear"></div>
                </div>

                <div>
                    <div class="section">
                        <label class="inputTitle floater" for="inputMobile1">핸드폰</label>
                        <div class="floater contRight">
                            <select id="inputMobile1"  class="inputBox">
                                <option selected>010</option>
                                <option>011</option>
                                <option>016</option>
                                <option>017</option>
                                <option>018</option>
                                <option>019</option>
                            </select>
                            <input type="text" maxlength="4" class="mpInput1  inputBox pn" />
                            <input type="text" maxlength="4" class="mpInput2  inputBox pn pn2r" />
                            <div class="clear"></div>
                        </div>
                        <div class="clear"></div>
                    </div>
                    <div class="section">
                        <label class="inputTitle floater" for="inputPhone1">연락처</label>
                        <div class="floater contRight">
                            <select id="inputPhone1" class="inputBox">
                                <option selected>02</option>
                                <option>031</option>
                                <option>032</option>
                                <option>033</option>
                                <option>041</option>
                                <option>042</option>
                                <option>043</option>
                                <option>051</option>
                                <option>052</option>
                                <option>053</option>
                                <option>054</option>
                                <option>055</option>
                                <option>061</option>
                                <option>062</option>
                                <option>063</option>
                                <option>064</option>
                            </select>
                            <input type="text" maxlength="4" class="pInput1 inputBox pn" />
                            <input type="text" maxlength="4" class="pInput2 inputBox pn pn2r" />
                            <div class="clear"></div>
                        </div>
                        <div class="clear"></div>
                    </div>
                </div>
                <div class="section">
                    <label class="inputTitle floater">E-mail</label>
                    <div class="contRight floater">
                        <input type="text" class="inputBox inputPad mailInput" placeholder="이메일"/>
                    </div>
                    <div class="clear"></div>
                </div>
                <div class="section">
                    <label  class="inputTitle floater" for="inputMobile1">주소</label>
                    <div class="crpAddressD floater contRight">
                        <div style="margin-bottom:10px;">
                            <input class="floater inputBox divButton" type="text" placeholder="우편번호" style="width:100px;padding-left:10px;"/>
                            <input type="button" class="floater divButton " value="주소찾기" style="margin-left:10px; height:28px;"/>
                            <div class="clear"></div>
                        </div>
                        <div style="margin-bottom:10px;">
                            <input class="inputBox inputPad divButton addInput" type="text" placeholder="기본주소" />
                        </div>
                        <div>
                            <input class="inputBox inputPad addInput" type="text" placeholder="세부주소" maxlength="30"/>
                        </div>
                    </div>
                    <div class="clear"></div>
                </div>
            </div>
            <div class="crpCont">
                <div class="section">
                    <label class="inputTitle floater">리콜 요청 타입</label>
                    <div class="floater contRight">
                        <div class="roeRadio1 floater"><input type="radio" name="refOrExc" id="ref" checked="" class="refexcRad"/><label for="ref"  class="refexcRad"> 환불</label></div>
                        <div class="roeRadio2 floater"><input type="radio" name="refOrExc" id="exc"  class="refexcRad"/><label for="exc"  class="refexcRad"> 교환</label></div>
                        <div class="clear"></div>
                    </div>
                    <div class="clear"></div>

                </div>
                <div class="section admin">
                    <label class="inputTitle floater">리콜 요청 타입</label>
                    <div class="floater contRight">
                        <textarea class="inputPad" maxlength="240" placeholder="240자 제한" style='width:100%;min-height:100px;'></textarea>
                    </div>
                    <div class="clear"></div>
                </div>
                <div class="contTitle">보유하고 계신 상품 선택 및 제품사진 4매</div>
                <div class="section">
                    <label class="inputTitle  floater">리콜대상 상품명</label>
                    <div class="floater contRight">
                        <div class="floater prodSel">
                          <div><img class="recallImg divButton rci1" src="./img/recall.png"<?=$ver?> /></div>
                          <label for="prodType1" class="divButton" style="margin: 0 auto;">150cm x 200cm x 5cm</label>
                          <div><input id="prodType1" class="divButton" type="radio" name="productSize" checked=""/></div>
                        </div>
                        <div class="floater prodSel">
                          <div><img class="recallImg divButton rci2" src="./img/recall.png"<?=$ver?> /></div>
                          <label for="prodType2" class="divButton" style="margin: 0 auto;">150cm x 200cm x 8cm</label>
                          <div><input id="prodType2" class="divButton" type="radio" name="productSize" /></div>
                        </div>
                        <div class="floater prodSel">
                          <div><img class="recallImg divButton rci3" src="./img/recall.png"<?=$ver?> /></div>
                          <label for="prodType3" class="divButton" style="margin: 0 auto;">160cm x 200cm x 8cm</label>
                          <div><input id="prodType3" class="divButton" type="radio" name="productSize" /></div>
                        </div>

                        <div class="clear"></div>
                    </div>
                    <div class="clear"></div>
                </div>
                <div class="section">
                    <label class="inputTitle  floater">제품 전체사진</label>
                    <div class="floater"><input id="imgInput1" class="divButton" type="file"/></div>
                    <div class="imgPopB1 ipb divButton">참고이미지</div>
                    <div class="inst"></div>
                    <div class="clear"></div>
                </div>
                <div class="section">
                    <label class="inputTitle  floater">케어라벨 앞면</label>
                    <div class="floater"><input id="imgInput2" class="divButton" type="file"/></div>
                    <div class="imgPopB2 ipb divButton">참고이미지</div>
                    <div class="inst">* 케어라벨 확인방법:매드리스 커버 안쪽, 매트리스 속커버 안쪽</div>
                    <div class="clear"></div>
                </div>
                <div class="section">
                    <label class="inputTitle  floater">케어라벨 뒷면</label>
                    <div class="floater"><input id="imgInput3" class="divButton" type="file"/></div>
                    <div class="imgPopB3 ipb divButton">참고이미지</div>
                    <div class="inst">* 케어라벨 확인방법:매드리스 커버 안쪽, 매트리스 속커버 안쪽</div>
                    <div class="clear"></div>
                </div>
            </div>
            <div class="crpCont">
              <div class="userAgreeInst" >
                수집목적 : 고객 리콜 진행에 따른 기본적인 고객정보 수집<br>
                수집항목 : 성명, 핸드폰, 주소, 이메일<br>
                보유 및 이용기간 : 3년 – 발생내용에 따른 유/무상 서비스 제공 기간 동안 보유<br>
                <br>
                수집목적,수집항목, 보유 및 이용기간에 대해 동의하시면 원활한 리콜 접수가 가능합니다.<br>
                안내에 동의 하셨더라도 신용정보의 이용 및 보호에 관련 법률에 따라 중단을 언제라도 요청 하실 수 있습니다.<br />
                (수신거부 대표전화 : 1588-3408)<br>
              </div>
              <label for="agree" style="cursor:pointer">개인정보 및 활용에 동의합니다.</label>
              <input id="agree" type="checkbox" style="cursor:pointer"/>
              <div class="submitBPos">
                <input type="button" class="divButton submitB" value="등록"/>
              </div>
            </div>
        </form>
        <div class="imgPopup1 divButton noDispImg">
            <img class="imgCont" src="./img/casaimg01.png"<?=$ver?> />
        </div>
        <div class="imgPopup2 divButton noDispImg">
            <img class="imgCont" src="./img/casaimg02.png"<?=$ver?> />
        </div>
        <div class="imgPopup3 divButton noDispImg">
            <img class="imgCont" src="./img/casaimg03.png"<?=$ver?> />
        </div>
    </div>

</body>
</html>
