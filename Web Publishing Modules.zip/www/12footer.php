<?php
  include_once('./inc/vs.php');
?>


<!doctype html>
<html itemscope="" itemtype="http://schema.org/WebPage" lang="ko">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title></title>
    <link rel="stylesheet" type="text/css" href="./css/reset.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.2/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="./css/style.css?<?=$ver?>">

</head>
<body>
    <div id="footerPage">
        <div id="fpContents">
            <div class="footBox">
                <div class="footTpos">
                    <div class="footTL">
                        <div class="footTLimg">
                            <img src="./img/12footersamplelogo.png?<?=$ver?>"  />
                        </div>
                        <div class="footTLlinks">
                            <div class="footLink">채용</div>
                            <div class="footLink">블로그</div>
                            <div class="footLink">피플의 사람들</div>
                            <div class="footLink">기술블로그</div>
                            <div class="clear"></div>
                        </div>
                        <div class="clear"></div>
                    </div>
                    <div class="footTL">
                        <div class="footSNS">
                            <img src="./img/12footersnsicon01.png?<?=$ver?>" />
                        </div>
                        <div class="footSNS">
                            <img src="./img/12footersnsicon02.png?<?=$ver?>" />
                        </div>
                        <div class="footSNS">
                            <img src="./img/12footersnsicon03.png?<?=$ver?>" />
                        </div>
                        <div class="clear"></div>
                    </div><!--페북, xx 카카오-->
                    <div class="clear"></div>
                    <div class="footTLlinksLow">
                        <div class="footLink">채용</div>
                        <div class="footLink">블로그</div>
                        <div class="footLink">피플의 사람들</div>
                        <div class="footLink">기술블로그</div>
                        <div class="clear"></div>
                    </div>
                </div>
                <div class="footWarn">피플펀드는 투자원금과 수익을 보장하지 않으며 투자손실에 대한 책임은 모두 투자자에게 있습니다.</div>
                <div class="footCont">
                    <div class="footCall">
                        <p><b>고객센터 </b>02-6212-0700 (오전 9시 - 오후6시)</p>
                    </div>
                    <div class="footMar"></div><!--bar-->
                    <div class="footMail">
                        <p><b>E-mail </b>ask@peoplefund.co.kr</p>
                    </div>
                    <div class="clear"></div>
                </div>
                <div class="footSeper"></div><!--bar, margin splitter-->
                <div class="footDescPos">
                    <div class="footDesc">주)피플펀드컴퍼니</div>
                    <div class="footMar"></div>
                    <div class="footDesc">대표: 김대윤</div>
                    <div class="clear"></div>
                </div>
                <div class="footDescPos">
                    <div class="footDesc">사업자등록번호: 668-88-00027</div>
                    <div class="footMar"></div>
                    <div class="footDesc">통신판매업신고 : 2015-서울강남-03543</div>
                    <div class="footMar"></div>
                    <div class="footDesc">주소 : 서울시 강남구 테헤란로87길 29, 10층 (삼성동, M타워)</div>
                    <div class="clear"></div>
                </div>
                <div class="footDescPos">
                    <div class="footDesc">제휴 여신기관</div>
                </div>
                <div class="footDescPos">
                    <div class="footDesc">개인채권 - 주식회사 전북은행</div>
                    <div class="footMar"></div>
                    <div class="footDesc">사업자등록번호: 418-81-07090</div>
                    <div class="footMar"></div>
                    <div class="footDesc">전화번호: 1588-4477</div>
                    <div class="footMar"></div>
                    <div class="footDesc">주소: 전주시 덕진구 백제대로 566 (금암동)</div>
                    <div class="clear"></div>
                </div>
                <div class="footDescPos">
                    <div class="footDesc">담보채권 - 주식회사 피플펀드대부</div>
                    <div class="footMar"></div>
                    <div class="footDesc">사업자등록번호: 411-81-91020</div>
                    <div class="footMar"></div>
                    <div class="footDesc">P2P연계대부업: 2018-금감원-1359</div>
                    <div class="footMar"></div>
                    <div class="footDesc">전화번호: 02-6212-2272</div>
                    <div class="footMar"></div>
                    <div class="footDesc">주소: 서울시 강남구 테헤란로87길 29, 1004호 (삼성동, M타워)</div>
                    <div class="clear"></div>
                </div>
                <div class="footDescPos">
                    <div class="footDesc">개인(신용)정보 취급방침</div>
                    <div class="footMar"></div>
                    <div class="footDesc">영리목적 광고성 정보 거부 등</div>
                    <div class="footMar"></div>
                    <div class="footDesc">책임의 한계와 고지</div>
                    <div class="clear"></div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
