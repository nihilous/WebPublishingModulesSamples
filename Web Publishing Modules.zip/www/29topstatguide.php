<?php
  include_once('./inc/vs.php');
?>



<!doctype html>
<html itemscope="" itemtype="http://schema.org/WebPage" lang="ko">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title></title>
    <link rel="stylesheet" type="text/css" href="./css/reset.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.2/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="./css/style.css?<?=$ver?>">

</head>
<body>
    <div id="F29noticeModule">
        <div class="F29nmCont">
                <div class="F29nmDesc">Test 공지사항 내용입니다</div>
        </div>
    </div>
    <div id="F29statModule">
        <div  class="F29smCont">
            <div class="F29smBox">
                <div class="F29smbTitle">연평균수익률</div>
                <div class="F29smbVal"><p><b>21.50</b>%</p></div>
            </div>
            <div class="F29smBox">
                <div class="F29smbTitle">누적대출금</div>
                <div class="F29smbVal"><p><b>12,376,900,000</b>원</p></div>
            </div>
            <div class="F29smBox">
                <div class="F29smbTitle">대출잔액</div>
                <div class="F29smbVal"><p><b>7,327,500,000</b>원</p></div>
            </div>
            <div class="F29smBox">
                <div class="F29smbTitle">부실률/연채율</div>
                <div class="F29smbVal"><p><b>21.50</b>%<i> / </i><b>21.50</b>%</p></div>
            </div>
            <div class="clear"></div>

        </div>
    </div>
    <div id="F29guideModlue">
        <div class="F29gmCont">
            <div class="F29gmTitle">신규 투자자를 위한 투자 가이드</div>
            <div class="F29gmInst">플레이핀테크가 처음이신가요? 아래의 링크에서 이용방법을 상세히 알려드립니다!</div>
            <div class="F29gmBtns">
                <div class="F29gmBposL">
                    <div class="F29gmBtn">투자이용절차</div>
                    <div class="clear"></div>
                </div>
                <div class="F29gmBposR">
                    <div class="F29gmBtn">출금계좌등록</div>
                    <div class="clear"></div>
                </div>
                <div class="clear"></div>
            </div>
        </div>
    </div>
</body>
</html>
