<?php
  include_once('./inc/vs.php');
?>


<!doctype html>
<html itemscope="" itemtype="http://schema.org/WebPage" lang="ko">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title></title>
    <link rel="stylesheet" type="text/css" href="./css/reset.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.2/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="./css/style.css?<?=$ver?>">

</head>
<body>
    <div id="loanPage"> <!--1130 ,1129  768, 767-->
        <div id="loanContents">
            <div class="lTypeSelector">
                <div class="lt">건축자금대출신청</div>
                <div class="lt">주택담보대출신청</div>
                <div class="lt">건축주세미나신청</div>
                <div class="clear"></div>
            </div>
            <div class="loanInst">
                <div class="callNum">
                    <div class="cnI">
                        <img src="./img/05lpimg.png?<?=$ver?>" />
                    </div>
                    <div class="cnT">
                        <div>대출상담 문의 1644-5506</div>
                        <div>테라펀딩으로 전화주시면 친절히 상담해 드리겠습니다.</div>
                    </div>
                    <div class="clear"></div>
                </div>
                <div class="lpcPos">
                    <div class="lpPadder">
                    <div class="instTitle">
                        <div>P2P금융을 통한 건축자금 대출로 당신의 건축사업이 달라집니다.</div>
                        <div>테라펀딩 건축자금 대출 안내</div>
                    </div>
                    <div class="benefits">
                        <div class="ib"><!--w 434-->
                            <div class="ibIcon">
                                <img class="ibiSizer" src="./img/05lpic01.png?<?=$ver?>" />
                            </div>
                            <div class="ibDesc">
                                <div class="ibdEmpha">빠릅니다</div>
                                <div class="ibd">건축자금대출 심사 ~ 실행까지 평균 10일이면 OK</div>
                                <div class="ibd">신속한 사업진행으로 사업회전률 증가</div>
                            </div>
                            <div class="clear"></div>
                        </div>
                        <div class="ib">
                            <div class="ibIcon">
                                <img class="ibiSizer" src="./img/05lpic02.png?<?=$ver?>"/>
                            </div>
                            <div class="ibDesc">
                                <div class="ibdEmpha">저렴합니다</div>
                                <div class="ibd">월 1%대 중금리 건축자금대출 가능</div>
                                <div class="ibd">현금 공사를 통한 사업비 절감 가능</div>
                            </div>
                            <div class="clear"></div>
                        </div>
                        <div class="ib">
                            <div class="ibIcon">
                                <img class="ibiSizer" src="./img/05lpic03.png?<?=$ver?>" />
                            </div>
                            <div class="ibDesc">
                                <div class="ibdEmpha">절약됩니다</div>
                                <div class="ibd">사업성 검토비용 無 중도상환 수수료</div>
                                <div class="ibd">총 사업비의 10%만으로 사업 진행 가능</div>
                            </div>
                            <div class="clear"></div>
                        </div>
                        <div class="ib">
                            <div class="ibIcon">
                                <img class="ibiSizer" src="./img/05lpic04.png?<?=$ver?>" />
                            </div>
                            <div class="ibDesc">
                                <div class="ibdEmpha">안전합니다</div>
                                <div class="ibd">신탁방식으로 제 3자에 의한 권리침해 예방 </div>
                                <div class="ibd">기성금 직불관리로 유치권 발생 예방</div>
                            </div>
                            <div class="clear"></div>
                        </div>
                        <div class="clear"></div>
                    </div>
                </div>
                </div>
                <button class="extButton">내용더보기</button>
                <div class="loanPaper">
                    <div class="lpTitle">대출 신청서</div>
                    <div class="processStat">
                        <div class="stage">
                            <div class="sNum">01</div>
                            <div class="sDesc">개인정보입력</div>
                        </div>
                        <div class="stage">
                            <div class="sNum">02</div>
                            <div class="sDesc">사업정보입력</div>
                        </div>
                        <div class="stage">
                            <div class="sNum">03</div>
                            <div class="sDesc">추가정보입력</div>
                        </div>
                        <div class="stage">
                            <div class="sNum">04</div>
                            <div class="sDesc">기타의견입력</div>
                        </div>
                        <div class="clear"></div>
                    </div>
                    <div class="lpInfoB">
                        <div class="sInst">01 개인정보 입력</div>
                        <div class="lpInputS">
                            <form method="post">
                                <div class="liRow">
                                    <div class="lprName">신청자 명</div>
                                    <input type="text" name="lName"/>
                                    <div class="lprInst"></div>
                                </div>
                                <div class="liRow">
                                    <div class="lprName">연락처</div>
                                    <input type="tel" name="lPhone"/>
                                    <div class="lprInst"></div>
                                </div>
                                <div class="liRow">
                                    <div class="lprName">이메일</div>
                                    <input type="email" name="lMail"/>
                                    <div class="lprInst"></div>
                                </div>
                                <div class="nextStage">
                                    <input type="submit">
                                </div>
                            </form>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
</body>
</html>
