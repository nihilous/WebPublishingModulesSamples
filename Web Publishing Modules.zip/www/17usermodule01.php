<?php
  include_once('./inc/vs.php');
?>


<!doctype html>
<html itemscope="" itemtype="http://schema.org/WebPage" lang="ko">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title></title>
    <link rel="stylesheet" type="text/css" href="./css/reset.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.2/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="./css/style.css?<?=$ver?>">

</head>
<body>
    <div id="UserModule01Page">
        <div id="um1Contents">
            <div class="um01Box">
                <div class="um01Top">
                    <div class="um01Tl">
                        <div class="um01TLt"><p><b>이석진</b>님</p></div>
                        <div class="um01TLt"><p>(<b>개인투자자</b>)</p></div>
                    </div>
                    <div class="um01Tr"><img src="./img/17usermodule01icon.png"<?=$ver?> /></div>
                    <div class="clear"></div>
                </div>
                <div class="um01R">
                    <div class="um01Rl">잔여 투자 원금</div>
                    <div class="um01Rr"><p><b>0</b>원</p></div>
                    <div class="clear"></div>
                </div>
                <div class="um01R">
                    <div class="um01Rl">누적 투자 채권</div>
                    <div class="um01Rr"><p><b>1</b>건</p></div>
                    <div class="clear"></div>
                </div>
                <div class="um01R">
                    <div class="um01Rl">평균 수익률</div>
                    <div class="um01Rr"><p>연 <b>10.18</b> %</p></div>
                    <div class="clear"></div>
                </div>
                <div class="um01R">
                    <div class="um01Rl">실질 수익률</div>
                    <div class="um01Rr"><p>연 <b>8.38</b> %</p></div>
                    <div class="clear"></div>
                </div>
                <div class="um01AccChan">상환계좌 변경</div>
            </div>
        </div>
    </div>
</body>
</html>
