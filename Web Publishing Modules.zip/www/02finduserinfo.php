<?php
  include_once('./inc/vs.php');
?>



<!doctype html>
<html itemscope="" itemtype="http://schema.org/WebPage" lang="ko">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title></title>
    <link rel="stylesheet" type="text/css" href="./css/reset.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.2/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="./css/style.css?<?=$ver?>">

</head>
<body>
    <div id="fuiPage">
        <div id="fuiContents">
            <div class="fuiBox">
                <div class="FuiTitle">휴대폰 번호로</div>
                <div class="FuiTitle">아이디 찾기</div>
                <div class="fuiSections">
                    <div class="fuiS">이름</div>
                    <div class="fuiS">휴대폰번호</div>
                    <div class="clear"></div>
                </div>
                <form method="get">
                    <div class="fuiInputsFields">
                        <input class="fuiIF" type="text" name="id" placeholder="한글로 실명을 적어주세요." />
                        <input class="fuiIF" type="tel" name="phonNumber" placeholder='"-"없이 입력해주세요.' />
                        <div class="clear"></div>
                    </div>
                    <div class="fuiWarnPos">
                        <div class="fuiWarn">이름을 입력해주세요.</div>
                        <div class="fuiWarn">휴대폰 번호를 입력해주세요.</div>
                        <div class="clear"></div>
                    </div>
                    <div class="fuiInst">본인 명의로 가입된 휴대폰번호를 입력해주세요.</div>
                    <button class="fuiSubmit" >아이디 찾기</button>
                </form>
            </div>
        </div>
    </div>
</body>
</html>
