<?php
  include_once('./inc/vs.php');
?>


<!doctype html>
<html itemscope="" itemtype="http://schema.org/WebPage" lang="ko">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title></title>
    <link rel="stylesheet" type="text/css" href="./css/reset.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.2/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="./css/style.css?<?=$ver?>">

</head>
<body>
    <div id="planPage">
        <div id="pContents">
            <div class="planPtop">
                <div class="planPtTitle">세이프플랜 1기 펀드</div>
                <div class="planPtStan">업데이트 기준: 2018년 6월 8일</div>
                <div class="planPtImg"><img src="" /></div>
            </div>
            <div class="planPmain">
                <div class="planPSum">
                    <div class="planPturns">
                        <div class="planPtLB">L</div>
                        <div class="planPtBef">1기</div>
                        <div class="planPtNow">2기</div>
                        <div class="planPtAft">3기</div>
                        <div class="planPtRB">R</div>
                        <div class="clear"></div>
                    </div>
                    <div class="planPSummary">
                        <div class="planPSumR">
                            <div class="planPsrTitle">전체 상품</div>
                            <div class="planPsrBar"></div>
                            <div class="planPsrP"><p><b>194</b>건</p></div>
                        </div>
                        <div class="planPSumR">
                            <div class="planPsrTitle">총 투자 금액</div>
                            <div class="planPsrBar"></div>
                            <div class="planPsrP"><p><b>8,558,440,000</b>원</p></div>
                        </div>
                        <div class="planPSumR">
                            <div class="planPsrTitle">상환중</div>
                            <div class="planPsrBar"></div>
                            <div class="planPsrP"><p><b>461</b>건</p></div>
                        </div>
                        <div class="planPSumR">
                            <div class="planPsrTitle">상환완료</div>
                            <div class="planPsrBar"></div>
                            <div class="planPsrP"><p><b>58</b>건</p></div>
                        </div>
                        <div class="planPSumR">
                            <div class="planPsrTitle">연체</div>
                            <div class="planPsrBar"></div>
                            <div class="planPsrP"><p><b>3</b>건</p></div>
                        </div>
                        <div class="planPSumR">
                            <div class="planPsrTitle">부실</div>
                            <div class="planPsrBar"></div>
                            <div class="planPsrP"><p><b>2</b>건</p></div>
                        </div>
                        <div class="clear"></div>
                    </div>
                </div>


                <div class="planPvis">
                    <div class="planPstat">
                        <div class="planPsTitle">세이프플랜 펀드 현황</div>
                        <div class="planPsRow">
                            <div class="planPsColL">적립 총액</div>
                            <div class="planPsColR">351,147,608 원</div>
                            <div class="clear"></div>
                        </div>
                        <div class="planPsRow">
                            <div class="planPsColL">사용액</div>
                            <div class="planPsColR">263,552,677 원</div>
                            <div class="clear"></div>
                        </div>
                        <div class="planPsRow">
                            <div class="planPsColL">잔액</div>
                            <div class="planPsColR">87,594,931 원</div>
                            <div class="clear"></div>
                        </div>
                        <div class="planPsG">
                            <div class="planPsgCon"></div><!--아래꺼가 빈거 기준이고-->
                            <div class="planPsgRem"></div><!--2개높이만큼 잡아놓고 위에꺼 회색을 아래꺼 z-1 에 겹침-->
                        </div>
                        <div class="planPsGstan"><!--바깥거 border l r 선주고-->
                        <div class="planPsGstanPin">사용액 263,552,677 원</div><!--내부꺼 보더 r만 선주고-->
                        </div>
                    </div>
                    <div class="planPLoss">
                        <div class="planPLtitle">원금 손실률</div>
                        <div class="planPLpos">
                            <div class="planPLg">
                                <div>0%</div>
                            </div>
                        </div>
                    </div>
                    <div class="clear"></div>
                </div>
                <div class="planPBanner">
                    <div class="planPBimg"><img src="" /></div>
                    <div class="planPBlogo">세이프플랜으로 안심하고 투자하세요</div>
                    <div class="planPBdet">자세히보기 &gt;</div>
                    <div class="clear"></div>
                </div>

                <div class="planPListTitle">세이프플랜 상품목록</div>
                <div class="PlanPListStan">
                    <div class="PlanPlsElem">세이프플랜</div>
                    <div class="PlanPlsElem">상환차수</div>
                    <div class="PlanPlsElem">상태</div>
                    <div class="PlanPlsElem">상환현황</div>
                    <div class="clear"></div>
                </div>
                <div class="planPeel">
                    <div class="planPEvalElem">
                        <div class="planPeeRo1">
                            <div class="planPeeI">266호</div>
                            <div class="planPeeI">참한아구</div>
                            <div class="clear"></div>
                        </div>
                        <div class="planPeeRo2"><img src="./img/11planicon01.png?<?=$ver?>" /></div>
                        <div class="planPeeRo3">
                            <div class="planPeeDisconNo">상환차수</div><!--display none-->
                            <div class="planPeeDisconNo">상태</div><!--display none-->
                            <div class="planPeeDisconNo">총상환금</div><!--display none-->
                            <div class="planPeeDisconYes1">15/18</div>
                            <div class="planPeeDisconYes2">상환중</div>
                            <div class="planPeeDisconYes3">총 상환금: 11,037,053원</div>
                            <div class="clear"></div>
                        </div>
                        <div class="planPeeRo4">상환금: 9,191,565원</div>
                        <div class="planPeeRo5">남은 상환금: 1,839,488원</div>
                        <div class="clear"></div>
                    </div>
                    <div class="planPEvalElem">
                        <div class="planPeeRo1">
                            <div class="planPeeI">266호</div>
                            <div class="planPeeI">참한아구</div>
                            <div class="clear"></div>
                        </div>
                        <div class="planPeeRo2"><img src="./img/11planicon01.png?<?=$ver?>" /></div>
                        <div class="planPeeRo3">
                            <div class="planPeeDisconNo">상환차수</div><!--display none-->
                            <div class="planPeeDisconNo">상태</div><!--display none-->
                            <div class="planPeeDisconNo">총상환금</div><!--display none-->
                            <div class="planPeeDisconYes1">15/18</div>
                            <div class="planPeeDisconYes2">상환중</div>
                            <div class="planPeeDisconYes3">총 상환금: 11,037,053원</div>
                            <div class="clear"></div>
                        </div>
                        <div class="planPeeRo4">상환금: 9,191,565원</div>
                        <div class="planPeeRo5">남은 상환금: 1,839,488원</div>
                        <div class="clear"></div>
                    </div>
                    <div class="planPEvalElem">
                        <div class="planPeeRo1">
                            <div class="planPeeI">266호</div>
                            <div class="planPeeI">참한아구</div>
                            <div class="clear"></div>
                        </div>
                        <div class="planPeeRo2"><img src="./img/11planicon01.png?<?=$ver?>" /></div>
                        <div class="planPeeRo3">
                            <div class="planPeeDisconNo">상환차수</div><!--display none-->
                            <div class="planPeeDisconNo">상태</div><!--display none-->
                            <div class="planPeeDisconNo">총상환금</div><!--display none-->
                            <div class="planPeeDisconYes1">15/18</div>
                            <div class="planPeeDisconYes2">상환중</div>
                            <div class="planPeeDisconYes3">총 상환금: 11,037,053원</div>
                            <div class="clear"></div>
                        </div>
                        <div class="planPeeRo4">상환금: 9,191,565원</div>
                        <div class="planPeeRo5">남은 상환금: 1,839,488원</div>
                        <div class="clear"></div>
                    </div>
                    <div class="planPEvalElem">
                        <div class="planPeeRo1">
                            <div class="planPeeI">266호</div>
                            <div class="planPeeI">참한아구</div>
                            <div class="clear"></div>
                        </div>
                        <div class="planPeeRo2"><img src="./img/11planicon01.png?<?=$ver?>" /></div>
                        <div class="planPeeRo3">
                            <div class="planPeeDisconNo">상환차수</div><!--display none-->
                            <div class="planPeeDisconNo">상태</div><!--display none-->
                            <div class="planPeeDisconNo">총상환금</div><!--display none-->
                            <div class="planPeeDisconYes1">15/18</div>
                            <div class="planPeeDisconYes2">상환중</div>
                            <div class="planPeeDisconYes3">총 상환금: 11,037,053원</div>
                            <div class="clear"></div>
                        </div>
                        <div class="planPeeRo4">상환금: 9,191,565원</div>
                        <div class="planPeeRo5">남은 상환금: 1,839,488원</div>
                        <div class="clear"></div>
                    </div>
                    <div class="planPEvalElem">
                        <div class="planPeeRo1">
                            <div class="planPeeI">266호</div>
                            <div class="planPeeI">참한아구</div>
                            <div class="clear"></div>
                        </div>
                        <div class="planPeeRo2"><img src="./img/11planicon01.png?<?=$ver?>" /></div>
                        <div class="planPeeRo3">
                            <div class="planPeeDisconNo">상환차수</div><!--display none-->
                            <div class="planPeeDisconNo">상태</div><!--display none-->
                            <div class="planPeeDisconNo">총상환금</div><!--display none-->
                            <div class="planPeeDisconYes1">15/18</div>
                            <div class="planPeeDisconYes2">상환중</div>
                            <div class="planPeeDisconYes3">총 상환금: 11,037,053원</div>
                            <div class="clear"></div>
                        </div>
                        <div class="planPeeRo4">상환금: 9,191,565원</div>
                        <div class="planPeeRo5">남은 상환금: 1,839,488원</div>
                        <div class="clear"></div>
                    </div>
                    <div class="planPEvalElem">
                        <div class="planPeeRo1">
                            <div class="planPeeI">266호</div>
                            <div class="planPeeI">참한아구</div>
                            <div class="clear"></div>
                        </div>
                        <div class="planPeeRo2"><img src="./img/11planicon01.png?<?=$ver?>" /></div>
                        <div class="planPeeRo3">
                            <div class="planPeeDisconNo">상환차수</div><!--display none-->
                            <div class="planPeeDisconNo">상태</div><!--display none-->
                            <div class="planPeeDisconNo">총상환금</div><!--display none-->
                            <div class="planPeeDisconYes1">15/18</div>
                            <div class="planPeeDisconYes2">상환중</div>
                            <div class="planPeeDisconYes3">총 상환금: 11,037,053원</div>
                            <div class="clear"></div>
                        </div>
                        <div class="planPeeRo4">상환금: 9,191,565원</div>
                        <div class="planPeeRo5">남은 상환금: 1,839,488원</div>
                        <div class="clear"></div>
                    </div>
                    <div class="planPEvalElem">
                        <div class="planPeeRo1">
                            <div class="planPeeI">266호</div>
                            <div class="planPeeI">참한아구</div>
                            <div class="clear"></div>
                        </div>
                        <div class="planPeeRo2"><img src="./img/11planicon01.png?<?=$ver?>" /></div>
                        <div class="planPeeRo3">
                            <div class="planPeeDisconNo">상환차수</div><!--display none-->
                            <div class="planPeeDisconNo">상태</div><!--display none-->
                            <div class="planPeeDisconNo">총상환금</div><!--display none-->
                            <div class="planPeeDisconYes1">15/18</div>
                            <div class="planPeeDisconYes2">상환중</div>
                            <div class="planPeeDisconYes3">총 상환금: 11,037,053원</div>
                            <div class="clear"></div>
                        </div>
                        <div class="planPeeRo4">상환금: 9,191,565원</div>
                        <div class="planPeeRo5">남은 상환금: 1,839,488원</div>
                        <div class="clear"></div>
                    </div>
                    <div class="planPEvalElem">
                        <div class="planPeeRo1">
                            <div class="planPeeI">266호</div>
                            <div class="planPeeI">참한아구</div>
                            <div class="clear"></div>
                        </div>
                        <div class="planPeeRo2"><img src="./img/11planicon01.png?<?=$ver?>" /></div>
                        <div class="planPeeRo3">
                            <div class="planPeeDisconNo">상환차수</div><!--display none-->
                            <div class="planPeeDisconNo">상태</div><!--display none-->
                            <div class="planPeeDisconNo">총상환금</div><!--display none-->
                            <div class="planPeeDisconYes1">15/18</div>
                            <div class="planPeeDisconYes2">상환중</div>
                            <div class="planPeeDisconYes3">총 상환금: 11,037,053원</div>
                            <div class="clear"></div>
                        </div>
                        <div class="planPeeRo4">상환금: 9,191,565원</div>
                        <div class="planPeeRo5">남은 상환금: 1,839,488원</div>
                        <div class="clear"></div>
                    </div>
                    <div class="planPEvalElem">
                        <div class="planPeeRo1">
                            <div class="planPeeI">266호</div>
                            <div class="planPeeI">참한아구</div>
                            <div class="clear"></div>
                        </div>
                        <div class="planPeeRo2"><img src="./img/11planicon01.png?<?=$ver?>" /></div>
                        <div class="planPeeRo3">
                            <div class="planPeeDisconNo">상환차수</div><!--display none-->
                            <div class="planPeeDisconNo">상태</div><!--display none-->
                            <div class="planPeeDisconNo">총상환금</div><!--display none-->
                            <div class="planPeeDisconYes1">15/18</div>
                            <div class="planPeeDisconYes2">상환중</div>
                            <div class="planPeeDisconYes3">총 상환금: 11,037,053원</div>
                            <div class="clear"></div>
                        </div>
                        <div class="planPeeRo4">상환금: 9,191,565원</div>
                        <div class="planPeeRo5">남은 상환금: 1,839,488원</div>
                        <div class="clear"></div>
                    </div>
                    <div class="planPEvalElem">
                        <div class="planPeeRo1">
                            <div class="planPeeI">266호</div>
                            <div class="planPeeI">참한아구</div>
                            <div class="clear"></div>
                        </div>
                        <div class="planPeeRo2"><img src="./img/11planicon01.png?<?=$ver?>" /></div>
                        <div class="planPeeRo3">
                            <div class="planPeeDisconNo">상환차수</div><!--display none-->
                            <div class="planPeeDisconNo">상태</div><!--display none-->
                            <div class="planPeeDisconNo">총상환금</div><!--display none-->
                            <div class="planPeeDisconYes1">15/18</div>
                            <div class="planPeeDisconYes2">상환중</div>
                            <div class="planPeeDisconYes3">총 상환금: 11,037,053원</div>
                            <div class="clear"></div>
                        </div>
                        <div class="planPeeRo4">상환금: 9,191,565원</div>
                        <div class="planPeeRo5">남은 상환금: 1,839,488원</div>
                        <div class="clear"></div>
                    </div>
                    <div class="planPEvalElem">
                        <div class="planPeeRo1">
                            <div class="planPeeI">266호</div>
                            <div class="planPeeI">참한아구</div>
                            <div class="clear"></div>
                        </div>
                        <div class="planPeeRo2"><img src="./img/11planicon01.png?<?=$ver?>" /></div>
                        <div class="planPeeRo3">
                            <div class="planPeeDisconNo">상환차수</div><!--display none-->
                            <div class="planPeeDisconNo">상태</div><!--display none-->
                            <div class="planPeeDisconNo">총상환금</div><!--display none-->
                            <div class="planPeeDisconYes1">15/18</div>
                            <div class="planPeeDisconYes2">상환중</div>
                            <div class="planPeeDisconYes3">총 상환금: 11,037,053원</div>
                            <div class="clear"></div>
                        </div>
                        <div class="planPeeRo4">상환금: 9,191,565원</div>
                        <div class="planPeeRo5">남은 상환금: 1,839,488원</div>
                        <div class="clear"></div>
                    </div>
                </div>


                <div class="planPlow">
                    <div class="planPlR">
                        <div class="planPlowElem">
                            <div class="planPlowEL">총 투자금액 </div>
                            <div class="planPlowER">5,296,570,000원</div>
                            <div class="clear"></div>
                        </div>
                        <div class="planPlowElem">
                            <div class="planPlowEL">총 상환금액 </div>
                            <div class="planPlowER">4,435,842,043원</div>
                            <div class="clear"></div>
                        </div>
                        <div class="planPlowElem">
                            <div class="planPlowEL">남은 상환금액 </div>
                            <div class="planPlowER">1,221,076,702원</div>
                            <div class="clear"></div>
                        </div>
                        <div class="clear"></div>
                    </div>
                    <div class="planPlR">
                        <div class="planPlInTitle">세이프플랜 펀드</div>
                        <div>
                            <div class="planPlowElem">
                                <div class="planPlowEL">적립 총액</div>
                                <div class="planPlowER">351,147,608원</div>
                                <div class="clear"></div>
                            </div>
                            <div class="planPlBar"></div>
                            <div class="planPlowElem">
                                <div class="planPlowEL">사용액</div>
                                <div class="planPlowER">263,552,677원</div>
                                <div class="clear"></div>
                            </div>
                            <div class="planPlBar"></div>
                            <div class="planPlowElem">
                                <div class="planPlowEL">잔액</div>
                                <div class="planPlowER">87,594,931원</div>
                                <div class="clear"></div>
                            </div>
                            <div class="planPlBar"></div>
                            <div class="planPlowElem">
                                <div class="planPlowEL">원금손실률</div>
                                <div class="planPlowER">0%</div>
                                <div class="clear"></div>
                            </div>
                            <div class="clear"></div>
                        </div>
                    </div>
                </div>

            </div>

        </div>
    </div>
</body>
</html>
