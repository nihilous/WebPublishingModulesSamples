<?php
  include_once('./inc/vs.php');
?>


<!doctype html>
<html itemscope="" itemtype="http://schema.org/WebPage" lang="ko">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title></title>
    <link rel="stylesheet" type="text/css" href="./css/reset.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.2/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="./css/style.css?<?=$ver?>">

</head>
<body>
    <div id="PlanFaQPage">
        <div id="pfContents">
            <div class="pfTop">
                <div class="pfTtitle">자주 묻는 질문</div>
                <div class="pfTseper"></div>
            </div>
            <div class="pfBox">
                <div class="pfbVis">
                    <div class="pfbIcon"><img src="./img/15planfaqicon01.png"<?=$ver?> /></div>
                    <div class="pfbMar"></div> <!--margin-->
                    <div class="pfbTitle">세이프플랜 상품에 투자하면 투자금액 전액을 보호받나요?</div>
                    <button class="pfbB"></button>
                    <div class="clear"></div>
                </div>
                <div class="pfbHid">
                    <div class="pfbIcon2"><img src="./img/15planfaqicon04.png"<?=$ver?>  /></div>
                    <div class="pfbInst"> 세이프플랜은 '세이프플랜 펀드'의 잔여 한도 내에서 보호되며, 세이프플랜 펀드의 적립금이 고갈되면 투자자도 손실을 보게 됩니다. 세이프플랜이 적용되면 약정된 상환일에 맞춰 해당회차의 투자 원금을 우선 지급하며, 이자는 추후 대출자가 해당회차의 원리금을 상환을 완료하면 후지급됩니다.</div>
                    <div class="clear"></div>
                </div>
            </div>
            <div class="pfBox">
                <div class="pfbVis">
                    <div class="pfbIcon"><img src="./img/15planfaqicon01.png"<?=$ver?> /></div>
                    <div class="pfbMar"></div> <!--margin-->
                    <div class="pfbTitle">세이프플랜 상품에 투자하면 투자금액 전액을 보호받나요?</div>
                    <button class="pfbB"></button>
                    <div class="clear"></div>
                </div>
                <div class="pfbHid">
                    <div class="pfbIcon2"><img src="./img/15planfaqicon04.png"<?=$ver?>  /></div>
                    <div class="pfbInst"> 세이프플랜은 '세이프플랜 펀드'의 잔여 한도 내에서 보호되며, 세이프플랜 펀드의 적립금이 고갈되면 투자자도 손실을 보게 됩니다. 세이프플랜이 적용되면 약정된 상환일에 맞춰 해당회차의 투자 원금을 우선 지급하며, 이자는 추후 대출자가 해당회차의 원리금을 상환을 완료하면 후지급됩니다.</div>
                    <div class="clear"></div>
                </div>
            </div>
            <div class="pfBox">
                <div class="pfbVis">
                    <div class="pfbIcon"><img src="./img/15planfaqicon01.png"<?=$ver?> /></div>
                    <div class="pfbMar"></div> <!--margin-->
                    <div class="pfbTitle">세이프플랜 상품에 투자하면 투자금액 전액을 보호받나요?</div>
                    <button class="pfbB"></button>
                    <div class="clear"></div>
                </div>
                <div class="pfbHid">
                    <div class="pfbIcon2"><img src="./img/15planfaqicon04.png"<?=$ver?>  /></div>
                    <div class="pfbInst"> 세이프플랜은 '세이프플랜 펀드'의 잔여 한도 내에서 보호되며, 세이프플랜 펀드의 적립금이 고갈되면 투자자도 손실을 보게 됩니다. 세이프플랜이 적용되면 약정된 상환일에 맞춰 해당회차의 투자 원금을 우선 지급하며, 이자는 추후 대출자가 해당회차의 원리금을 상환을 완료하면 후지급됩니다.</div>
                    <div class="clear"></div>
                </div>
            </div>
            <div class="pfExtB">세이프플랜에 대해 자주 묻는 질문 더보기<img src=""  /></div>
        </div>
    </div>
</body>
</html>
