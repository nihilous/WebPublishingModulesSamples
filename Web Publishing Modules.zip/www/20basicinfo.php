<?php
  include_once('./inc/vs.php');
?>


<!doctype html>
<html itemscope="" itemtype="http://schema.org/WebPage" lang="ko">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title></title>
    <link rel="stylesheet" type="text/css" href="./css/reset.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.2/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="./css/style.css?<?=$ver?>">

</head>
<body>
    <div id="BasicInfoPage">
        <div id="bicontents">
            <div class="biBox">
                <form method="post">
                    <div class="biInfoType">
                        <div class="biITelem1">기본정보</div>
                        <div class="biMargin"></div>
                        <div class="biITelem2">투자자정보</div>
                        <div class="biMargin"></div>
                        <div class="biITelem3">비밀번호 수정</div>
                        <div class="clear"></div>
                    </div>
                    <div class="bibInfos">
                        <div class="bibR1">
                            <div class="bibRl">이름</div>
                            <div class="bibRr"><input class="bibName" type="text" name="biName" value="이석진"/></div>
                            <div class="clear"></div>
                        </div>
                        <div class="bibR2">
                            <div class="bibRl">휴대전화</div>
                            <div class="bibRr">
                                <div class="bibI1"><input class="bibPhoneNum" type="text" name="biPhone" value="010-0000-1111"/></div>
                                <div class="bibI2  link_btn">변경</div>
                                <div class="clear"></div>
                            </div>
                            <div class="clear"></div>
                        </div>
                        <div class="bibR3">
                            <div class="bibRl">이메일</div>
                            <div class="bibRr"><input class="bibEmail" type="email" name="biEmail" value="abcd@efg.hij"/></div>
                            <div class="clear"></div>
                        </div>
                    </div>
                    <div class="bibRecCode">
                        <div class="bibRl">나의 추천인 코드</div>
                        <div class="bibRr">
                            <div class="bibRC1">A1B2C3</div>
                            <button class="bibRC2">코드복사하기</button>
                            <div class="bibRC3">※ 나의 추천인 코드를 입력하여 가입한 지인은 첫 투자 시 익월 10일 이내에 본인과 지인에게 2천원씩 리워드가 지급됩니다.</div>
                            <div class="clear"></div>
                        </div>
                        <div class="clear"></div>
                    </div>
                    <div class="bibMarkAgree">
                        <div class="bibRl">마케팅 동의</div>
                        <div class="bibRr">
                            <div class="bibMA1">알림 수신 동의시 테라펀딩 투자상품 오픈 정보/이벤트 소식 등을 제공 받으실 수 있습니다.</div>
                            <div class="bibMA2"><input name="biAgreeEmail" type="checkbox" /> 이메일 수신동의</div>
                            <div class="bibMA3"><input name="biAgreeSMS" type="checkbox" /> SMS 수신동의</div>
                            <div class="clear"></div>
                        </div>
                        <div class="clear"></div>
                    </div>
                    <div class="bibModify">
                        <div class="bibEdit">
                            <button type="submit" class="bibEditB">수정완료</button>
                        </div>
                        <div class="bibDelete"><p>테라펀딩 서비스를 더 이상 이용하지 않는다면? <b class="link_btn">[회원탈퇴]</b></p></div>
                        <div class="clear"></div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</body>
</html>
