<?php
  include_once('./inc/vs.php');
?>


﻿<!DOCTYPE html>

<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title></title>

    <style>

        * {
            margin: 0;
            padding: 0;
        }

        html {
            height: 100%;
        }

        body {
            height: 100%;
        }

        body {
            position: relative;
        }

        /*타블렛이하*/

        @media screen and (max-width: 765px) {
            #bankAccount {
                position: absolute;
                left: 0;
                top: 115px;
                width: 100%; /*765*/
                height: 100%;
            }

            #bankAccount .pageInfo {
                width: 100%; /*765*/
            }

            #bankAccount .bankSelect {
                position: absolute;
                top: 165px;
                left: 5px;
                width: 90%;
                z-index: -1;
            }

            #bankAccount .accountNumType {
                position: absolute;
                top: 240px;
                left: 5px;
                width: 72.5%;
                z-index: -1;
            }

            #bankAccount .submitButton {
                position: absolute;
                top: 320px;
                width: 100%;
                height: 60px;
            }
        }

        /*PC*/
        @media screen and (min-width: 766px) {
            #bankAccount {
                position: absolute;
                top: 50%;
                left: 50%;
                margin-left: -230px;
                margin-top: -190px;
                /*탑 레프트 둘다 50% 위드 460이니까 마진레프트 -230 탑 -190 위드의 절반*/
                width: 460px;
                height: 380px;
            }

            #bankAccount .pageInfo {
                position: absolute;
                width: 460px;
            }

            #bankAccount .bankSelect {
                position: absolute;
                top: 165px;
                left: 5px;
                width: 450px;
            }

            #bankAccount .accountNumType {
                position: absolute;
                top: 240px;
                left: 5px;
                width: 350px;
            }

            #bankAccount .submitButton {
                position: absolute;
                top: 320px;
                width: 460px;
                height: 60px;
            }
        }


        #bankAccount .pageInfo {
            position: absolute;
            top: 0px;
            left: 0px;
            height: 80px;
            border-bottom: solid;
            border-bottom-color: dodgerblue;
            border-bottom-width: thick;
        }

        #bankAccount .pageInfo .ProcessTitle {
            position: absolute;
            top: 15px;
            left: 30px;
            font-size:30px;
        }

        #bankAccount .pageInfo .ProcessNum {
            position: absolute;
            top: 25px;
            right: 30px;
            font-size:25px;
            color: dodgerblue;
        }

        #bankAccount .desc {
            position: absolute;
            top: 110px;
            left: 10px;
            height: 65px;
        }


        #bankAccount .bankSelect {
            border: none;
            border-bottom: 2px solid dodgerblue;
        }

        #bankAccount .accountNumType {
            border: none;
            border-bottom: 2px solid dodgerblue;
        }

        #bankAccount .phoneVerifyB {
            position: absolute;
            top: 230px;
            right: 5px;
            width: 115px;
            height: 35px;
            border-radius: 5px;
            border-color:dodgerblue;
            background-color:white;
            color: dodgerblue;
            text-align: center;
        }

        #bankAccount .verified {
            position: absolute;
            top: 285px;
            left: 5px;
        }

        #bankAccount .veriDesc {
            position: absolute;
            top: 280px;
            left: 40px;
        }

        #bankAccount .submitButton {
                font-size:20px;
                border:none;
                background-color:#d1d1d1;
            }

    </style>
</head>
<body>
    <div id="bankAccount">
        <!-- pc width 450 height 370--->    <!--모바일 width 765-->
        <div class="pageInfo">
            <p class="ProcessTitle"><b>출금 전용</b> 계좌 등록</p>
            <p class="ProcessNum">3/3</p>
        </div>
        <div class="desc">
            <p>출금전용 계좌를 등록해주세요</p>
        </div>
        <form method="post">
            <select class="bankSelect" name="bankCode">
                <option value="">은행을 선택해 주세요.</option>
                <option value="">경남은행</option>
                <option value="">광주은행</option>
                <option value="">국민은행</option>
                <option value="">기업은행</option>
                <option value="">농협은행(중앙회)</option>
                <option value="">농축협(지역농협)</option>
                <option value="">대구은행</option>
                <option value="">부산은행</option>
                <option value="">산업은행</option>
                <option value="">수협중앙회</option>
                <option value="">신한은행</option>
                <option value="">우리은행</option>
                <option value="">전북은행</option>
                <option value="">제주은행</option>
                <option value="">KEB하나은행(구 외환은행)</option>
                <option value="">한국씨티은행</option>
                <option value="">HSBC은행</option>
                <option value="">SC은행</option>
                <option value="">케이뱅크</option>
                <option value="">카카오뱅크</option>
                <option value="">도이치은행</option>
                <option value="">BOA은행</option>
                <option value="">BNP은행</option>
                <option value="">산림조합</option>
                <option value="">상호저축은행</option>
                <option value="">새마을금고</option>
                <option value="">신협중앙회</option>
                <option value="">우체국</option>
                <option value="">JP모간 체이스</option>
                <option value="">중국공상은행</option>
            </select>
            <div>
                <span>
                    <input class="accountNumType" type="text" name="accountNum" placeholder="계좌번호 입력    - 숫자만 입력해주십시오." />
                </span>
                <span>
                    <button class="phoneVerifyB">명의자 본인확인</button>
                </span>
            </div>
            <div>
                <input class="verified" type="checkbox" />
                <p class="veriDesc">계좌 명의의 실 소유자임을 확인하였습니다.</p>
            </div>
            <div>
                <input class="submitButton" value="선택 은행을 출금계좌로 등록" type="submit" />
            </div>
        </form>
    </div>
</body>
</html>
