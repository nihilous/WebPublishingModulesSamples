<?php
  include_once('./inc/vs.php');
?>



<!doctype html>
<html itemscope="" itemtype="http://schema.org/WebPage" lang="ko">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title></title>
    <link rel="stylesheet" type="text/css" href="./css/reset.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.2/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="./css/style.css?<?=$ver?>">

</head>
<body>
    <div id="loanCondition">
        <div class="lcCont">
            <form>
                <div class="lcTitle">이름</div>
                <div class="lcInputPos">
                  <input class="lcInputText" type="text" placeholder="한글로 실명을 적어주세요."/>
                </div>
                <div class="lcNameWarn">한글로 실명을 적어주세요.</div>
                <div class="lcTitle">생년월일</div>
                <div class="lcInputPos">
                    <select class="lcBD">
                        <option>생년</option>
                        <option>1</option>
                    </select>
                    <select class="lcBD">
                        <option>월</option>
                        <option>1</option>
                    </select>
                    <select class="lcBD">
                        <option>일</option>
                        <option>1</option>
                    </select>
                    <div class="clear"></div>
                </div>
                <div class="lcTitle">전화번호</div>
                <div class="lcInputPos">
                  <input class="lcInputText" type="text"  placeholder="전화번호를 적어주세요."/>
                </div>
                <div class="lcTitle">성별</div>
                <div class="lcInputPos">
                  <div class="lcGender">
                    <input id="lcGM" type="radio" name="lcGenderSelected"/>
                    <label for="lcGM">남자</label>
                  </div>
                  <div class="lcGender">
                    <input id="lcGF" type="radio" name="lcGenderSelected"/>
                    <label for="lcGF">여자</label>
                  </div>
                  <div class="clear"></div>
                </div>
                <div class="lcTitle">대출목적</div>
                <div class="lcInputPos">
                  <select class="lcPurpose">
                      <option>선택해주세요</option>
                      <option>기존 대출 전환</option>
                      <option>전월세 보증금</option>
                      <option>주택구입</option>
                      <option>차량구입</option>
                      <option>생활비</option>
                      <option>투자</option>
                      <option>부업자금</option>
                  </select>
                </div>
                <div class="lcTitle">신청금액</div>
                <div class="lcInputPos">
                  <input class="lcInputAmount" type="text"  placeholder="금액을 입력해주세요."/>
                  <div class="lcStan">만원</div>
                  <div class="clear"></div>
                </div>
                <div class="lcAmountWarn">신청금액을 입력해주세요.</div>
                <div class="lcInst">대출 가능여부 확인을 위한 신용조회는 신용등급에 영향을 주지 않습니다.</div>
                <div class="lcSubmitB">대출 가능여부 확인하기</div>
                <div class="lcLogin">
                  <p>신청내역이 있으신가요? <b>로그인하기</b></p>
                </div>
            </form>
        </div>

    </div>
</body>
</html>
