<?php
  include_once('./inc/vs.php');
?>


<!doctype html>
<html itemscope="" itemtype="http://schema.org/WebPage" lang="ko">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title></title>
    <link rel="stylesheet" type="text/css" href="./css/reset.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.2/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="./css/style.css?<?=$ver?>">

</head>
<body>
    <div id="prPage">
        <div id="PassResetContents">
            <div class="prBox">
                <form method="post">
                    <div class="pbTitle">비밀번호 재설정</div>
                    <div class="pbBar"></div>
                    <div class="pbNsection">이름</div>
                    <div class="pbNinputPos">
                        <input type="text" name="prName" placeholder="이름을 입력해주세요." />
                    </div>
                    <div class="pbRNsection">주민등록 번호</div>
                    <div class="pbRNinputPos">
                        <div class="pbrnA">
                            <input class="" type="text" name="prResiNumA" placeholder="주민등록번호 앞자리" />
                        </div>
                        <div class="pbrnB">
                            <input type="text" name="prResiNumB" placeholder="주민등록번호 뒷자리" />
                        </div>
                        <div class="clear"></div>
                    </div>
                    <div class="pbPhoneSection">
                        <div class="pbCompany">통신사</div>
                        <div class="pbPhoneNum">휴대폰 번호</div>
                        <div class="clear"></div>
                    </div>
                    <div class="pbPhonePos">
                        <div class="pbMobComSelPos">
                            <select class="pbMobComSelector" name="prMcompany">
                                <option value="">선택</option>
                                <option value="">SKT</option>
                                <option value="">KT</option>
                                <option value="">LGT</option>
                                <option value="">알뜰폰(SKT)</option>
                                <option value="">알뜰폰(KT)</option>
                                <option value="">알뜰폰(LG)</option>
                            </select>
                        </div>
                        <div class="pbPhoneNumPos">
                            <input type="text" name="prPhoneNum" placeholder="휴대폰 번호 입력" />
                        </div>
                        <div class="pbAskVerify">인증 번호 요청</div>
                        <div class="clear"></div>
                    </div>
                    <div class="pbWarn">인증번호 요청 버튼을 눌러 <a href="#">개인정보 수집/이용</a>, <a href="#">고유식별정보 처리</a>, <a href="#">통신사 이용약관</a>, <a href="#">서비스 이용약관</a>, <a href="#">개인정보 제 3자 제공</a>을 확인하였으며, 동의합니다.</div>
                </form>
            </div>
        </div>
    </div>
</body>
</html>
