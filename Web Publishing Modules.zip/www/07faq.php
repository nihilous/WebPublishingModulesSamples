<?php
  include_once('./inc/vs.php');
?>


<!doctype html>
<html itemscope="" itemtype="http://schema.org/WebPage" lang="ko">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title></title>
    <link rel="stylesheet" type="text/css" href="./css/reset.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.2/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="./css/style.css?<?=$ver?>">

</head>
<body>
    <div id="faqPage">
        <div id="faqContents">
            <div class="faqTop">
                <div class="faqTtitle">자주하는질문(FAQ)</div>
                <div class="faqTlinks">
                    <div class="faqTl">기타질문</div>
                    <div class="faqVertBar"></div>
                    <div class="faqTl">대출관련</div>
                    <div class="faqVertBar"></div>
                    <div class="faqTl">투자관련</div>
                    <div class="clear"></div>
                </div>
                <div class="clear"></div>
            </div>
            <div class="faqBox">
                <div class="fbTop">
                    <div class="fbTitle">01. 부동산 P2P투자란 무엇인가요?</div>
                    <div class="FBTextbPos">
                    <button class="fbtExtB"></button>
                    </div>
                    <div class="clear"></div>
                </div>
                <div class="fbDesc">
                    P2P금융은 온라인을 통해 다수의 개인으로부터 자금을 모아 투자/대출하는 핀테크 방식으로, 최근 새로운 재테크 수단으로 각광받고 있습니다.<br/><br/>
                    부동산 P2P금융은 부동산을 담보로 자금이 필요한 대출자와 투자를 원하는 개인 투자자를 연결해 드립니다.<br/><br/>
                    대출자에게는 합리적인 금리로 필요한 자금을 제공해드리고 투자자에게는 시중 금융상품 대비 높은 수익률을 올릴 수 있도록 해주는 새로운 형태의 금융상품입니다.</p>
                </div>
            </div>
            <div class="faqBox">
                <div class="fbTop">
                    <div class="fbTitle">01. 부동산 P2P투자란 무엇인가요?</div>
                    <div class="FBTextbPos">
                    <button class="fbtExtB"></button>
                    </div>
                    <div class="clear"></div>
                </div>
                <div class="fbDesc">
                    <p>P2P금융은 온라인을 통해 다수의 개인으로부터 자금을 모아 투자/대출하는 핀테크 방식으로, 최근 새로운 재테크 수단으로 각광받고 있습니다.</p><br/><br/>
                    <p>부동산 P2P금융은 부동산을 담보로 자금이 필요한 대출자와 투자를 원하는 개인 투자자를 연결해 드립니다.</p><br/><br/>
                    <p>대출자에게는 합리적인 금리로 필요한 자금을 제공해드리고 투자자에게는 시중 금융상품 대비 높은 수익률을 올릴 수 있도록 해주는 새로운 형태의 금융상품입니다.</p>
                </div>
            </div>
            <div class="faqBox">
                <div class="fbTop">
                    <div class="fbTitle">01. 부동산 P2P투자란 무엇인가요?</div>
                    <div class="FBTextbPos">
                    <button class="fbtExtB"></button>
                    </div>
                    <div class="clear"></div>
                </div>
                <div class="fbDesc">
                    <p>P2P금융은 온라인을 통해 다수의 개인으로부터 자금을 모아 투자/대출하는 핀테크 방식으로, 최근 새로운 재테크 수단으로 각광받고 있습니다.</p><br/><br/>
                    <p>부동산 P2P금융은 부동산을 담보로 자금이 필요한 대출자와 투자를 원하는 개인 투자자를 연결해 드립니다.</p><br/><br/>
                    <p>대출자에게는 합리적인 금리로 필요한 자금을 제공해드리고 투자자에게는 시중 금융상품 대비 높은 수익률을 올릴 수 있도록 해주는 새로운 형태의 금융상품입니다.</p>
                </div>
            </div>
            <div class="faqBox">
                <div class="fbTop">
                    <div class="fbTitle">01. 부동산 P2P투자란 무엇인가요?</div>
                    <div class="FBTextbPos">
                    <button class="fbtExtB"></button>
                    </div>
                    <div class="clear"></div>
                </div>
                <div class="fbDesc">
                    <p>P2P금융은 온라인을 통해 다수의 개인으로부터 자금을 모아 투자/대출하는 핀테크 방식으로, 최근 새로운 재테크 수단으로 각광받고 있습니다.</p><br/><br/>
                    <p>부동산 P2P금융은 부동산을 담보로 자금이 필요한 대출자와 투자를 원하는 개인 투자자를 연결해 드립니다.</p><br/><br/>
                    <p>대출자에게는 합리적인 금리로 필요한 자금을 제공해드리고 투자자에게는 시중 금융상품 대비 높은 수익률을 올릴 수 있도록 해주는 새로운 형태의 금융상품입니다.</p>
                </div>
            </div>
            <div class="faqBox">
                <div class="fbTop">
                    <div class="fbTitle">01. 부동산 P2P투자란 무엇인가요?</div>
                    <div class="FBTextbPos">
                    <button class="fbtExtB"></button>
                    </div>
                    <div class="clear"></div>
                </div>
                <div class="fbDesc">
                    <p>P2P금융은 온라인을 통해 다수의 개인으로부터 자금을 모아 투자/대출하는 핀테크 방식으로, 최근 새로운 재테크 수단으로 각광받고 있습니다.</p><br/><br/>
                    <p>부동산 P2P금융은 부동산을 담보로 자금이 필요한 대출자와 투자를 원하는 개인 투자자를 연결해 드립니다.</p><br/><br/>
                    <p>대출자에게는 합리적인 금리로 필요한 자금을 제공해드리고 투자자에게는 시중 금융상품 대비 높은 수익률을 올릴 수 있도록 해주는 새로운 형태의 금융상품입니다.</p>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
