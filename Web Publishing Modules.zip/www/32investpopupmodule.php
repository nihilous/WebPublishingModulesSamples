<?php
  include_once('./inc/vs.php');
?>



<!doctype html>
<html itemscope="" itemtype="http://schema.org/WebPage" lang="ko">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title></title>
    <link rel="stylesheet" type="text/css" href="./css/reset.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.2/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="./css/style.css?<?=$ver?>">

</head>
<body>
    <div id="InvestPopupModule">
      <form>
        <div class="IPmodule">
          <div>
            <div>투자할곳이름</div>
            <div>X</div>
          </div>
          <div>
            <div>
                <input type="text" />
                <div>만원</div>
            </div>
            <div>
              <div>100만</div>
              <div>10만</div>
              <div>1만</div>
              <div>정정</div>
            </div>
            <div>
              <div>최대 투자 한도</div>
              <div>
                <p><b>500</b> 만원</p>
              </div>
            </div>
            <div>
              <div>나의 계좌 잔액</div>
              <div>
                <p><b>500</b> 원</p>
              </div>
            </div>
            <div>
              <div>연 수익률</div>
              <div>
                <p><b>9.1</b>%</p>
              </div>
            </div>
            <div>투자하기</div>
            <div>상환일정 보기</div>
          </div>
        </div>
      </form>
    </div>
</body>
</html>
