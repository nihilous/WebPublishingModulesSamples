<?php
  include_once('./inc/vs.php');
?>


<!doctype html>
<html itemscope="" itemtype="http://schema.org/WebPage" lang="ko">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title></title>
    <link rel="stylesheet" type="text/css" href="./css/reset.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.2/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="./css/style.css?<?=$ver?>">

</head>
<body>
    <div id="PointLogPage">
        <div id="plContents">
            <div class="plBox">
                <div class="plbTop">
                    <div class="plbtR1">
                        <div class="plbtTitle">포인트 내역</div>
                        <button class="plbtB">포인트 쿠폰 입력</button>
                        <div class="clear"></div>
                    </div>
                    <div class="plbtR2">
                        <div class="plbtValid"><p>사용가능한 포인트 : <b>0</b>P</p></div>
                        <div class="plbtMargin"></div>
                        <div class="plbtExpiry"><p>6월 소멸 포인트 : <b>0</b>P</p></div>
                        <div class="clear"></div>
                    </div>
                </div>
                <div class="plbBot">
                    <div class="plbbStan">
                        <div class="plbbS1">날짜</div>
                        <div class="plbbS2">구분</div>
                        <div class="plbbS3">금액</div>
                        <div class="plbbS4">비고</div>
                        <div class="clear"></div>
                    </div>
                    <div class="plbbValue">
                        <div class="plbbvR">
                            <div class="plbbv1">2018.06.09</div>
                            <div class="plbbv2">소멸</div>
                            <div class="plbbv3"><p>-<b>10,000</b>원</p></div>
                            <div class="plbbv4">유효 기간 만료</div>
                            <div class="clear"></div>
                        </div>
                        <div class="plbbvR">
                            <div class="plbbv1">2018.06.09</div>
                            <div class="plbbv2">적립</div>
                            <div class="plbbv3"><p><b>10,000</b>원</p></div>
                            <div class="plbbv4">[1A] 첫투자 응원 포인트</div>
                            <div class="clear"></div>
                        </div>
                        <div class="plbbvR">
                            <div class="plbbv1">2018.06.09</div>
                            <div class="plbbv2">소멸</div>
                            <div class="plbbv3"><p>-<b>10,000</b>원</p></div>
                            <div class="plbbv4">유효 기간 만료</div>
                            <div class="clear"></div>
                        </div>
                        <div class="plbbvR">
                            <div class="plbbv1">2018.06.09</div>
                            <div class="plbbv2">적립</div>
                            <div class="plbbv3"><p><b>10,000</b>원</p></div>
                            <div class="plbbv4">[1B] 첫투자 응원 포인트</div>
                            <div class="clear"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
