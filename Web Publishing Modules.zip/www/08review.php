<?php
  include_once('./inc/vs.php');
?>


<!doctype html>
<html itemscope="" itemtype="http://schema.org/WebPage" lang="ko">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title></title>
    <link rel="stylesheet" type="text/css" href="./css/reset.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.2/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="./css/style.css?<?=$ver?>">

</head>
<body>
    <div id="reviewPage">
        <div id="reviewContents">
            <div class="reviewTop">
                <div class="reviewTitle">테라펀딩</div>
            </div>
            <div class="reviewBox">
                <img class="rbImg" src="./img/08mainimgsample.png?<?=$ver?>" />
                <div class="rbTitle">
                    하루하루 더 행복하게 살기 위해 테라펀딩으로 미래 준비를 - 김정희님
                </div>
                <div class="rbCounter" >
                        <img src="./img/08reviewcountericon.png?<?=$ver?>" >333
                </div>
                30대부터는 돈 관리를 다르게 해야겠다고 마음먹었습니다. 주변에는 주식을 하는 친구들도 있고, 가상화폐에 빠져든 친구들도 있었지만, 저는 그런 쪽의 투자는 아직 이르다는 생각이 들었습니다.그래서 좀 더 가벼우면서 ‘투자’라는 것을 시작하기에 좋은 것을 알아보다가 테라펀딩을 알게 되었습니다. 처음 투자를 시작한 건데, 수익률도 정말 높고 무엇보다 정말 간편합니다. 제가 잘 모르는 분야에 대해 전문가들이 대신 평가, 심사를 해주고, 매월 관리도 해주니 믿고 투자할 수 있었습니다.
                <div class="clear"></div>
            </div>
            <div class="reviewBox">
                <img class="rbImg" src="./img/08mainimgsample.png?<?=$ver?>" />
                <div class="rbTitle">
                    하루하루 더 행복하게 살기 위해 테라펀딩으로 미래 준비를 - 김정희님
                </div>
                <div class="rbCounter" >
                        <img src="./img/08reviewcountericon.png?<?=$ver?>" >333
                </div>
                30대부터는 돈 관리를 다르게 해야겠다고 마음먹었습니다. 주변에는 주식을 하는 친구들도 있고, 가상화폐에 빠져든 친구들도 있었지만, 저는 그런 쪽의 투자는 아직 이르다는 생각이 들었습니다.그래서 좀 더 가벼우면서 ‘투자’라는 것을 시작하기에 좋은 것을 알아보다가 테라펀딩을 알게 되었습니다. 처음 투자를 시작한 건데, 수익률도 정말 높고 무엇보다 정말 간편합니다. 제가 잘 모르는 분야에 대해 전문가들이 대신 평가, 심사를 해주고, 매월 관리도 해주니 믿고 투자할 수 있었습니다.
                <div class="clear"></div>
            </div>
            <div class="reviewBox">
                <img class="rbImg" src="./img/08mainimgsample.png?<?=$ver?>" />
                <div class="rbTitle">
                    하루하루 더 행복하게 살기 위해 테라펀딩으로 미래 준비를 - 김정희님
                </div>
                <div class="rbCounter" >
                        <img src="./img/08reviewcountericon.png?<?=$ver?>" >333
                </div>
                30대부터는 돈 관리를 다르게 해야겠다고 마음먹었습니다. 주변에는 주식을 하는 친구들도 있고, 가상화폐에 빠져든 친구들도 있었지만, 저는 그런 쪽의 투자는 아직 이르다는 생각이 들었습니다.그래서 좀 더 가벼우면서 ‘투자’라는 것을 시작하기에 좋은 것을 알아보다가 테라펀딩을 알게 되었습니다. 처음 투자를 시작한 건데, 수익률도 정말 높고 무엇보다 정말 간편합니다. 제가 잘 모르는 분야에 대해 전문가들이 대신 평가, 심사를 해주고, 매월 관리도 해주니 믿고 투자할 수 있었습니다.
                <div class="clear"></div>
            </div>
            <div class="reviewBox">
                <img class="rbImg" src="./img/08mainimgsample.png?<?=$ver?>" />
                <div class="rbTitle">
                    하루하루 더 행복하게 살기 위해 테라펀딩으로 미래 준비를 - 김정희님
                </div>
                <div class="rbCounter" >
                        <img src="./img/08reviewcountericon.png?<?=$ver?>" >333
                </div>
                30대부터는 돈 관리를 다르게 해야겠다고 마음먹었습니다. 주변에는 주식을 하는 친구들도 있고, 가상화폐에 빠져든 친구들도 있었지만, 저는 그런 쪽의 투자는 아직 이르다는 생각이 들었습니다.그래서 좀 더 가벼우면서 ‘투자’라는 것을 시작하기에 좋은 것을 알아보다가 테라펀딩을 알게 되었습니다. 처음 투자를 시작한 건데, 수익률도 정말 높고 무엇보다 정말 간편합니다. 제가 잘 모르는 분야에 대해 전문가들이 대신 평가, 심사를 해주고, 매월 관리도 해주니 믿고 투자할 수 있었습니다.
                <div class="clear"></div>
            </div>
            <div class="reviewBox">
                <img class="rbImg" src="./img/08mainimgsample.png?<?=$ver?>" />
                <div class="rbTitle">
                    하루하루 더 행복하게 살기 위해 테라펀딩으로 미래 준비를 - 김정희님
                </div>
                <div class="rbCounter" >
                        <img src="./img/08reviewcountericon.png?<?=$ver?>" >333
                </div>
                30대부터는 돈 관리를 다르게 해야겠다고 마음먹었습니다. 주변에는 주식을 하는 친구들도 있고, 가상화폐에 빠져든 친구들도 있었지만, 저는 그런 쪽의 투자는 아직 이르다는 생각이 들었습니다.그래서 좀 더 가벼우면서 ‘투자’라는 것을 시작하기에 좋은 것을 알아보다가 테라펀딩을 알게 되었습니다. 처음 투자를 시작한 건데, 수익률도 정말 높고 무엇보다 정말 간편합니다. 제가 잘 모르는 분야에 대해 전문가들이 대신 평가, 심사를 해주고, 매월 관리도 해주니 믿고 투자할 수 있었습니다.
                <div class="clear"></div>
            </div>
        </div>
    </div>
</body>
</html>
