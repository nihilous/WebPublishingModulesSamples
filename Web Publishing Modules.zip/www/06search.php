<?php
  include_once('./inc/vs.php');
?>﻿

<!doctype html>
<html itemscope="" itemtype="http://schema.org/WebPage" lang="ko">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title></title>
    <link rel="stylesheet" type="text/css" href="./css/reset.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.2/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="./css/style.css?<?=$ver?>">

</head>
<body>
    <div id="searchPage">
        <div id="searchContents">
            <div class="spTopBar">
                <div class="spTopBG">
                    <div class="sptB">투자 가이드 바로가기</div>
                    <div class="sptB">자동투자서비스 안내</div>
                    <div class="clear"></div>
                </div>
                <form method="get">
                <div class="searchPos">
                    <input class="SPsearchInput" type="text" name="pKeyword" placeholder="검색어를 입력하세요."/>
                    <img class="searchIconImg" src="./img/06searchicon.png?<?=$ver?>" />
                </div>
                <div class="spTopSG">
                    <select class="spSelector" name="searchOptionStat">
                        <option value=""><img src="./img/06staticon01.png?<?=$ver?>" />채권상태</option>
                        <option value=""><img src="./img/06staticon01.png?<?=$ver?>" />전체</option>
                    </select>
                    <select class="spSelector" name="searchOptionPref">
                        <option value="">상품유형</option>
                        <option value="">전체</option>
                    </select>
                    <div class="clear"></div>
                </div>
                </form>
                <div class="clear"></div>
            </div>
            <div class="products">
                <div class="product">
                    <div class="pImgPos">
                        <img class="pIMG" src="./img/06sampleimg.png?<?=$ver?>" />
                        <div class="piBanner">
                            <div class="pibPriority">1순위</div>
                            <div class="pibInvest">자동투자 40%</div>
                            <div class="clear"></div>
                        </div>
                    </div>
                    <div class="proDesc">
                        <div class="proTitle">제1156차 서산 테크노밸리 근린생활시설 신축사업 25차</div>
                        <div class="proPeriod">모집기간 : 2018.06.11 ~ 2018.06.18</div>
                        <div class="proBoxes">
                            <div class="proB">
                                <div class="pbR">수익률(연)</div>
                                <div class="pbR">14.5%</div>
                            </div>
                            <div class="proB">
                                <div class="pbR">투자기간</div>
                                <div class="pbR">9개월</div>
                            </div>
                            <div class="proB">
                                <div class="pbR">등급</div>
                                <div class="pbR">C3</div>
                            </div>
                            <div class="clear"></div>
                        </div>
                        <div class="proProgress">
                            <div class="ppText">펀딩 진행률</div>
                            <div class="ppPercent">0%</div>
                            <div class="clear"></div>
                        </div>
                        <div class="ppVis"><!--펀딩진행률-->
                            <div class="ppvEmptyG"></div><!--빈그래프-->
                            <div class="ppvFillG"></div><!--실진행그래프-->
                        </div>
                        <div class="ppCondiiton">
                            <div class="ppNnG">
                                <div class="ppNow">0원(0명)</div>
                                <div class="ppGoal"> / 3억원</div>
                                <div class="clear"></div>
                            </div>
                            <div class="ppStat">
                                <img src="./img/06staticon01.png?<?=$ver?>" /> 대기중
                            </div>
                            <div class="clear"></div>
                        </div>
                    </div>
                </div>
                <div class="product">
                    <div class="pImgPos">
                        <img class="pIMG" src="./img/06sampleimg.png?<?=$ver?>" />
                        <div class="piBanner">
                            <div class="pibPriority">1순위</div>
                            <div class="pibInvest">자동투자 40%</div>
                            <div class="clear"></div>
                        </div>
                    </div>
                    <div class="proDesc">
                        <div class="proTitle">제1156차 서산 테크노밸리 근린생활시설 신축사업 25차</div>
                        <div class="proPeriod">모집기간 : 2018.06.11 ~ 2018.06.18</div>
                        <div class="proBoxes">
                            <div class="proB">
                                <div class="pbR">수익률(연)</div>
                                <div class="pbR">14.5%</div>
                            </div>
                            <div class="proB">
                                <div class="pbR">투자기간</div>
                                <div class="pbR">9개월</div>
                            </div>
                            <div class="proB">
                                <div class="pbR">등급</div>
                                <div class="pbR">C3</div>
                            </div>
                            <div class="clear"></div>
                        </div>
                        <div class="proProgress">
                            <div class="ppText">펀딩 진행률</div>
                            <div class="ppPercent">0%</div>
                            <div class="clear"></div>
                        </div>
                        <div class="ppVis"><!--펀딩진행률-->
                            <div class="ppvEmptyG"></div><!--빈그래프-->
                            <div class="ppvFillG"></div><!--실진행그래프-->
                        </div>
                        <div class="ppCondiiton">
                            <div class="ppNnG">
                                <div class="ppNow">0원(0명)</div>
                                <div class="ppGoal"> / 3억원</div>
                                <div class="clear"></div>
                            </div>
                            <div class="ppStat">
                                <img src="./img/06staticon01.png?<?=$ver?>" /> 대기중
                            </div>
                            <div class="clear"></div>
                        </div>
                    </div>
                </div>
                <div class="product">
                    <div class="pImgPos">
                        <img class="pIMG" src="./img/06sampleimg.png?<?=$ver?>" />
                        <div class="piBanner">
                            <div class="pibPriority">1순위</div>
                            <div class="pibInvest">자동투자 40%</div>
                            <div class="clear"></div>
                        </div>
                    </div>
                    <div class="proDesc">
                        <div class="proTitle">제1156차 서산 테크노밸리 근린생활시설 신축사업 25차</div>
                        <div class="proPeriod">모집기간 : 2018.06.11 ~ 2018.06.18</div>
                        <div class="proBoxes">
                            <div class="proB">
                                <div class="pbR">수익률(연)</div>
                                <div class="pbR">14.5%</div>
                            </div>
                            <div class="proB">
                                <div class="pbR">투자기간</div>
                                <div class="pbR">9개월</div>
                            </div>
                            <div class="proB">
                                <div class="pbR">등급</div>
                                <div class="pbR">C3</div>
                            </div>
                            <div class="clear"></div>
                        </div>
                        <div class="proProgress">
                            <div class="ppText">펀딩 진행률</div>
                            <div class="ppPercent">0%</div>
                            <div class="clear"></div>
                        </div>
                        <div class="ppVis"><!--펀딩진행률-->
                            <div class="ppvEmptyG"></div><!--빈그래프-->
                            <div class="ppvFillG"></div><!--실진행그래프-->
                        </div>
                        <div class="ppCondiiton">
                            <div class="ppNnG">
                                <div class="ppNow">0원(0명)</div>
                                <div class="ppGoal"> / 3억원</div>
                                <div class="clear"></div>
                            </div>
                            <div class="ppStat">
                                <img src="./img/06staticon01.png?<?=$ver?>" /> 대기중
                            </div>
                            <div class="clear"></div>
                        </div>
                    </div>
                </div>
                <div class="product">
                    <div class="pImgPos">
                        <img class="pIMG" src="./img/06sampleimg.png?<?=$ver?>" />
                        <div class="piBanner">
                            <div class="pibPriority">1순위</div>
                            <div class="pibInvest">자동투자 40%</div>
                            <div class="clear"></div>
                        </div>
                    </div>
                    <div class="proDesc">
                        <div class="proTitle">제1156차 서산 테크노밸리 근린생활시설 신축사업 25차</div>
                        <div class="proPeriod">모집기간 : 2018.06.11 ~ 2018.06.18</div>
                        <div class="proBoxes">
                            <div class="proB">
                                <div class="pbR">수익률(연)</div>
                                <div class="pbR">14.5%</div>
                            </div>
                            <div class="proB">
                                <div class="pbR">투자기간</div>
                                <div class="pbR">9개월</div>
                            </div>
                            <div class="proB">
                                <div class="pbR">등급</div>
                                <div class="pbR">C3</div>
                            </div>
                            <div class="clear"></div>
                        </div>
                        <div class="proProgress">
                            <div class="ppText">펀딩 진행률</div>
                            <div class="ppPercent">0%</div>
                            <div class="clear"></div>
                        </div>
                        <div class="ppVis"><!--펀딩진행률-->
                            <div class="ppvEmptyG"></div><!--빈그래프-->
                            <div class="ppvFillG"></div><!--실진행그래프-->
                        </div>
                        <div class="ppCondiiton">
                            <div class="ppNnG">
                                <div class="ppNow">0원(0명)</div>
                                <div class="ppGoal"> / 3억원</div>
                                <div class="clear"></div>
                            </div>
                            <div class="ppStat">
                                <img src="./img/06staticon01.png?<?=$ver?>" /> 대기중
                            </div>
                            <div class="clear"></div>
                        </div>
                    </div>
                </div>
                <div class="product">
                    <div class="pImgPos">
                        <img class="pIMG" src="./img/06sampleimg.png?<?=$ver?>" />
                        <div class="piBanner">
                            <div class="pibPriority">1순위</div>
                            <div class="pibInvest">자동투자 40%</div>
                            <div class="clear"></div>
                        </div>
                    </div>
                    <div class="proDesc">
                        <div class="proTitle">제1156차 서산 테크노밸리 근린생활시설 신축사업 25차</div>
                        <div class="proPeriod">모집기간 : 2018.06.11 ~ 2018.06.18</div>
                        <div class="proBoxes">
                            <div class="proB">
                                <div class="pbR">수익률(연)</div>
                                <div class="pbR">14.5%</div>
                            </div>
                            <div class="proB">
                                <div class="pbR">투자기간</div>
                                <div class="pbR">9개월</div>
                            </div>
                            <div class="proB">
                                <div class="pbR">등급</div>
                                <div class="pbR">C3</div>
                            </div>
                            <div class="clear"></div>
                        </div>
                        <div class="proProgress">
                            <div class="ppText">펀딩 진행률</div>
                            <div class="ppPercent">0%</div>
                            <div class="clear"></div>
                        </div>
                        <div class="ppVis"><!--펀딩진행률-->
                            <div class="ppvEmptyG"></div><!--빈그래프-->
                            <div class="ppvFillG"></div><!--실진행그래프-->
                        </div>
                        <div class="ppCondiiton">
                            <div class="ppNnG">
                                <div class="ppNow">0원(0명)</div>
                                <div class="ppGoal"> / 3억원</div>
                                <div class="clear"></div>
                            </div>
                            <div class="ppStat">
                                <img src="./img/06staticon01.png?<?=$ver?>" /> 대기중
                            </div>
                            <div class="clear"></div>
                        </div>
                    </div>
                </div>
                <div class="product">
                    <div class="pImgPos">
                        <img class="pIMG" src="./img/06sampleimg.png?<?=$ver?>" />
                        <div class="piBanner">
                            <div class="pibPriority">1순위</div>
                            <div class="pibInvest">자동투자 40%</div>
                            <div class="clear"></div>
                        </div>
                    </div>
                    <div class="proDesc">
                        <div class="proTitle">제1156차 서산 테크노밸리 근린생활시설 신축사업 25차</div>
                        <div class="proPeriod">모집기간 : 2018.06.11 ~ 2018.06.18</div>
                        <div class="proBoxes">
                            <div class="proB">
                                <div class="pbR">수익률(연)</div>
                                <div class="pbR">14.5%</div>
                            </div>
                            <div class="proB">
                                <div class="pbR">투자기간</div>
                                <div class="pbR">9개월</div>
                            </div>
                            <div class="proB">
                                <div class="pbR">등급</div>
                                <div class="pbR">C3</div>
                            </div>
                            <div class="clear"></div>
                        </div>
                        <div class="proProgress">
                            <div class="ppText">펀딩 진행률</div>
                            <div class="ppPercent">0%</div>
                            <div class="clear"></div>
                        </div>
                        <div class="ppVis"><!--펀딩진행률-->
                            <div class="ppvEmptyG"></div><!--빈그래프-->
                            <div class="ppvFillG"></div><!--실진행그래프-->
                        </div>
                        <div class="ppCondiiton">
                            <div class="ppNnG">
                                <div class="ppNow">0원(0명)</div>
                                <div class="ppGoal"> / 3억원</div>
                                <div class="clear"></div>
                            </div>
                            <div class="ppStat">
                                <img src="./img/06staticon01.png?<?=$ver?>" /> 대기중
                            </div>
                            <div class="clear"></div>
                        </div>
                    </div>
                </div>
                <div class="product">
                    <div class="pImgPos">
                        <img class="pIMG" src="./img/06sampleimg.png?<?=$ver?>" />
                        <div class="piBanner">
                            <div class="pibPriority">1순위</div>
                            <div class="pibInvest">자동투자 40%</div>
                            <div class="clear"></div>
                        </div>
                    </div>
                    <div class="proDesc">
                        <div class="proTitle">제1156차 서산 테크노밸리 근린생활시설 신축사업 25차</div>
                        <div class="proPeriod">모집기간 : 2018.06.11 ~ 2018.06.18</div>
                        <div class="proBoxes">
                            <div class="proB">
                                <div class="pbR">수익률(연)</div>
                                <div class="pbR">14.5%</div>
                            </div>
                            <div class="proB">
                                <div class="pbR">투자기간</div>
                                <div class="pbR">9개월</div>
                            </div>
                            <div class="proB">
                                <div class="pbR">등급</div>
                                <div class="pbR">C3</div>
                            </div>
                            <div class="clear"></div>
                        </div>
                        <div class="proProgress">
                            <div class="ppText">펀딩 진행률</div>
                            <div class="ppPercent">0%</div>
                            <div class="clear"></div>
                        </div>
                        <div class="ppVis"><!--펀딩진행률-->
                            <div class="ppvEmptyG"></div><!--빈그래프-->
                            <div class="ppvFillG"></div><!--실진행그래프-->
                        </div>
                        <div class="ppCondiiton">
                            <div class="ppNnG">
                                <div class="ppNow">0원(0명)</div>
                                <div class="ppGoal"> / 3억원</div>
                                <div class="clear"></div>
                            </div>
                            <div class="ppStat">
                                <img src="./img/06staticon01.png?<?=$ver?>" /> 대기중
                            </div>
                            <div class="clear"></div>
                        </div>
                    </div>
                </div>
                <div class="product">
                    <div class="pImgPos">
                        <img class="pIMG" src="./img/06sampleimg.png?<?=$ver?>" />
                        <div class="piBanner">
                            <div class="pibPriority">1순위</div>
                            <div class="pibInvest">자동투자 40%</div>
                            <div class="clear"></div>
                        </div>
                    </div>
                    <div class="proDesc">
                        <div class="proTitle">제1156차 서산 테크노밸리 근린생활시설 신축사업 25차</div>
                        <div class="proPeriod">모집기간 : 2018.06.11 ~ 2018.06.18</div>
                        <div class="proBoxes">
                            <div class="proB">
                                <div class="pbR">수익률(연)</div>
                                <div class="pbR">14.5%</div>
                            </div>
                            <div class="proB">
                                <div class="pbR">투자기간</div>
                                <div class="pbR">9개월</div>
                            </div>
                            <div class="proB">
                                <div class="pbR">등급</div>
                                <div class="pbR">C3</div>
                            </div>
                            <div class="clear"></div>
                        </div>
                        <div class="proProgress">
                            <div class="ppText">펀딩 진행률</div>
                            <div class="ppPercent">0%</div>
                            <div class="clear"></div>
                        </div>
                        <div class="ppVis"><!--펀딩진행률-->
                            <div class="ppvEmptyG"></div><!--빈그래프-->
                            <div class="ppvFillG"></div><!--실진행그래프-->
                        </div>
                        <div class="ppCondiiton">
                            <div class="ppNnG">
                                <div class="ppNow">0원(0명)</div>
                                <div class="ppGoal"> / 3억원</div>
                                <div class="clear"></div>
                            </div>
                            <div class="ppStat">
                                <img src="./img/06staticon01.png?<?=$ver?>" /> 대기중
                            </div>
                            <div class="clear"></div>
                        </div>
                    </div>
                </div>
                <div class="product">
                    <div class="pImgPos">
                        <img class="pIMG" src="./img/06sampleimg.png?<?=$ver?>" />
                        <div class="piBanner">
                            <div class="pibPriority">1순위</div>
                            <div class="pibInvest">자동투자 40%</div>
                            <div class="clear"></div>
                        </div>
                    </div>
                    <div class="proDesc">
                        <div class="proTitle">제1156차 서산 테크노밸리 근린생활시설 신축사업 25차</div>
                        <div class="proPeriod">모집기간 : 2018.06.11 ~ 2018.06.18</div>
                        <div class="proBoxes">
                            <div class="proB">
                                <div class="pbR">수익률(연)</div>
                                <div class="pbR">14.5%</div>
                            </div>
                            <div class="proB">
                                <div class="pbR">투자기간</div>
                                <div class="pbR">9개월</div>
                            </div>
                            <div class="proB">
                                <div class="pbR">등급</div>
                                <div class="pbR">C3</div>
                            </div>
                            <div class="clear"></div>
                        </div>
                        <div class="proProgress">
                            <div class="ppText">펀딩 진행률</div>
                            <div class="ppPercent">0%</div>
                            <div class="clear"></div>
                        </div>
                        <div class="ppVis"><!--펀딩진행률-->
                            <div class="ppvEmptyG"></div><!--빈그래프-->
                            <div class="ppvFillG"></div><!--실진행그래프-->
                        </div>
                        <div class="ppCondiiton">
                            <div class="ppNnG">
                                <div class="ppNow">0원(0명)</div>
                                <div class="ppGoal"> / 3억원</div>
                                <div class="clear"></div>
                            </div>
                            <div class="ppStat">
                                <img src="./img/06staticon01.png?<?=$ver?>" /> 대기중
                            </div>
                            <div class="clear"></div>
                        </div>
                    </div>
                </div>
                <div class="product">
                    <div class="pImgPos">
                        <img class="pIMG" src="./img/06sampleimg.png?<?=$ver?>" />
                        <div class="piBanner">
                            <div class="pibPriority">1순위</div>
                            <div class="pibInvest">자동투자 40%</div>
                            <div class="clear"></div>
                        </div>
                    </div>
                    <div class="proDesc">
                        <div class="proTitle">제1156차 서산 테크노밸리 근린생활시설 신축사업 25차</div>
                        <div class="proPeriod">모집기간 : 2018.06.11 ~ 2018.06.18</div>
                        <div class="proBoxes">
                            <div class="proB">
                                <div class="pbR">수익률(연)</div>
                                <div class="pbR">14.5%</div>
                            </div>
                            <div class="proB">
                                <div class="pbR">투자기간</div>
                                <div class="pbR">9개월</div>
                            </div>
                            <div class="proB">
                                <div class="pbR">등급</div>
                                <div class="pbR">C3</div>
                            </div>
                            <div class="clear"></div>
                        </div>
                        <div class="proProgress">
                            <div class="ppText">펀딩 진행률</div>
                            <div class="ppPercent">0%</div>
                            <div class="clear"></div>
                        </div>
                        <div class="ppVis"><!--펀딩진행률-->
                            <div class="ppvEmptyG"></div><!--빈그래프-->
                            <div class="ppvFillG"></div><!--실진행그래프-->
                        </div>
                        <div class="ppCondiiton">
                            <div class="ppNnG">
                                <div class="ppNow">0원(0명)</div>
                                <div class="ppGoal"> / 3억원</div>
                                <div class="clear"></div>
                            </div>
                            <div class="ppStat">
                                <img src="./img/06staticon01.png?<?=$ver?>" /> 대기중
                            </div>
                            <div class="clear"></div>
                        </div>
                    </div>
                </div>
                <div class="product">
                    <div class="pImgPos">
                        <img class="pIMG" src="./img/06sampleimg.png?<?=$ver?>" />
                        <div class="piBanner">
                            <div class="pibPriority">1순위</div>
                            <div class="pibInvest">자동투자 40%</div>
                            <div class="clear"></div>
                        </div>
                    </div>
                    <div class="proDesc">
                        <div class="proTitle">제1156차 서산 테크노밸리 근린생활시설 신축사업 25차</div>
                        <div class="proPeriod">모집기간 : 2018.06.11 ~ 2018.06.18</div>
                        <div class="proBoxes">
                            <div class="proB">
                                <div class="pbR">수익률(연)</div>
                                <div class="pbR">14.5%</div>
                            </div>
                            <div class="proB">
                                <div class="pbR">투자기간</div>
                                <div class="pbR">9개월</div>
                            </div>
                            <div class="proB">
                                <div class="pbR">등급</div>
                                <div class="pbR">C3</div>
                            </div>
                            <div class="clear"></div>
                        </div>
                        <div class="proProgress">
                            <div class="ppText">펀딩 진행률</div>
                            <div class="ppPercent">0%</div>
                            <div class="clear"></div>
                        </div>
                        <div class="ppVis"><!--펀딩진행률-->
                            <div class="ppvEmptyG"></div><!--빈그래프-->
                            <div class="ppvFillG"></div><!--실진행그래프-->
                        </div>
                        <div class="ppCondiiton">
                            <div class="ppNnG">
                                <div class="ppNow">0원(0명)</div>
                                <div class="ppGoal"> / 3억원</div>
                                <div class="clear"></div>
                            </div>
                            <div class="ppStat">
                                <img src="./img/06staticon01.png?<?=$ver?>" /> 대기중
                            </div>
                            <div class="clear"></div>
                        </div>
                    </div>
                </div>
                <div class="product">
                    <div class="pImgPos">
                        <img class="pIMG" src="./img/06sampleimg.png?<?=$ver?>" />
                        <div class="piBanner">
                            <div class="pibPriority">1순위</div>
                            <div class="pibInvest">자동투자 40%</div>
                            <div class="clear"></div>
                        </div>
                    </div>
                    <div class="proDesc">
                        <div class="proTitle">제1156차 서산 테크노밸리 근린생활시설 신축사업 25차</div>
                        <div class="proPeriod">모집기간 : 2018.06.11 ~ 2018.06.18</div>
                        <div class="proBoxes">
                            <div class="proB">
                                <div class="pbR">수익률(연)</div>
                                <div class="pbR">14.5%</div>
                            </div>
                            <div class="proB">
                                <div class="pbR">투자기간</div>
                                <div class="pbR">9개월</div>
                            </div>
                            <div class="proB">
                                <div class="pbR">등급</div>
                                <div class="pbR">C3</div>
                            </div>
                            <div class="clear"></div>
                        </div>
                        <div class="proProgress">
                            <div class="ppText">펀딩 진행률</div>
                            <div class="ppPercent">0%</div>
                            <div class="clear"></div>
                        </div>
                        <div class="ppVis"><!--펀딩진행률-->
                            <div class="ppvEmptyG"></div><!--빈그래프-->
                            <div class="ppvFillG"></div><!--실진행그래프-->
                        </div>
                        <div class="ppCondiiton">
                            <div class="ppNnG">
                                <div class="ppNow">0원(0명)</div>
                                <div class="ppGoal"> / 3억원</div>
                                <div class="clear"></div>
                            </div>
                            <div class="ppStat">
                                <img src="./img/06staticon01.png?<?=$ver?>" /> 대기중
                            </div>
                            <div class="clear"></div>
                        </div>
                    </div>
                </div>
                <div class="product">
                    <div class="pImgPos">
                        <img class="pIMG" src="./img/06sampleimg.png?<?=$ver?>" />
                        <div class="piBanner">
                            <div class="pibPriority">1순위</div>
                            <div class="pibInvest">자동투자 40%</div>
                            <div class="clear"></div>
                        </div>
                    </div>
                    <div class="proDesc">
                        <div class="proTitle">제1156차 서산 테크노밸리 근린생활시설 신축사업 25차</div>
                        <div class="proPeriod">모집기간 : 2018.06.11 ~ 2018.06.18</div>
                        <div class="proBoxes">
                            <div class="proB">
                                <div class="pbR">수익률(연)</div>
                                <div class="pbR">14.5%</div>
                            </div>
                            <div class="proB">
                                <div class="pbR">투자기간</div>
                                <div class="pbR">9개월</div>
                            </div>
                            <div class="proB">
                                <div class="pbR">등급</div>
                                <div class="pbR">C3</div>
                            </div>
                            <div class="clear"></div>
                        </div>
                        <div class="proProgress">
                            <div class="ppText">펀딩 진행률</div>
                            <div class="ppPercent">0%</div>
                            <div class="clear"></div>
                        </div>
                        <div class="ppVis"><!--펀딩진행률-->
                            <div class="ppvEmptyG"></div><!--빈그래프-->
                            <div class="ppvFillG"></div><!--실진행그래프-->
                        </div>
                        <div class="ppCondiiton">
                            <div class="ppNnG">
                                <div class="ppNow">0원(0명)</div>
                                <div class="ppGoal"> / 3억원</div>
                                <div class="clear"></div>
                            </div>
                            <div class="ppStat">
                                <img src="./img/06staticon01.png?<?=$ver?>" /> 대기중
                            </div>
                            <div class="clear"></div>
                        </div>
                    </div>
                </div>
                <div class="product">
                    <div class="pImgPos">
                        <img class="pIMG" src="./img/06sampleimg.png?<?=$ver?>" />
                        <div class="piBanner">
                            <div class="pibPriority">1순위</div>
                            <div class="pibInvest">자동투자 40%</div>
                            <div class="clear"></div>
                        </div>
                    </div>
                    <div class="proDesc">
                        <div class="proTitle">제1156차 서산 테크노밸리 근린생활시설 신축사업 25차</div>
                        <div class="proPeriod">모집기간 : 2018.06.11 ~ 2018.06.18</div>
                        <div class="proBoxes">
                            <div class="proB">
                                <div class="pbR">수익률(연)</div>
                                <div class="pbR">14.5%</div>
                            </div>
                            <div class="proB">
                                <div class="pbR">투자기간</div>
                                <div class="pbR">9개월</div>
                            </div>
                            <div class="proB">
                                <div class="pbR">등급</div>
                                <div class="pbR">C3</div>
                            </div>
                            <div class="clear"></div>
                        </div>
                        <div class="proProgress">
                            <div class="ppText">펀딩 진행률</div>
                            <div class="ppPercent">0%</div>
                            <div class="clear"></div>
                        </div>
                        <div class="ppVis"><!--펀딩진행률-->
                            <div class="ppvEmptyG"></div><!--빈그래프-->
                            <div class="ppvFillG"></div><!--실진행그래프-->
                        </div>
                        <div class="ppCondiiton">
                            <div class="ppNnG">
                                <div class="ppNow">0원(0명)</div>
                                <div class="ppGoal"> / 3억원</div>
                                <div class="clear"></div>
                            </div>
                            <div class="ppStat">
                                <img src="./img/06staticon01.png?<?=$ver?>" /> 대기중
                            </div>
                            <div class="clear"></div>
                        </div>
                    </div>
                </div>
                <div class="product">
                    <div class="pImgPos">
                        <img class="pIMG" src="./img/06sampleimg.png?<?=$ver?>" />
                        <div class="piBanner">
                            <div class="pibPriority">1순위</div>
                            <div class="pibInvest">자동투자 40%</div>
                            <div class="clear"></div>
                        </div>
                    </div>
                    <div class="proDesc">
                        <div class="proTitle">제1156차 서산 테크노밸리 근린생활시설 신축사업 25차</div>
                        <div class="proPeriod">모집기간 : 2018.06.11 ~ 2018.06.18</div>
                        <div class="proBoxes">
                            <div class="proB">
                                <div class="pbR">수익률(연)</div>
                                <div class="pbR">14.5%</div>
                            </div>
                            <div class="proB">
                                <div class="pbR">투자기간</div>
                                <div class="pbR">9개월</div>
                            </div>
                            <div class="proB">
                                <div class="pbR">등급</div>
                                <div class="pbR">C3</div>
                            </div>
                            <div class="clear"></div>
                        </div>
                        <div class="proProgress">
                            <div class="ppText">펀딩 진행률</div>
                            <div class="ppPercent">0%</div>
                            <div class="clear"></div>
                        </div>
                        <div class="ppVis"><!--펀딩진행률-->
                            <div class="ppvEmptyG"></div><!--빈그래프-->
                            <div class="ppvFillG"></div><!--실진행그래프-->
                        </div>
                        <div class="ppCondiiton">
                            <div class="ppNnG">
                                <div class="ppNow">0원(0명)</div>
                                <div class="ppGoal"> / 3억원</div>
                                <div class="clear"></div>
                            </div>
                            <div class="ppStat">
                                <img src="./img/06staticon01.png?<?=$ver?>" /> 대기중
                            </div>
                            <div class="clear"></div>
                        </div>
                    </div>
                </div>
                <div class="product">
                    <div class="pImgPos">
                        <img class="pIMG" src="./img/06sampleimg.png?<?=$ver?>" />
                        <div class="piBanner">
                            <div class="pibPriority">1순위</div>
                            <div class="pibInvest">자동투자 40%</div>
                            <div class="clear"></div>
                        </div>
                    </div>
                    <div class="proDesc">
                        <div class="proTitle">제1156차 서산 테크노밸리 근린생활시설 신축사업 25차</div>
                        <div class="proPeriod">모집기간 : 2018.06.11 ~ 2018.06.18</div>
                        <div class="proBoxes">
                            <div class="proB">
                                <div class="pbR">수익률(연)</div>
                                <div class="pbR">14.5%</div>
                            </div>
                            <div class="proB">
                                <div class="pbR">투자기간</div>
                                <div class="pbR">9개월</div>
                            </div>
                            <div class="proB">
                                <div class="pbR">등급</div>
                                <div class="pbR">C3</div>
                            </div>
                            <div class="clear"></div>
                        </div>
                        <div class="proProgress">
                            <div class="ppText">펀딩 진행률</div>
                            <div class="ppPercent">0%</div>
                            <div class="clear"></div>
                        </div>
                        <div class="ppVis"><!--펀딩진행률-->
                            <div class="ppvEmptyG"></div><!--빈그래프-->
                            <div class="ppvFillG"></div><!--실진행그래프-->
                        </div>
                        <div class="ppCondiiton">
                            <div class="ppNnG">
                                <div class="ppNow">0원(0명)</div>
                                <div class="ppGoal"> / 3억원</div>
                                <div class="clear"></div>
                            </div>
                            <div class="ppStat">
                                <img src="./img/06staticon01.png?<?=$ver?>" /> 대기중
                            </div>
                            <div class="clear"></div>
                        </div>
                    </div>
                </div>
                <div class="product">
                    <div class="pImgPos">
                        <img class="pIMG" src="./img/06sampleimg.png?<?=$ver?>" />
                        <div class="piBanner">
                            <div class="pibPriority">1순위</div>
                            <div class="pibInvest">자동투자 40%</div>
                            <div class="clear"></div>
                        </div>
                    </div>
                    <div class="proDesc">
                        <div class="proTitle">제1156차 서산 테크노밸리 근린생활시설 신축사업 25차</div>
                        <div class="proPeriod">모집기간 : 2018.06.11 ~ 2018.06.18</div>
                        <div class="proBoxes">
                            <div class="proB">
                                <div class="pbR">수익률(연)</div>
                                <div class="pbR">14.5%</div>
                            </div>
                            <div class="proB">
                                <div class="pbR">투자기간</div>
                                <div class="pbR">9개월</div>
                            </div>
                            <div class="proB">
                                <div class="pbR">등급</div>
                                <div class="pbR">C3</div>
                            </div>
                            <div class="clear"></div>
                        </div>
                        <div class="proProgress">
                            <div class="ppText">펀딩 진행률</div>
                            <div class="ppPercent">0%</div>
                            <div class="clear"></div>
                        </div>
                        <div class="ppVis"><!--펀딩진행률-->
                            <div class="ppvEmptyG"></div><!--빈그래프-->
                            <div class="ppvFillG"></div><!--실진행그래프-->
                        </div>
                        <div class="ppCondiiton">
                            <div class="ppNnG">
                                <div class="ppNow">0원(0명)</div>
                                <div class="ppGoal"> / 3억원</div>
                                <div class="clear"></div>
                            </div>
                            <div class="ppStat">
                                <img src="./img/06staticon01.png?<?=$ver?>" /> 대기중
                            </div>
                            <div class="clear"></div>
                        </div>
                    </div>
                </div>
                <div class="product">
                    <div class="pImgPos">
                        <img class="pIMG" src="./img/06sampleimg.png?<?=$ver?>" />
                        <div class="piBanner">
                            <div class="pibPriority">1순위</div>
                            <div class="pibInvest">자동투자 40%</div>
                            <div class="clear"></div>
                        </div>
                    </div>
                    <div class="proDesc">
                        <div class="proTitle">제1156차 서산 테크노밸리 근린생활시설 신축사업 25차</div>
                        <div class="proPeriod">모집기간 : 2018.06.11 ~ 2018.06.18</div>
                        <div class="proBoxes">
                            <div class="proB">
                                <div class="pbR">수익률(연)</div>
                                <div class="pbR">14.5%</div>
                            </div>
                            <div class="proB">
                                <div class="pbR">투자기간</div>
                                <div class="pbR">9개월</div>
                            </div>
                            <div class="proB">
                                <div class="pbR">등급</div>
                                <div class="pbR">C3</div>
                            </div>
                            <div class="clear"></div>
                        </div>
                        <div class="proProgress">
                            <div class="ppText">펀딩 진행률</div>
                            <div class="ppPercent">0%</div>
                            <div class="clear"></div>
                        </div>
                        <div class="ppVis"><!--펀딩진행률-->
                            <div class="ppvEmptyG"></div><!--빈그래프-->
                            <div class="ppvFillG"></div><!--실진행그래프-->
                        </div>
                        <div class="ppCondiiton">
                            <div class="ppNnG">
                                <div class="ppNow">0원(0명)</div>
                                <div class="ppGoal"> / 3억원</div>
                                <div class="clear"></div>
                            </div>
                            <div class="ppStat">
                                <img src="./img/06staticon01.png?<?=$ver?>" /> 대기중
                            </div>
                            <div class="clear"></div>
                        </div>
                    </div>
                </div>
                <div class="clear"></div>
            </div>
        </div>
    </div>
</body>
</html>
