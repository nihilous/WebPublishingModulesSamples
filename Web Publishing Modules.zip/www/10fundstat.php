<?php
  include_once('./inc/vs.php');
?>


<!doctype html>
<html itemscope="" itemtype="http://schema.org/WebPage" lang="ko">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title></title>
    <link rel="stylesheet" type="text/css" href="./css/reset.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.2/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="./css/style.css?<?=$ver?>">

</head>
<body>
    <div id="fundstatPage">
        <div id="fsContents">
            <div class="fsBox">
                <div class="fsbTitle">투자 현황</div>
                <div class="fsbSum">현재까지 155,166건 투자</div>
                <div class="fsbTime">2018-06-12 14:40 기준</div>
                <div class="fsbMidPos">
                    <div class="fsbMidCol">
                        <div class="fsbMCl">
                            누적 투자액
                        </div>
                        <div class="fsbMCr">
                            463억 4,058만원
                        </div>
                        <div class="clear"></div>
                    </div>
                    <div class="fsbMidCol">
                        <div class="fsbMCl">
                            누적 상환액
                        </div>
                        <div class="fsbMCr">
                            328억 4,767만원
                        </div>
                        <div class="clear"></div>
                    </div>
                    <div class="fsbMidCol">
                        <div class="fsbMCl">
                            평균 수익률
                        </div>
                        <div class="fsbMCr">
                            11.03%
                        </div>
                        <div class="clear"></div>
                    </div>
                </div>
                <div class="fsbLowPos">
                    <div class="fsbLhalf">
                        <div class="fsbLbox">
                            <div class="fsbLBtop">
                                <div class="fsbLBTt">연채율</div>
                                <div class="fsbLBTq">?</div>
                                <div class="clear"></div>
                            </div>
                            <div class="fsbLBbar"></div>
                            <div class="fsbLBl">1.63%</div>
                        </div>
                        <div class="fsbLbox">
                            <div class="fsbLBtop">
                                <div class="fsbLBTt">부실률</div>
                                <div class="fsbLBTq">?</div>
                                <div class="clear"></div>
                            </div>
                            <div class="fsbLBbar"></div>
                            <div class="fsbLBl">2.01%</div>
                        </div>
                        <div class="clear"></div>
                    </div>
                    <div class="fsbLhalf">
                        <div class="fsbLbox">
                            <div class="fsbLBtop">
                                <div class="fsbLBTt">투자자 연체율</div>
                                <div class="fsbLBTq">?</div>
                                <div class="clear"></div>
                            </div>
                            <div class="fsbLBbar"></div>
                            <div class="fsbLBl">0.90%</div>
                        </div>
                        <div class="fsbLbox">
                            <div class="fsbLBtop">
                                <div class="fsbLBTt">투자자 손실률</div>
                                <div class="fsbLBTq">?</div>
                                <div class="clear"></div>
                            </div>
                            <div class="fsbLBbar"></div>
                            <div class="fsbLBl">0.06%</div>
                        </div>
                        <div class="clear"></div>
                    </div>
                    <div class="clear"></div>
                </div>
                <div class="fsLowStan">2018년 4월 말 현재</div>
                <div class="fsLowPos">
                    <div class="fsLinst">채권 기준과 투자자 기준의 연체/손실률 수치는 왜 다른가요?</div>
                    <div class="fsLq">?</div>
                    <div class="clear"></div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
