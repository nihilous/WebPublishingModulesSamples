<?php
  include_once('./inc/vs.php');
?>


<!doctype html>
<html itemscope="" itemtype="http://schema.org/WebPage" lang="ko">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title></title>
    <link rel="stylesheet" type="text/css" href="./css/reset.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.2/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="./css/style.css?<?=$ver?>">

</head>
<body>
    <div id="TradeLogPage">
        <div id="tlContents">
            <div class="tlTbox">
                <form method="get">
                    <div class="tltbUp">
                        <div class="tltbuL">조회기간</div>
                        <div class="tltbuM">
                            <div class="tltbum1">
                                <input value="2018-06-17" />
                                <div class="tlExtraS"></div>
                                <div class="clear"></div>
                            </div>
                            <div class="tltbum2">~</div>
                            <div class="tltbum3">
                                <input value="2018-06-17" />
                                <div class="tlExtraS"></div>
                                <div class="clear"></div>
                            </div>
                            <div class="clear"></div>
                        </div>
                        <div class="tltbuR">
                            <button class="tltbur1">1개월</button>
                            <button class="tltbur2">3개월</button>
                            <button class="tltbur3">6개월</button>
                            <button class="tltbur4">1년</button>
                            <div class="clear"></div>
                        </div>
                        <div class="clear"></div>
                    </div>
                    <div  class="tltbDown">
                        <div class="tltbdL">조회내용</div>
                        <div class="tltbdM">
                            <div class="tltbdm1">
                                <input class="tltbdmCB" type="checkbox" />
                                <div class="tltbdmCBT">전체</div>
                                <div class="clear"></div>
                            </div>
                            <div class="tltbdm2">
                                <input class="tltbdmCB" type="checkbox" />
                                <div class="tltbdmCBT">입금</div>
                                <div class="clear"></div>
                            </div>
                            <div class="tltbdm3">
                                <input class="tltbdmCB" type="checkbox" />
                                <div class="tltbdmCBT">출금</div>
                                <div class="clear"></div>
                            </div>
                            <div class="clear"></div>
                        </div>
                        <div class="tltbdR">
                            <button class="tltbdr1">조회</button>
                            <button class="tltbdr2">엑셀저장</button>
                            <div class="clear"></div>
                        </div>
                        <div class="clear"></div>
                    </div>
                </form>
            </div>
            <div class="tlBbox">
                <div class="tlbbStan">
                    <div class="tlbbS1">거래일자</div>
                    <div class="tlbbS2">구분</div>
                    <div class="tlbbS3">거래내역</div>
                    <div class="tlbbS4">입출금</div>
                    <div class="tlbbS5">잔액</div>
                    <div class="clear"></div>
                </div>
                <div  class="tlbbValue">
                    조회된 거래내역이 없습니다.
                </div>
            </div>
        </div>
    </div>
</body>
</html>
