<?php
  include_once('./inc/vs.php');
?>


<!doctype html>
<html itemscope="" itemtype="http://schema.org/WebPage" lang="ko">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title></title>
    <link rel="stylesheet" type="text/css" href="./css/reset.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.2/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="./css/style.css?<?=$ver?>">

</head>
<body>
    <div id="SettingPage">
        <div id="setContents">
            <form method="post">
                <div class="setPinfoBox">
                    <div class="spibTitle1">계정정보</div>
                    <div class="spibR1">
                        <div class="spibr1Title">이메일 (로그인 ID)</div>
                        <input class="spibr1Value" type="email" value="abc@efg.hij"/>
                    </div>
                    <div class="spibR2">
                        <div class="spibRowTitle">
                            <div class="spibL">비밀번호</div>
                            <div class="spibR link_btn">변경</div>
                            <div class="clear"></div>
                        </div>
                        <input type="text" value="1234567890"/>
                    </div>
                    <div class="spibTitle2">소셜 계정 연결</div>
                    <div class="spibR3">
                        <div class="spibL link_btn"><img src="./img/24settingsnsicon01.png?<?=$ver?>" />페이스북</div>
                        <div class="spibR link_btn">연결</div>
                        <div class="clear"></div>
                    </div>
                    <div class="spibR4">
                        <div class="spibL link_btn"><img src="./img/24settingsnsicon02.png?<?=$ver?>" />카카오</div>
                        <div class="spibR link_btn">연결</div>
                        <div class="clear"></div>
                    </div>
                    <div class="spibR5"><img src="./img/24settingwarn.png?<?=$ver?>" /> 소셜 계정을 연결하시면 간편하게 로그인하실 수 있습니다.</div>
                </div>
                <div class="setAinfoBox">
                    <div class="saibTitle">소셜 계정 연결</div>
                    <div class="saibR">
                        <div class="saibRtitle">이름</div>
                        <input type="text" value="이석진" />
                    </div>
                    <div class="saibR">
                        <div class="saibRtitle">생년월일</div>
                        <input type="text" value="1982년 11월 11일" />
                    </div>
                    <div class="saibR">
                        <div class="saibRowTitle">
                            <div class="saibrL">휴대폰 번호</div>
                            <div class="saibrR link_btn">변경</div>
                            <div class="clear"></div>
                        </div>
                        <input type="text" value="010-0000-0000"/>
                    </div>
                    <div class="saibR">
                        <div class="saibRtitle">성별</div>
                        <input type="text" value="남자"/>
                    </div>
                    <div class="saibR">
                        <div class="saibRowTitle">
                            <div class="saibrL">담보채권 투자 지정계좌</div>
                            <div class="saibrR link_btn">변경</div>
                            <div class="clear"></div>
                        </div>
                        <input type="text" value="카카오뱅크 0987654321098"/>
                    </div>
                    <div class="link_btn">회원탈퇴</div>
                </div>
            </form>

        </div>
    </div>
</body>
</html>
