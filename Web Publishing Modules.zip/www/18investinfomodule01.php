<?php
  include_once('./inc/vs.php');
?>


<!doctype html>
<html itemscope="" itemtype="http://schema.org/WebPage" lang="ko">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title></title>
    <link rel="stylesheet" type="text/css" href="./css/reset.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.2/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="./css/style.css?<?=$ver?>">

</head>
<body>
    <div id="InvestInfoModule01Page">
        <div id="iimContents">
            <div class="iimTopBox">
                <div class="iimTBtitle">
                    <div class="iimTBTl">투자정보</div>
                    <div class="iimTBTr"><a href="#">투자내역</a></div>
                    <div class="clear"></div>
                </div>
                <div class="iimTBsumS">
                    <div class="iimTBsss">총 투자</div>
                    <div class="iimTBsss">마감대기</div>
                    <div class="iimTBsss">모집완료</div>
                    <div class="iimTBsss">상환중</div>
                    <div class="iimTBsss">연체</div>
                    <div class="iimTBsss">부실</div>
                    <div class="iimTBsss">상환완료</div>
                    <div class="clear"></div>
                </div>
                <div class="iimTBsumV">
                    <div class="iimTBsvv">1</div>
                    <div class="iimTBsvv">0</div>
                    <div class="iimTBsvv">0</div>
                    <div class="iimTBsvv">0</div>
                    <div class="iimTBsvv">0</div>
                    <div class="iimTBsvv">0</div>
                    <div class="iimTBsvv">1</div>
                    <div class="clear"></div>
                </div>

                <div class="iimTBtabS">
                    <div class="iimtbt1">상환완료</div>
                    <div class="iimtbt2">상환예정</div>
                    <div class="iimtbt3">합계</div>
                    <div class="clear"></div>
                </div>
                <div class="iimTBtabV">
                    <div class="iimtbt1">원금</div>
                    <div class="iimtbt2"><p><b>10,000</b> 원</p></div>
                    <div class="iimtbt3"><p><b>0</b> 원</p></div>
                    <div class="iimtbt4"><p><b>10,000</b> 원</p></div>
                    <div class="clear"></div>
                </div>
                <div class="iimTBtabV">
                    <div class="iimtbt1">이자 (세후)</div>
                    <div class="iimtbt2"><p><b>187</b> 원</p></div>
                    <div class="iimtbt3"><p><b>0</b> 원</p></div>
                    <div class="iimtbt4"><p><b>187</b> 원</p></div>
                    <div class="clear"></div>
                </div>
                <div class="iimTBtabV">
                    <div class="iimtbt1">평균 수익률 <img src="./img/18investinfomodule01icon.png"<?=$ver?>  /></div>
                    <div class="iimtbt2"><p>연 <b>10.18</b> %</p></div>
                    <div class="iimtbt3"><p>연 <b>0</b> %</p></div>
                    <div class="iimtbt4"><p>연 <b>10.18</b> %</p></div>
                    <div class="clear"></div>
                </div>
                <div class="iimTBtabV">
                    <div class="iimtbt1">(-) 손실 <img src="./img/18investinfomodule01icon.png"<?=$ver?>  /></div>
                    <div class="iimtbt2"><p><b>0</b> %p</p></div>
                    <div class="iimtbt3"><p><b>0</b> %p</p></div>
                    <div class="iimtbt4"><p><b>0</b> %p</p></div>
                    <div class="clear"></div>
                </div>
                <div class="iimTBtabV">
                    <div class="iimtbt1">(+) 세이프플랜 <img src="./img/18investinfomodule01icon.png"<?=$ver?>  /></div>
                    <div class="iimtbt2"><p><b>0</b> %p</p></div>
                    <div class="iimtbt3"><p><b>0</b> %p</p></div>
                    <div class="iimtbt4"><p><b>0</b> %p</p></div>
                    <div class="clear"></div>
                </div>
                <div class="iimTBtabV">
                    <div class="iimtbt1">(-) 세금 <img src="./img/18investinfomodule01icon.png"<?=$ver?>  /></div>
                    <div class="iimtbt2"><p><b>1.79</b> %p</p></div>
                    <div class="iimtbt3"><p><b>0</b> %p</p></div>
                    <div class="iimtbt4"><p><b>1.79 </b> %p</p></div>
                    <div class="clear"></div>
                </div>
                <div class="iimTBtabV">
                    <div class="iimtbt1">(-) 투자 수수료 <img src="./img/18investinfomodule01icon.png"<?=$ver?>  /></div>
                    <div class="iimtbt2"><p><b>0</b> %p</p></div>
                    <div class="iimtbt3"><p><b>0</b> %p</p></div>
                    <div class="iimtbt4"><p><b>0</b> %p</p></div>
                    <div class="clear"></div>
                </div>
                <div class="iimTBtabVCal">
                    <div class="iimtbtVC1">실질 수익률 <img src="./img/18investinfomodule01icon.png"<?=$ver?>  /></div>
                    <div class="iimtbtVC2"><p>연 <b>8.38</b> %</p></div>
                    <div class="iimtbtVC3"><p>연 <b>0</b> %</p></div>
                    <div class="iimtbtVC4"><p>연 <b>8.38</b> %</p></div>
                    <div class="clear"></div>
                </div>
                <div class="iimTBwarn">* 변경 안내: 2017년 10월 30일부터 '마감대기' 및 '모집완료' 상태의 상품은 계산에 반영되지 않습니다.</div>
            </div>
            <div class="iimMidBox">
                <div class="iimMBl">   <!--height 기준은 나의 계좌현황을 보고나서..-->
                    <div class="iimMBTitle">
                        <div class="iimMBTl">최근 입출금내역</div>
                        <div class="iimMBTr">내역보기</div>
                        <div class="clear"></div>
                    </div>
                    <div class="iimMBLcont">
                        <div class="iimMBLr">
                            <div class="iimMBL1">2018-05-31</div>
                            <div class="iimMBL2">예치금</div>
                            <div class="iimMBL3"><p><b>10,187</b> 원</p></div>
                            <div class="clear"></div>
                        </div>
                        <div class="iimMBLr">
                            <div class="iimMBL1">2018-01-26</div>
                            <div class="iimMBL2">552호 고베식당 3/3차</div>
                            <div class="iimMBL3"><p><b>7,897</b> 원</p></div>
                            <div class="clear"></div>
                        </div>
                        <div class="iimMBLr">
                            <div class="iimMBL1">2018-05-31</div>
                            <div class="iimMBL2">예치금</div>
                            <div class="iimMBL3"><p><b>10,187</b> 원</p></div>
                            <div class="clear"></div>
                        </div>
                        <div class="iimMBLr">
                            <div class="iimMBL1">2018-01-26</div>
                            <div class="iimMBL2">552호 고베식당 3/3차</div>
                            <div class="iimMBL3"><p><b>7,897</b> 원</p></div>
                            <div class="clear"></div>
                        </div>
                        <div class="iimMBLr">
                            <div class="iimMBL1">2018-05-31</div>
                            <div class="iimMBL2">예치금</div>
                            <div class="iimMBL3"><p><b>10,187</b> 원</p></div>
                            <div class="clear"></div>
                        </div>
                        <div class="iimMBLr">
                            <div class="iimMBL1">2018-01-26</div>
                            <div class="iimMBL2">552호 고베식당 3/3차</div>
                            <div class="iimMBL3"><p><b>7,897</b> 원</p></div>
                            <div class="clear"></div>
                        </div>
                        <div class="iimMBLr">
                            <div class="iimMBL1">2018-05-31</div>
                            <div class="iimMBL2">예치금</div>
                            <div class="iimMBL3"><p><b>10,187</b> 원</p></div>
                            <div class="clear"></div>
                        </div>
                        <div class="iimMBLr">
                            <div class="iimMBL1">2018-01-26</div>
                            <div class="iimMBL2">552호 고베식당 3/3차</div>
                            <div class="iimMBL3"><p><b>7,897</b> 원</p></div>
                            <div class="clear"></div>
                        </div>
                    </div>

                </div>
                <div class="iimMBr">
                    <div class="iimMBTitle">
                        <div class="iimMBTl">나의 계좌 현황</div>
                        <div class="iimMBTr">충전 및 출금</div>
                        <div class="clear"></div>
                    </div>
                    <div class="iimMBRcont">
                        <div class="iimMBRr">
                            <div class="iimMBR1">나의 계좌 잔액</div>
                            <div class="iimMBR2"><p><b>0</b> 원</p></div>
                            <div class="clear"></div>
                        </div>
                        <div class="iimMBRr">
                            <div class="iimMBR1">예치금</div>
                            <div class="iimMBR2"><p><b>0</b> 원</p></div>
                            <div class="clear"></div>
                        </div>
                        <div class="iimMBRr">
                            <div class="iimMBR1">포인트</div>
                            <div class="iimMBR2"><p><b>0</b> P</p></div>
                            <div class="clear"></div>
                        </div>
                        <div class="iimMBRr">나의 투자한도 <img src="" /></div>
                        <div class="iimMBRr">
                            <div class="iimMBR1">잔여투자한도</div>
                            <div class="iimMBR2"><p><b>20,000,000</b> 원</p></div>
                            <div class="clear"></div>
                        </div>
                        <div class="iimMBRr">
                            <div class="iimMBR1">최대투자한도</div>
                            <div class="iimMBR2"><p><b>20,000,000</b> 원</p></div>
                            <div class="clear"></div>
                        </div>
                    </div>
                </div>
                <div class="clear"></div>
            </div>
            <div class="iimBotBox">
                <div class="iimBBtitle">06월 상환정보</div>
                <div class="iimBBcont">
                    <div class="iimBBl">
                        <div class="iimBBLr">
                            <div class="iimBBLRl">상환 예정</div>
                            <div class="iimBBLRr"><p><b>0</b> 원</p></div>
                            <div class="clear"></div>
                        </div>
                        <div class="iimBBLr">
                            <div class="iimBBLRl">원금</div>
                            <div class="iimBBLRr"><p><b>0</b> 원</p></div>
                            <div class="clear"></div>
                        </div>
                        <div class="iimBBLr">
                            <div class="iimBBLRl">이자 (세후)</div>
                            <div class="iimBBLRr"><p><b>0</b> 원</p></div>
                            <div class="clear"></div>
                        </div>
                    </div>
                    <div class="iimBBr">
                        <div class="iimBBRr">
                            <div class="iimBBRRl">상환 완료</div>
                            <div class="iimBBRRr"><p><b>0</b> 원</p></div>
                            <div class="clear"></div>
                        </div>
                        <div class="iimBBRr">
                            <div class="iimBBRRl">원금</div>
                            <div class="iimBBRRr"><p><b>0</b> 원</p></div>
                            <div class="clear"></div>
                        </div>
                        <div class="iimBBRr">
                            <div class="iimBBRRl">이자 (세후)</div>
                            <div class="iimBBRRr"><p><b>0</b> 원</p></div>
                            <div class="clear"></div>
                        </div>
                    </div>
                    <div class="clear"></div>
                </div>
                <div class="iimBBsum">
                    <div class="iimBBSl">총 상환 금액</div>
                    <div class="iimBBSr"><p><b>0</b> 원</p></div>
                    <div class="clear"></div>
                </div>
                <div class="iimBBcal">
                    <div class="iimBBcalL">상환예정 스케쥴</div>
                    <div class="iimBBcalR">전체 스케줄 보기</div>
                    <div class="clear"></div>
                </div>
                <div class="iimBBCstan">
                    <div class="iimBBCS1">날짜</div>
                    <div class="iimBBCS2">상점명</div>
                    <div class="iimBBCS3">금액</div>
                    <div class="clear"></div>
                </div>
                <div class="iimBBcvPos">
                    <div class="iimBBCval">
                        <div class="iimBBCV1">날짜V</div>
                        <div class="iimBBCV2">상점명V</div>
                        <div class="iimBBCV3">금액V</div>
                        <div class="clear"></div>
                    </div>
                    <div class="iimBBCval">
                        <div class="iimBBCV1">날짜V</div>
                        <div class="iimBBCV2">상점명V</div>
                        <div class="iimBBCV3">금액V</div>
                        <div class="clear"></div>
                    </div>
                    <div class="iimBBCval">
                        <div class="iimBBCV1">날짜V</div>
                        <div class="iimBBCV2">상점명V</div>
                        <div class="iimBBCV3">금액V</div>
                        <div class="clear"></div>
                    </div>
                </div>

                <div class="iimBBNotice">상환예정이 없습니다</div>
            </div>
        </div>
    </div>
</body>
</html>
